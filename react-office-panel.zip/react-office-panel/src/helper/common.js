import CryptoJS from "crypto-js";
import { DATA_KEY } from "../utils/constance";

export const encryptPayload = (pwd) => {
  const key = CryptoJS.enc.Utf8.parse(DATA_KEY);
  const hashedKey = CryptoJS.SHA256(key); // Hash the key to get a 256-bit key

  // Generate random IV (16 bytes for AES-256-CBC)
  const iv = CryptoJS.lib.WordArray.random(16);

  const encrypted = CryptoJS.AES.encrypt(
    CryptoJS.enc.Utf8.parse(pwd),
    hashedKey,
    {
      iv: iv,
      mode: CryptoJS.mode.CBC,
      padding: CryptoJS.pad.Pkcs7,
    }
  );

  // Prepend the IV to the encrypted ciphertext for passing it along with the encrypted password
  const encryptedPayload =
    iv.toString(CryptoJS.enc.Base64) + ":" + encrypted.toString();

  return encryptedPayload;
};

// Decrypt function
export const decryptPayload = (encryptedPayload) => {
  try {
    const key = CryptoJS.enc.Utf8.parse(DATA_KEY); // Secret key
    const hashedKey = CryptoJS.SHA256(key); // Hash the key for AES-256 compatibility

    // Split the payload into IV and ciphertext
    const parts = encryptedPayload.split(":");
    if (parts.length !== 2) {
      throw new Error("Invalid encrypted payload format");
    }
    const iv = CryptoJS.enc.Base64.parse(parts[0]); // Extract IV
    const ciphertext = CryptoJS.enc.Base64.parse(parts[1]); // Extract ciphertext

    // Decrypt using AES-256-CBC
    const decrypted = CryptoJS.AES.decrypt(
      { ciphertext: ciphertext },
      hashedKey,
      {
        iv: iv,
        mode: CryptoJS.mode.CBC,
        padding: CryptoJS.pad.Pkcs7,
      }
    );

    const plaintext = decrypted.toString(CryptoJS.enc.Utf8);
    return JSON.parse(plaintext); // Parse the decrypted JSON
  } catch (error) {
    console.error("Decryption failed:", error);
    throw new Error("Failed to decrypt the API response");
  }
};

export const dateFormat = (dateString = "") => {
  if (!dateString) {
    return null; // Explicitly return null for invalid input
  }

  const date = new Date(dateString);

  if (isNaN(date.getTime())) {
    console.error("Invalid date string:", dateString);
    return null; // Return null if the date is invalid
  }

  // Format date as DD-MM-YYYY
  const day = String(date.getDate()).padStart(2, "0");
  const month = String(date.getMonth() + 1).padStart(2, "0"); // Months are 0-indexed
  const year = date.getFullYear();
  const formattedDate = `${year}-${month}-${day}`;

  // DateTime options
  const dateOptions = {
    day: "2-digit",
    month: "2-digit",
    year: "2-digit",
    hour: "2-digit",
    minute: "2-digit",
    second: "2-digit",
    hour12: true,
  };

  // Get formatted date and time (e.g., 26/12/24, 1:00:00 PM)
  const formattedDateTime = date.toLocaleString("en-GB", dateOptions);

  return { formattedDate, formattedDateTime };
};

export const generateRandomId = () => {
  const randomPart = Math.floor(Math.random() * 1000); // A 3-digit random number
  return (Date.now().toString().slice(-7) + randomPart).slice(-10);
};

export const currentDateTime = () => {
  const now = new Date(Date.now());
  const date = now.toISOString().split("T")[0];
  const time = now.toISOString().split("T")[1].split(".")[0];
  const dateTime = now.toISOString();

  return {
    date,
    time,
    dateTime,
  };
};

export const cleanUpValue = (value) => {
  if (!value) {
    return "";
  }
  return value?.replace(/\s*\(.*?\)/, "").trim();
};

export const generateOptions = () => {
  return Array.from({ length: 50 }, (_, i) => ({
    value: i + 1,
    label: i + 1,
  }));
};
