import { defaultAxios } from "../utils/api/axios";
import { APICustomServerUrl, APIServerBaseUrl } from "../utils/constance";
import showToast from "../utils/toastUtil";

export const getAxios = async (url, params) => {
  try {
    const data = await defaultAxios.get(url, { params });
    if (data?.status && data?.data) {
      // showToast.success(data?.message || "Updated");
      return data?.data;
    } else {
      // showToast.error(data?.message || "Invalid data");
      return [];
    }
  } catch (error) {
    console.log("🚀 ~ getAxios ~ error:", error);
    return false;
  }
};

export const getAxiosForAuthResponse = async (url, params) => {
  try {
    const data = await defaultAxios.get(url, { params });

    if (data && data?.status) {
      return data?.data;
    } else {
      return false;
    }
  } catch (error) {
    console.log("getAxiosForAuthResponse failed", error);
    return false;
  }
};

export const putAxios = async (url, payload) => {
  try {
    const data = await defaultAxios.put(url, payload);

    if (data) {
      showToast.success(data?.message || "Updated");
      return data?.data || data?.status;
    } else {
      showToast.error(data?.message || "Invalid data");
      return false;
    }
  } catch (error) {
    console.log("putAxios failed", error);
    return false;
  }
};

export const postAxios = async (url, payload) => {
  try {
    const data = await defaultAxios.post(url, payload);

    if (data && data?.status) {
      showToast.success(data?.message || "Success");
      // return data?.data || data?.status;
      return data?.status || data?.data;
    } else {
      showToast.error(data?.message || "Invalid data");
      return false;
    }
  } catch (error) {
    console.log("putAxios failed", error);
    return false;
  }
};

export const postAxiosWithoutAuth = async (url, payload) => {
  try {
    const data = await defaultAxios.post(url, payload);

    if (data && data?.status) {
      showToast.success(data?.message || "Success");
      return data;
    } else {
      showToast.error(data?.message || "Invalid data");
      return false;
    }
  } catch (error) {
    console.log("postAxiosWithoutAuth failed", error?.data?.message);
    return false;
  }
};

export const putAxiosWithoutAuth = async (url, payload) => {
  try {
    const { data } = await defaultAxios.put(url, payload);

    if (data && data?.status) {
      showToast.success(data?.message || "Success");
      return data?.data;
    } else {
      showToast.error(data?.message || "Invalid data");
      return false;
    }
  } catch (error) {
    console.log("postAxiosWithoutAuth failed", error?.data?.message);
    return false;
  }
};

export const postAxiosDataTable = async (url, payload) => {
  try {
    const data = await defaultAxios.post(url, payload);

    if (data && data?.status) {
      return data?.data;
    } else {
      return false;
    }
  } catch (error) {
    console.log("postAxiosDataTable failed", error);
    return false;
  }
};

export const deleteAxios = async (url) => {
  try {
    const data = await defaultAxios.delete(url);

    if (data && data?.status) {
      showToast.success(data?.message || "deleted");
      return data?.status ?? true;
    } else {
      showToast.error(data?.message || "Invalid data");
      return false;
    }
  } catch (error) {
    console.log("deleteAxios failed", error);
    return false;
  }
};

// custom axios url
export const getCustomUrlAxios = async (subDomain, url, params) => {
  try {
    const config = {
      baseURL: `${APICustomServerUrl}${subDomain}/api/v1`,
      url,
      method: "get",
      params,
    };

    const data = await defaultAxios(config);

    if (data && data?.status) {
      return data?.data;
    } else {
      return false;
    }
  } catch (error) {
    return false;
  }
};

export const postCustomUrlAxios = async ({
  subDomain,
  url,
  apptoken,
  payload,
}) => {
  try {
    const config = {
      baseURL: `${APICustomServerUrl}${subDomain}/api/v1`,
      headers: {
        "Content-Type": "application/json",
        Accept: "application/json",
        apptoken,
      },
      url,
      method: "post",
      data: payload,
    };

    const data = await defaultAxios(config);

    if (data && data?.status) {
      showToast.success(data?.message || "Success");
      return data?.data;
    } else {
      showToast.error(data?.message || "Invalid data");
      return false;
    }
  } catch (error) {
    return false;
  }
};

export const putCustomUrlAxios = async ({
  subDomain,
  url,
  apptoken,
  payload,
}) => {
  try {
    const config = {
      baseURL: `${APICustomServerUrl}${subDomain}/api/v1`,
      headers: {
        "Content-Type": "application/json",
        Accept: "application/json",
        apptoken,
      },
      url,
      method: "put",
      data: payload,
    };

    const data = await defaultAxios(config);

    if (data && data?.status) {
      showToast.success(data?.message || "updated");
      return data?.data;
    } else {
      showToast.error(data?.message || "Invalid data");
      return false;
    }
  } catch (error) {
    return false;
  }
};
