import { defaultAxios } from "../utils/api/axios";
import { importUrl } from "../utils/constance";

export const getAxiosImportServer = async (url, params) => {
  try {
    const config = {
      baseURL: importUrl,
      url,
      method: "get",
      params,
    };

    const data = await defaultAxios(config);

    if (data) {
      return data;
    } else {
      return false;
    }
  } catch (error) {
    console.error("getAxiosImportServer here", error);
    return false;
  }
};
