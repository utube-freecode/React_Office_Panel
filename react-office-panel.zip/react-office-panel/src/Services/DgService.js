import { defaultAxios } from "../utils/api/axios";
import { APIServerBaseUrl } from "../utils/constance";

export const postAxiosDGServer = async (url, payload) => {
  try {
    const config = {
      baseURL: APIServerBaseUrl,
      url,
      method: "post",
      data: payload,
    };

    const data = await defaultAxios(config);

    if (data && data?.status) {
      return data?.data;
    } else {
      return false;
    }
  } catch (error) {
    console.error("failed here", error);
    return false;
  }
};

export const getAxiosDGServer = async (url, params) => {
  try {
    const config = {
      baseURL: APIServerBaseUrl,
      url,
      method: "get",
      params,
    };

    const data = await defaultAxios(config);
    console.log("🚀 ~ getAxiosDGServer ~ data:", data);

    if (data && data?.status) {
      return data?.data;
    } else {
      return false;
    }
  } catch (error) {
    console.error("getAxiosDGServer here", error);
    return false;
  }
};
