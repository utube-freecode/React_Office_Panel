import React from "react";
import { Navigate } from "react-router-dom";
import { useDispatch, useSelector } from "react-redux";
import { uiActions } from "../store/ui/ui-slice";

const ProtectedRoute = ({ children }) => {
  const dispatch = useDispatch();
  dispatch(uiActions.setLoading(false));
  dispatch(uiActions.setFormSubmitLoading(false));
  const { token } = useSelector((state) => state.user);

  if (!token) {
    return <Navigate to="/login" />;
  }
  return children;
};

export default ProtectedRoute;
