import { API_LOGIN, API_LOGOUT } from "../../utils/api/ApiConstant";
import { defaultAxios } from "../../utils/api/axios";
import showToast from "../../utils/toastUtil";
import { userAction } from "./user-slice";
import { uiActions } from "../ui/ui-slice";
import { decryptPayload, encryptPayload } from "../../helper/common";
import { getAxios } from "../../Services/commonService";

export const loginUser = async (dispatch, payload) => {
  try {
    dispatch(uiActions.setLoading(true));
    const { password } = payload;
    const encryptedPass = encryptPayload(password);
    const body = {
      ...payload,
      password: encryptedPass,
    };
    const data = await defaultAxios.post(API_LOGIN, body);
    if (data?.status) {
      dispatch(userAction.setToken(data?.token));
      dispatch(userAction.updateUser(decryptPayload(data?.data)));
      dispatch(uiActions.setHeading("Dashboard"));
      showToast.success(data?.message);
    } else {
      showToast.error(data?.message);
    }
    dispatch(uiActions.setLoading(false));
  } catch (err) {
    dispatch(uiActions.setLoading(false));
    console.error("Login failed:", err);
  }
};

export const logoutUser = async (dispatch) => {
  try {
    await getAxios(API_LOGOUT, {});
    await dispatch(userAction.clearUser());
    showToast.success("Logout.");
  } catch (error) {
    showToast.error(error?.data?.message);
  }
};

let isLogoutInProgress = false; // Prevent multiple logout calls

export const handleAxiosError = async (error, dispatch) => {
  // Handle network errors
  if (error?.message === "Network Error") {
    if (!isLogoutInProgress) {
      isLogoutInProgress = true; // Set the flag
      try {
        await logoutUser(dispatch); // Call logout function
        showToast.info("Network issue detected. You have been logged out.");
      } catch (logoutError) {
        console.error("Logout error:", logoutError);
        showToast.error("Error logging out. Please try again.");
      } finally {
        // isLogoutInProgress = false; // Reset the flag
      }
    }
  }

  // Handle other types of errors (e.g., 401 Unauthorized)
  if (error?.response?.status === 401) {
    try {
      await logoutUser(dispatch);
      showToast.warning("Session expired. Please log in again.");
    } catch (logoutError) {
      console.error("Logout error:", logoutError);
    }
  }

  // Return a rejected promise to allow further error handling
  return Promise.reject(error);
};
