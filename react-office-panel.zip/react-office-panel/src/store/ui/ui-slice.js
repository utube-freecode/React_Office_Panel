import { createSlice } from "@reduxjs/toolkit";

const uiSlice = createSlice({
  name: "ui",
  initialState: {
    isLoading: false,
    theme: "dark",
    heading: "",
    isFormLoading: false,
    breadcrumb: [],
  },
  reducers: {
    setLoading(state, action) {
      state.isLoading = action.payload;
    },
    setTheme(state, action) {
      state.theme = action.payload;
    },
    setHeading(state, action) {
      state.heading = action.payload;
    },
    setFormSubmitLoading(state, action) {
      state.isFormLoading = action.payload;
    },
    addBreadcrumb(state, action) {
      state.breadcrumb = action.payload;
    },
  },
});

export const uiActions = uiSlice.actions;
export default uiSlice;
