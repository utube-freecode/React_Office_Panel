import React, { useMemo, useState } from "react";
import { useFormik } from "formik";
import { useQuery } from "@tanstack/react-query";
import { useDispatch, useSelector } from "react-redux";

import {
  Button,
  CustomSelect,
  Error,
  Label,
  Runners,
  Switch,
} from "../../../Components";
import { useFilteredData } from "../../../Hooks";
import { currentDateTime, generateRandomId } from "../../../helper/common";
import {
  API_ADD_MARKET,
  API_GET_FANCYUSERS,
} from "../../../utils/api/ApiConstant";
import {
  getAxiosForAuthResponse,
  postAxios,
} from "../../../Services/commonService";
import { uiActions } from "../../../store/ui/ui-slice";
import { addBookmakerSchema } from "../../../Schema/Game/BookmakerSchema";

const AddBookmakerModal = ({ handleShowHide }) => {
  const { user } = useSelector((state) => state.user);
  const dispatch = useDispatch();
  const [selectAll, setSelectAll] = useState({
    sport: null,
    tournament: null,
    match: null,
  });
  const { sportOptions, tournamentOptions, matchOptions } = useFilteredData({
    sport: selectAll.sport,
    tournament: selectAll.tournament,
  });

  const { data: activeGameData } = useQuery({
    queryKey: ["filterActiveGame"],
    queryFn: async () =>
      await getAxiosForAuthResponse(API_GET_FILTER_SPORT, {
        page: 1,
        limit: -1,
      }),
    staleTime: 300000,
  });

  const { data: fancyUsers } = useQuery({
    queryKey: ["fancyUser"],
    queryFn: async () =>
      getAxiosForAuthResponse(`${API_GET_FANCYUSERS}/${user?.user_id}`, {}),
    staleTime: 300000,
  });

  const fancyUserOption = useMemo(
    () =>
      fancyUsers?.map((item) => ({
        value: item._id,
        label: item.name,
        userType: item.userType,
      })),
    [fancyUsers]
  );

  const {
    values,
    errors,
    touched,
    handleBlur,
    handleChange,
    handleSubmit,
    setFieldValue,
  } = useFormik({
    initialValues: {
      sport: sportOptions,
      tournament: tournamentOptions,
      match: matchOptions,
      runners: [],
      displayName: "",
      maxLimit: 0,
      isActive: false,
      assignTo: null,
    },
    validationSchema: addBookmakerSchema,
    onSubmit: (values) => {
      // const updateData = {...values, runners: }
      handleFormSubmit(values);
    },
  });

  const handleRunners = (runnersObj) => {
    // console.log("🚀 ~ handleRunners ~ runnersObj:", runnersObj);
    setFieldValue("runners", runnersObj);
  };

  const handleFormSubmit = async (values) => {
    dispatch(uiActions.setFormSubmitLoading(true));
    const {
      runners,
      displayName,
      sport,
      tournament,
      match,
      maxLimit,
      isActive,
      assignTo,
    } = values;
    const payload = {
      marketId: generateRandomId(),
      marketType: "Bookmaker",
      marketTypeId: "5ebc1code68br4bik5b0810",
      marketStartTime: currentDateTime().dateTime,
      totalMatched: 0,
      runners,
      displayName,
      maxLimit,
      isActive,
      message: null,
      sport: {
        id: sport?.value,
        name: sport?.label,
      },
      tournament: {
        id: tournament?.value,
        name: tournament?.label,
      },
      match: {
        id: match?.value,
        name: match?.label,
      },
      assignTo: {
        id: assignTo?.value,
        name: assignTo?.label,
      },
      bookmakerSetting: {
        _id: "6126561293560f2120edbd2a",
        updatedAt: currentDateTime().dateTime,
        createdAt: currentDateTime().dateTime,
        id: "5ebc1code68br4bik5b0810",
        minStack: 10,
        maxStack: 500000,
        maxProfit: 5000000,
        maxLoss: 20000000,
        betDelay: 0,
        maxStackPerOdds: 500000,
        maxOdds: 2000,
        minOdds: 0.25,
        isActive: true,
        isDeleted: false,
      },
      gameSetting: null,
      fancySetting: null,
      marketStatus: {
        id: "MS081893",
        name: "OPEN",
      },
      bookmakerMode: "manual",
    };

    const res = await postAxios(API_ADD_MARKET, payload);
    dispatch(uiActions.setFormSubmitLoading(false));
    if (res) {
      handleShowHide();
    }
  };

  return (
    <form onSubmit={handleSubmit}>
      <div className="row">
        <div className="col-md-4">
          <Label htmlFor="sport" className="form-label" isRequired={true}>
            Sports
          </Label>
          <CustomSelect
            options={sportOptions}
            value={values.sport}
            onChange={(selectedOption) => {
              setFieldValue("sport", selectedOption);
              setSelectAll((prev) => ({
                ...prev,
                sport: selectedOption?.value,
              }));
            }}
            placeholder="Select Sports"
            isMulti={false}
          />
          {errors.sport && touched.sport && <Error>{errors.sport}</Error>}
        </div>

        <div className="col-md-4">
          <Label htmlFor="tournament" className="form-label" isRequired={true}>
            Tournament
          </Label>
          <CustomSelect
            options={tournamentOptions}
            value={values.tournament}
            onChange={(selectedOption) => {
              setFieldValue("tournament", selectedOption);
              setSelectAll((prev) => ({
                ...prev,
                tournament: selectedOption?.value,
              }));
            }}
            placeholder="Select Tournament"
            isMulti={false}
          />
          {errors.tournament && touched.tournament && (
            <Error>{errors.tournament}</Error>
          )}
        </div>

        <div className="col-md-4">
          <Label htmlFor="match" className="form-label" isRequired={true}>
            Matches
          </Label>
          <CustomSelect
            options={matchOptions}
            value={values.match}
            onChange={(selectedOption) =>
              setFieldValue("match", selectedOption)
            }
            placeholder="Select Match"
            isMulti={false}
          />
          {errors.match && touched.match && <Error>{errors.match}</Error>}
        </div>
        <div className="col-md-3">
          <Label htmlFor="isActive" className="form-label">
            Active
          </Label>
          <Switch
            name="isActive"
            onChange={handleChange}
            getValue={() => values.isActive}
            value={values.isActive}
          />
        </div>
        <div className="col-md-3">
          <Label htmlFor="displayName" className="form-label" isRequired={true}>
            Bookmaker name
          </Label>
          <input
            type="text"
            name="displayName"
            className="w-100 form-control"
            placeholder="Enter name"
            value={values.displayName}
            onChange={handleChange}
            onBlur={handleBlur}
          />
          {errors.displayName && touched.displayName && (
            <Error>{errors.displayName}</Error>
          )}
        </div>
        <div className="col-md-3">
          <Label htmlFor="maxLimit" className="form-label" isRequired={true}>
            Max limit
          </Label>
          <input
            type="number"
            name="maxLimit"
            className="w-100 form-control"
            placeholder="Enter limit"
            value={values.maxLimit}
            onChange={handleChange}
            onBlur={handleBlur}
          />
          {errors.maxLimit && touched.maxLimit && (
            <Error>{errors.maxLimit}</Error>
          )}
        </div>
        <div className="col-md-3">
          <Label htmlFor="assignTo" className="form-label" isRequired={true}>
            Assign To
          </Label>
          <CustomSelect
            options={fancyUserOption}
            value={values.assignTo}
            onChange={(selectedOption) =>
              setFieldValue("assignTo", selectedOption)
            }
            placeholder="Select User"
            isMulti={false}
          />
          {errors.assignTo && touched.assignTo && (
            <Error>{errors.assignTo}</Error>
          )}
        </div>
        <div className="col-md-12">
          <Runners
            handleRunners={(runnersobj) => handleRunners(runnersobj)}
            errors={errors.runners}
            touched={touched.runners}
          />
        </div>
      </div>
      <Button type="submit" isHidden={true} id="form-submit-btn">
        submit
      </Button>
    </form>
  );
};

export default AddBookmakerModal;
