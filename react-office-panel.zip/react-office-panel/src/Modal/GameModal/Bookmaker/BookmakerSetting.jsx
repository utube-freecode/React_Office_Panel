import React from "react";
import { useFormik } from "formik";

import { Button, Error, Label } from "../../../Components";
import { API_UPDATE_MARKETBYTYPE } from "../../../utils/api/ApiConstant";
import { putAxios } from "../../../Services/commonService";
import { bookmakerSettingSchema } from "../../../Schema/Game/BookmakerSchema";

const BookmakerSetting = ({ rowData, handleShowHide, handlePutRequest }) => {
  const { values, touched, errors, handleBlur, handleChange, handleSubmit } =
    useFormik({
      initialValues: {
        minStack: rowData?.bookmakerSetting?.minStack,
        maxStack: rowData?.bookmakerSetting?.maxStack,
        maxProfit: rowData?.bookmakerSetting?.maxProfit,
        betDelay: rowData?.bookmakerSetting?.betDelay,
      },
      validationSchema: bookmakerSettingSchema,
      onSubmit: (values) => {
        const payload = {
          ...rowData,
          bookmakerSetting: { ...rowData.bookmakerSetting, ...values },
        };
        handlePutRequest({
          url: `${API_UPDATE_MARKETBYTYPE}/${rowData?.marketId}`,
          payload,
          modalRequest: true,
          updateRowData: true,
        });
      },
    });

  return (
    <form onSubmit={handleSubmit}>
      <div className="row">
        <div className="col-md-6">
          <Label htmlFor="minStack" className="form-label" isRequired={true}>
            Min Stack
          </Label>
          <input
            type="number"
            className="form-control"
            name="minStack"
            id="minStack"
            placeholder="0"
            onChange={handleChange}
            onBlur={handleBlur}
            value={values.minStack}
          />
          {errors.minStack && touched.minStack && (
            <Error>{errors.minStack}</Error>
          )}
        </div>
        <div className="col-md-6">
          <Label htmlFor="maxStack" className="form-label" isRequired={true}>
            max Stack
          </Label>
          <input
            type="number"
            className="form-control"
            name="maxStack"
            id="maxStack"
            placeholder="0"
            onChange={handleChange}
            onBlur={handleBlur}
            value={values.maxStack}
          />
          {errors.maxStack && touched.maxStack && (
            <Error>{errors.maxStack}</Error>
          )}
        </div>
        <div className="col-md-6">
          <Label htmlFor="maxProfit" className="form-label" isRequired={true}>
            Max profit
          </Label>
          <input
            type="number"
            className="form-control"
            name="maxProfit"
            id="maxProfit"
            placeholder="0"
            onChange={handleChange}
            onBlur={handleBlur}
            value={values.maxProfit}
          />
          {errors.maxProfit && touched.maxProfit && (
            <Error>{errors.maxProfit}</Error>
          )}
        </div>
        <div className="col-md-6">
          <Label htmlFor="betDelay" className="form-label" isRequired={true}>
            Bet delay
          </Label>
          <input
            type="number"
            className="form-control"
            name="betDelay"
            id="betDelay"
            placeholder="0"
            onChange={handleChange}
            onBlur={handleBlur}
            value={values.betDelay}
          />
          {errors.betDelay && touched.betDelay && (
            <Error>{errors.betDelay}</Error>
          )}
        </div>
      </div>
      <Button type="submit" id="form-submit-btn" isHidden={true}>
        Submit
      </Button>
    </form>
  );
};

export default BookmakerSetting;
