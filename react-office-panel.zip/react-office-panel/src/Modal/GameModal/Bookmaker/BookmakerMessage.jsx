import React from "react";
import { useFormik } from "formik";

import { Button, Error, Label } from "../../../Components";
import { messageSchema } from "../../../Schema/Game/MarketSchema";
import { putAxios } from "../../../Services/commonService";
import { API_UPDATE_MARKET } from "../../../utils/api/ApiConstant";

const BookmakerMessage = ({ rowData, handleShowHide }) => {
  const { values, touched, errors, handleChange, handleBlur, handleSubmit } =
    useFormik({
      initialValues: {
        message: rowData?.message || "",
      },
      validationSchema: messageSchema,
      onSubmit: async (values) => {
        const body = {
          ...rowData,
          message: values?.message,
        };

        console.log("🚀 ~ onSubmit: ~ body:", body);
        handleFormSubmit(body);
      },
    });

  const handleFormSubmit = async (payload) => {
    const res = await putAxios(`${API_UPDATE_MARKET}/${rowData?._id}`, payload);

    if (res) {
      handleShowHide();
    }
  };

  return (
    <form onSubmit={handleSubmit} className="row">
      <div className="col-12">
        <Label htmlFor="message" className="form-label" isRequired={true}>
          Message
        </Label>
        <textarea
          className="form-control"
          name="message"
          id="message"
          placeholder="Enter Message"
          onChange={handleChange}
          onBlur={handleBlur}
          value={values.message}
          rows={5}
          cols={10}
          autoFocus={true}
        ></textarea>
        {errors.message && touched.message && <Error>{errors.message}</Error>}
      </div>

      <Button type="submit" id="form-submit-btn" isHidden={true}>
        Submit
      </Button>
    </form>
  );
};

export default BookmakerMessage;
