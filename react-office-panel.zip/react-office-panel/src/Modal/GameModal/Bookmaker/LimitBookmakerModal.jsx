import React from "react";
import { useFormik } from "formik";

import { Button, Error, Label } from "../../../Components";
import { limitBookmakerSchema } from "../../../Schema/Game/BookmakerSchema";

const LimitBookmakerModal = ({ rowData, handleShowHide, handlePutRequest }) => {
  const { bookmakerSetting } = rowData;
  const { values, touched, errors, handleChange, handleBlur, handleSubmit } =
    useFormik({
      initialValues: {
        minStack: bookmakerSetting?.minStack || 0,
        maxStack: bookmakerSetting?.maxStack || 0,
        maxProfit: bookmakerSetting?.maxProfit || 0,
        betDelay: bookmakerSetting?.betDelay || 0,
      },
      validationSchema: limitBookmakerSchema,
      onSubmit: async (values) => {
        const body = {
          ...rowData,
          bookmakerSetting: {
            ...bookmakerSetting,
            minStack: values?.minStack,
            maxStack: values?.maxStack,
            maxProfit: values?.maxProfit,
            betDelay: values?.betDelay,
          },
        };

        handleFormSubmit(body);
      },
    });

  const handleFormSubmit = (payload) => {
    const res = handlePutRequest(
      rowData,
      payload.bookmakerSetting,
      "bookmakerSetting"
    );

    if (res) {
      handleShowHide();
    }
  };

  return (
    <form onSubmit={handleSubmit}>
      <div className="row">
        <div className="col-md-6">
          <Label htmlFor="minStack" className="form-label" isRequired={true}>
            Min Stack
          </Label>
          <input
            type="number"
            className="form-control"
            name="minStack"
            id="minStack"
            placeholder="0"
            onChange={handleChange}
            onBlur={handleBlur}
            value={values.minStack}
          />
          {errors.minStack && touched.minStack && (
            <Error>{errors.minStack}</Error>
          )}
        </div>
        <div className="col-md-6">
          <Label htmlFor="maxStack" className="form-label" isRequired={true}>
            Max Stack
          </Label>
          <input
            type="number"
            className="form-control"
            name="maxStack"
            id="maxStack"
            placeholder="0"
            onChange={handleChange}
            onBlur={handleBlur}
            value={values.maxStack}
          />
          {errors.maxStack && touched.maxStack && (
            <Error>{errors.maxStack}</Error>
          )}
        </div>

        <div className="col-md-6">
          <Label htmlFor="maxProfit" className="form-label" isRequired={true}>
            Max Profit
          </Label>
          <input
            type="number"
            className="form-control"
            name="maxProfit"
            id="maxProfit"
            placeholder="0"
            onChange={handleChange}
            onBlur={handleBlur}
            value={values.maxProfit}
          />
          {errors.maxProfit && touched.maxProfit && (
            <Error>{errors.maxProfit}</Error>
          )}
        </div>

        <div className="col-md-6">
          <Label htmlFor="betDelay" className="form-label" isRequired={true}>
            Bet Delay
          </Label>
          <input
            type="number"
            className="form-control"
            name="betDelay"
            id="betDelay"
            placeholder="0"
            onChange={handleChange}
            onBlur={handleBlur}
            value={values.betDelay}
          />
          {errors.betDelay && touched.betDelay && (
            <Error>{errors.betDelay}</Error>
          )}
        </div>
      </div>
      <Button type="submit" id="form-submit-btn" isHidden={true}>
        Submit
      </Button>
    </form>
  );
};

export default LimitBookmakerModal;
