import { useFormik } from "formik";
import React from "react";
import { Error, Label } from "../../Components";
import { putAxios } from "../../Services/commonService";
import { API_UPDATE_MARKET } from "../../utils/api/ApiConstant";
import { messageSchema } from "../../Schema/Game/MarketSchema";

const Message = ({ rowData, handleShowHide, handlePutRequest }) => {
  const { values, touched, errors, handleChange, handleBlur, handleSubmit } =
    useFormik({
      initialValues: {
        message: rowData?.message || "",
      },
      validationSchema: messageSchema,
      onSubmit: async (values) => {
        const body = {
          ...rowData,
          message: values?.message,
        };
        handlePutRequest(rowData, values?.message, "message");
      },
    });

  return (
    <form onSubmit={handleSubmit}>
      <div className="row">
        <div className="col-12">
          <Label htmlFor="message" className="form-label" isRequired={true}>
            Match Id
          </Label>
          <textarea
            className="form-control"
            name="message"
            id="message"
            placeholder="Enter Message"
            onChange={handleChange}
            onBlur={handleBlur}
            value={values.message}
            rows={5}
            cols={10}
            autoFocus={true}
          ></textarea>
          {errors.message && touched.message && <Error>{errors.message}</Error>}
        </div>
      </div>

      <button type="submit" id="form-submit-btn" hidden>
        Submit
      </button>
    </form>
  );
};

export default Message;
