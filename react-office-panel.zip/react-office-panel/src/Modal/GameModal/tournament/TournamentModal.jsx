import React from "react";
import { useFormik } from "formik";
import { useDispatch } from "react-redux";
import { uiActions } from "../../../store/ui/ui-slice";

import { Button, CustomSelect, Error, Label } from "../../../Components";
import { generateRandomId } from "../../../helper/common";
import TournamentSchema from "../../../Schema/Game/TournamentSchema";
import { API_POST_TOURNAMENT } from "../../../utils/api/ApiConstant";
import { postAxios } from "../../../Services/commonService";
import { useFilteredData } from "../../../Hooks";

const TournamentModal = ({ handleShowHide }) => {
  const dispatch = useDispatch();
  const {
    values,
    errors,
    touched,
    handleBlur,
    handleChange,
    handleSubmit,
    setFieldValue,
  } = useFormik({
    initialValues: {
      id: generateRandomId(),
      name: "",
      isManual: true,
      isActive: false,
      sport: null,
      isDeleted: false,
    },
    validationSchema: TournamentSchema,
    onSubmit: async (values) => {
      dispatch(uiActions.setFormSubmitLoading(true));
      const payload = {
        ...values,
        sport: { id: values?.sport?.value, name: values?.sport?.label },
      };

      const res = await postAxios(API_POST_TOURNAMENT, payload);
      dispatch(uiActions.setFormSubmitLoading(false));
      if (res) {
        handleShowHide();
      }
    },
  });
  const { sportOptions } = useFilteredData({
    sport: values?.sport?.value,
    enableTournament: false,
  });

  return (
    <form onSubmit={handleSubmit}>
      <div className="row m-0 p-0">
        <div className="col-lg-6 col-12 mb-2">
          <Label htmlFor="sport" className="form-label" isRequired={true}>
            Sport
          </Label>
          <CustomSelect
            options={sportOptions}
            value={values.sport}
            onChange={(selectedOption) =>
              setFieldValue("sport", selectedOption)
            }
            placeholder="Select Sport"
            isMulti={false}
          />
          {errors.sport && touched.sport && <Error>{errors.sport}</Error>}
        </div>
        <div className="col-md-6 m-0 p-1">
          <Label htmlFor="name" className="form-label" isRequired={true}>
            Tournament
          </Label>
          <input
            type="text"
            className="form-control"
            name="name"
            id="name"
            placeholder="Enter name"
            onChange={handleChange}
            onBlur={handleBlur}
            value={values.name}
          />
          {errors.name && touched.name && <Error>{errors.name}</Error>}
        </div>
      </div>
      <Button type="submit" id="form-submit-btn" isHidden={true}>
        Submit
      </Button>
    </form>
  );
};

export default TournamentModal;
