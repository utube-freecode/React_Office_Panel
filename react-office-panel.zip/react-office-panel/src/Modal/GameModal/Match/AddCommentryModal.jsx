import { useFormik } from "formik";
import React, { useState } from "react";
import { Label } from "../../../Components";
import {
  getAxios,
  postAxiosWithoutAuth,
} from "../../../Services/commonService";
import {
  API_ADD_COMMENTARY,
  API_DELETE_COMMENTARY,
  API_EDIT_COMMENTARY,
  API_UPDATE_COMMENTARYSTATUS,
} from "../../../utils/api/ApiConstant";
import Icon from "../../../assets/icons/Icon";

const AddCommentryModal = ({ commentryList, queryClient }) => {
  const [edit, setEdit] = useState(false);
  const { values, handleChange, handleSubmit, setValues } = useFormik({
    initialValues: {
      name: "",
      id: "",
    },
    onSubmit: async (values) => {
      console.log("values", values);

      if (edit) {
        handleEditHandler(values);
      } else {
        const body = {
          name: values?.name,
          isActive: true,
        };
        const res = await postAxiosWithoutAuth(`${API_ADD_COMMENTARY}`, body);
        setValues({ name: "", id: "" });
        queryClient.invalidateQueries(["commentaryList"]);
      }
    },
  });

  const handleToggleSwitch = async (details) => {
    try {
      const res = await postAxiosWithoutAuth(
        `${API_UPDATE_COMMENTARYSTATUS}/${details?._id}`,
        { isActive: !details?.isActive }
      );

      if (res) {
        queryClient.invalidateQueries(["commentaryList"]);
      }
    } catch (error) {
      console.log("InupdateStatus Error", error);
    }
  };

  const handleEditHandler = async (values) => {
    try {
      const res = await postAxiosWithoutAuth(
        `${API_EDIT_COMMENTARY}/${values?.id}`,
        { name: values?.name }
      );
      if (res) {
        setValues({ name: "", id: "" });
        setEdit(false);
        queryClient.invalidateQueries(["commentaryList"]);
      }
    } catch (error) {
      setEdit(false);

      console.log("InupdateStatus Error", error);
    }
  };

  const handleDeleteHandler = async (id) => {
    try {
      const res = await getAxios(`${API_DELETE_COMMENTARY}/${id}`, {});
      if (res) {
        queryClient.invalidateQueries(["commentaryList"]);
      }
    } catch (error) {
      console.log("error in Delete Commentary", error);
    }
  };

  return (
    <>
      <form onSubmit={handleSubmit} autoComplete="off">
        <div className="row">
          <Label htmlFor="name" className="form-label" isRequired={true}>
            Enter Name
          </Label>
          <input
            type="text"
            className="form-control"
            name="name"
            id="name"
            placeholder="Enter Name"
            onChange={handleChange}
            value={values.name}
            required
          />
        </div>

        <div className="card-body">
          <table
            style={{ borderCollapse: "collapse", width: "100%" }}
            className="table table-striped table-auto"
          >
            <thead className="table-light">
              <tr>
                <th>No.</th>
                <th>Name</th>
                <th>Is Active ?</th>
                <th>Actions</th>
              </tr>
            </thead>
            <tbody>
              {commentryList?.map((item, i) => {
                return (
                  <tr key={item?._id}>
                    <td>{i + 1}</td>
                    <td>{item?.name}</td>
                    <td>
                      <div className="form-check form-switch form-switch-success">
                        <input
                          className="form-check-input"
                          type="checkbox"
                          checked={item?.isActive}
                          onFocus={(e) => e.target.blur()}
                          onChange={() => handleToggleSwitch(item)}
                        />
                      </div>
                    </td>
                    <td>
                      <Icon
                        name="MdEditSquare"
                        className="m-1"
                        onClick={() => {
                          setEdit(true);
                          setValues({
                            ...values,
                            name: item?.name,
                            id: item?._id,
                          });
                        }}
                      />
                      <Icon
                        name="MdDelete"
                        className="m-1"
                        onClick={() => handleDeleteHandler(item?._id)}
                      />
                    </td>
                  </tr>
                );
              })}
            </tbody>
          </table>
        </div>

        <button type="submit" id="form-submit-btn" hidden>
          Submit
        </button>
      </form>
    </>
  );
};

export default AddCommentryModal;
