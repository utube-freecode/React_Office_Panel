import { useFormik } from "formik";
import React, { useState } from "react";
import { Button, DatePickerComponent, Error, Label } from "../../../Components";
import Icon from "../../../assets/icons/Icon";
import CommonModal from "../../CommonModal";
import { ImportTimeSchema } from "../../../Schema/Game/MatchSchema";
import { putAxiosWithoutAuth } from "../../../Services/commonService";
import { API_UPDATE_MATCHIMPORTTIME } from "../../../utils/api/ApiConstant";

const ImportTimeModal = ({ rowData }) => {
  const [isShow, setIsShow] = useState(false); // Modal visibility state

  const {
    values,
    touched,
    errors,
    handleBlur,
    handleChange,
    handleSubmit,
    setFieldValue,
  } = useFormik({
    initialValues: {
      openDate: null,
      hour: "",
      min: "",
      sec: "",
    },
    validationSchema: ImportTimeSchema,
    onSubmit: async (values) => {
      try {
        const body = {
          openDate: formatDate(
            values?.openDate,
            values?.hour,
            values?.min,
            values?.sec
          ),
          id: rowData?.id,
        };
        const res = putAxiosWithoutAuth(
          `${API_UPDATE_MATCHIMPORTTIME}/${rowData?.id}`,
          body
        );
        if (res) {
          handleShowHide();
        }
      } catch (error) {
        console.log("error in edit import time", error);
      }
    },
  });

  const handleShowHide = () => {
    setIsShow(!isShow);
  };

  const formatDate = (date, hour, min, sec) => {
    const year = date.getFullYear();
    const month = date.getMonth() + 1; // Month is 0-indexed
    const day = date.getDate();
    return `${year}-${month}-${day} ${hour}:${min}:${sec}.000Z`;
  };

  return (
    <>
      <div>
        <Icon name="FaClock" onClick={() => setIsShow(true)} />
      </div>

      <CommonModal
        isShow={isShow}
        handleShowHide={handleShowHide}
        modalTitle="Change Status"
        isFooter={false}
      >
        <form onSubmit={handleSubmit}>
          <div className="row">
            <div className="col-md-4">
              <Label
                htmlFor="openDate"
                className="form-label"
                isRequired={true}
              >
                Start Date
              </Label>
              <DatePickerComponent
                selectedDate={values.openDate}
                onChange={(date) => setFieldValue("openDate", date)}
                placeholderText="Pick a start date"
                minDate={new Date()}
              />
              {errors.openDate && touched.openDate && (
                <Error>{errors.openDate}</Error>
              )}
            </div>

            <div className="col-md-4">
              <Label htmlFor="time" className="form-label" isRequired={true}>
                Time
              </Label>
              <div
                className="time-input-group"
                style={{ display: "flex", gap: "10px", alignItems: "center" }}
              >
                <input
                  type="number"
                  className="form-control"
                  name="hour"
                  id="hour"
                  placeholder="HH"
                  min="0"
                  max="23"
                  onChange={handleChange}
                  onBlur={handleBlur}
                  value={values.hour}
                />
                <span>:</span>
                <input
                  type="number"
                  className="form-control"
                  name="min"
                  id="min"
                  placeholder="MM"
                  min="0"
                  max="59"
                  onChange={handleChange}
                  onBlur={handleBlur}
                  value={values.min}
                />
                <span>:</span>
                <input
                  type="number"
                  className="form-control"
                  name="sec"
                  id="sec"
                  placeholder="SS"
                  min="0"
                  max="59"
                  onChange={handleChange}
                  onBlur={handleBlur}
                  value={values.sec}
                />
              </div>
              {((errors.hour && touched.hour) ||
                (errors.min && touched.min) ||
                (errors.sec && touched.sec)) && (
                <Error>Invalid time input</Error>
              )}
            </div>
          </div>
          <div className="col-md-12 m-0 p-1 d-flex align-items-center justify-content-end">
            <Button className="btn-primary" type="submit" id="form-submit-btn">
              submit
            </Button>
          </div>
        </form>
      </CommonModal>
    </>
  );
};

export default ImportTimeModal;
