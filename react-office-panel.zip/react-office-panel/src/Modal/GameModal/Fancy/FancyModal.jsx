import React from "react";
import { useSelector } from "react-redux";
import { useFormik } from "formik";
import { useQuery } from "@tanstack/react-query";

import { CustomSelect, Error, Label } from "../../../Components";
import {
  getAxiosForAuthResponse,
  postAxios,
} from "../../../Services/commonService";
import { MarketSchema } from "../../../Schema/Game/MarketSchema";
import { currentDateTime, generateRandomId } from "../../../helper/common";
import {
  API_ADD_CREATEFANCY,
  API_ADD_MATCH,
  API_GET_FANCYSETTINGS,
  API_GET_FANCYUSERS,
  API_GET_FILTER_SPORT,
  API_GET_FILTER_TOURNAMENT,
} from "../../../utils/api/ApiConstant";
import { useFilteredData } from "../../../Hooks";

const FancyModal = ({ handleShowHide }) => {
  const { user } = useSelector((state) => state.user);

  const {
    values,
    touched,
    errors,
    handleBlur,
    handleChange,
    handleSubmit,
    setFieldValue,
  } = useFormik({
    initialValues: {
      sports: null,
      tournament: null,
      match: null,
      assignTo: null,
      fancyName: "",
    },
    validationSchema: MarketSchema,
    onSubmit: async (values) => {
      const obj = {
        fancyId: generateRandomId(),
        fancyName: values?.fancyName,
        tempAsiignToName: [
          {
            id: values?.assignTo?.value,
            itemName: values?.assignTo?.label,
            userType: values?.assignTo?.userType,
          },
        ],
        assignTo: {
          id: values?.assignTo?.value,
          name: values?.assignTo?.label,
        },
        fancySetting: {
          maxStack: 100000,
          minStack: 10,
          maxProfit: 2000000,
          betDelay: 0,
          maxStackPerOdds: 200000,
        },
        fancyConfigurationSetting: {
          ballStart: 30,
          rateRange: 20,
          rateDiffrence: 1,
        },
        marketId: generateRandomId(),
        marketType: "Fancy",
        marketTypeId: "5ebc1code68br4bik5b1808",
        marketStartTime: currentDateTime().dateTime,
        totalMatched: 0,
        gameSetting: null,
        bookmakerSetting: null,
        isActive: false,
        marketStatus: {
          id: "MS081893",
          name: "OPEN",
        },
        sport: {
          id: values?.sports?.value,
          name: values?.sports?.label,
        },
        tournament: {
          id: values?.tournament?.value,
          name: values?.tournament?.label,
        },
        match: {
          id: values?.match?.value,
          name: values?.match?.label,
        },
      };
      const res = await postAxios(API_ADD_CREATEFANCY, [obj]);
      if (res) {
        handleShowHide();
      }
    },
  });
  const { sportOptions, tournamentOptions, matchOptions } = useFilteredData({
    sport: values?.sports?.value,
    tournament: values?.tournament?.value,
  });

  const { data: fancySettings } = useQuery({
    queryKey: ["fancySettings"],
    queryFn: async () =>
      await getAxiosForAuthResponse(API_GET_FANCYSETTINGS, {
        page: 1,
        limit: -1,
      }),
    staleTime: 300000,
  });

  const { data: fancyUsers } = useQuery({
    queryKey: ["fancyUser"],
    queryFn: async () =>
      getAxiosForAuthResponse(`${API_GET_FANCYUSERS}/${user?.user_id}`, {}),
    staleTime: 300000,
  });

  const fancyUserOption =
    fancyUsers?.map((item) => ({
      value: item._id,
      label: item.name,
      userType: item.userType,
    })) || [];

  return (
    <form onSubmit={handleSubmit}>
      <div className="row">
        <div className="col-md-6">
          <Label htmlFor="sports" className="form-label" isRequired={true}>
            Sports
          </Label>
          <CustomSelect
            options={sportOptions}
            value={values.sports}
            onChange={(selectedOption) =>
              setFieldValue("sports", selectedOption)
            }
            placeholder="Select Sports"
            isMulti={false}
          />
          {errors.sports && touched.sports && <Error>{errors.sports}</Error>}
        </div>

        <div className="col-md-6">
          <Label htmlFor="tournament" className="form-label" isRequired={true}>
            Tournament
          </Label>
          <CustomSelect
            options={tournamentOptions}
            value={values.tournament}
            onChange={(selectedOption) =>
              setFieldValue("tournament", selectedOption)
            }
            placeholder="Select Tournament"
            isMulti={false}
          />
          {errors.tournament && touched.tournament && (
            <Error>{errors.tournament}</Error>
          )}
        </div>

        <div className="col-md-6">
          <Label htmlFor="match" className="form-label" isRequired={true}>
            Matches
          </Label>
          <CustomSelect
            options={matchOptions}
            value={values.match}
            onChange={(selectedOption) =>
              setFieldValue("match", selectedOption)
            }
            placeholder="Select Match"
            isMulti={false}
          />
          {errors.match && touched.match && <Error>{errors.match}</Error>}
        </div>
        <div className="col-md-6">
          <Label htmlFor="assignTo" className="form-label" isRequired={true}>
            Assign To
          </Label>
          <CustomSelect
            options={fancyUserOption}
            value={values.assignTo}
            onChange={(selectedOption) =>
              setFieldValue("assignTo", selectedOption)
            }
            placeholder="Select User"
            isMulti={false}
          />
          {errors.assignTo && touched.assignTo && (
            <Error>{errors.assignTo}</Error>
          )}
        </div>
        <div className="col-md-6">
          <Label htmlFor="fancyName" className="form-label" isRequired={true}>
            Match Name
          </Label>
          <input
            type="text"
            className="form-control"
            name="fancyName"
            id="fancyName"
            placeholder="Enter name"
            onChange={handleChange}
            onBlur={handleBlur}
            value={values.fancyName}
          />
          {errors.fancyName && touched.fancyName && (
            <Error>{errors.fancyName}</Error>
          )}
        </div>
      </div>
      <button type="submit" id="form-submit-btn" hidden>
        submit
      </button>
    </form>
  );
};

export default FancyModal;
