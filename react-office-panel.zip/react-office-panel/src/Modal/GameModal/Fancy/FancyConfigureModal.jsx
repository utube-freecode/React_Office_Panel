import { useFormik } from "formik";
import React from "react";

import { Button, Error, Label } from "../../../Components";
import { fancyConfigSchema } from "../../../Schema/Game/FancySchema";
import { putAxios } from "../../../Services/commonService";
import { API_FANCY_SETTING } from "../../../utils/api/ApiConstant";

const FancyConfigureModal = ({ rowData, handleShowHide, handlePutRequest }) => {
  const { values, touched, errors, handleChange, handleBlur, handleSubmit } =
    useFormik({
      initialValues: {
        ballStart: rowData?.fancyConfigurationSetting?.ballStart,
        rateDiffrence: rowData?.fancyConfigurationSetting?.rateDiffrence,
        rateRange: rowData?.fancyConfigurationSetting?.rateRange,
      },
      validationSchema: fancyConfigSchema,
      onSubmit: (values) => {
        const payload = {
          ...rowData,
          fancyConfigurationSetting: { ...values },
        };
        const url = `${API_FANCY_SETTING}/${rowData?._id}`;
        handlePutRequest({
          url,
          payload,
          modalRequest: true,
          updateRowData: true,
        });
      },
    });

  return (
    <form onSubmit={handleSubmit}>
      <div className="row">
        <div className="col-md-6">
          <Label htmlFor="ballStart" className="form-label" isRequired={true}>
            Ball Start After
          </Label>
          <input
            type="number"
            className="form-control"
            name="ballStart"
            id="ballStart"
            placeholder="Enter ballStart"
            onChange={handleChange}
            onBlur={handleBlur}
            value={values.ballStart}
            autoFocus={true}
          />
          {errors.ballStart && touched.ballStart && (
            <Error>{errors.ballStart}</Error>
          )}
        </div>
        <div className="col-md-6">
          <Label
            htmlFor="rateDiffrence"
            className="form-label"
            isRequired={true}
          >
            Rate Difference
          </Label>
          <input
            type="number"
            className="form-control"
            name="rateDiffrence"
            id="rateDiffrence"
            placeholder="Enter Rate Difference"
            onChange={handleChange}
            onBlur={handleBlur}
            value={values.rateDiffrence}
          />
          {errors.rateDiffrence && touched.rateDiffrence && (
            <Error>{errors.rateDiffrence}</Error>
          )}
        </div>
        <div className="col-md-6">
          <Label htmlFor="rateRange" className="form-label" isRequired={true}>
            Rate Range
          </Label>
          <input
            type="number"
            className="form-control"
            name="rateRange"
            id="rateRange"
            placeholder="Enter Rate Range"
            onChange={handleChange}
            onBlur={handleBlur}
            value={values.rateRange}
          />
          {errors.rateRange && touched.rateRange && (
            <Error>{errors.rateRange}</Error>
          )}
        </div>
      </div>

      <Button type="submit" id="form-submit-btn" isHidden={true}>
        Submit
      </Button>
    </form>
  );
};

export default FancyConfigureModal;
