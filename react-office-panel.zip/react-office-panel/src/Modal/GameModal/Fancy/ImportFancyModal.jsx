import React, { useState } from "react";
import { useFormik } from "formik";
import { useQuery } from "@tanstack/react-query";

import { CustomSelect, Error, Label } from "../../../Components";
import { useFilteredData } from "../../../Hooks";
import { importFancySchema } from "../../../Schema/Game/FancySchema";

const ImportFancyModal = () => {
  const [selectAll, setSelectAll] = useState({
    sports: null,
    tournament: null,
    match: null,
  });
  const { sportOptions, tournamentOptions, matchOptions } = useFilteredData({
    sport: selectAll.sports,
    tournament: selectAll.tournament,
  });

  const { data: activeGameData } = useQuery({
    queryKey: ["filterActiveGame"],
    queryFn: async () =>
      await getAxiosForAuthResponse(API_GET_FILTER_SPORT, {
        page: 1,
        limit: -1,
      }),
    staleTime: 300000,
  });

  const {
    values,
    errors,
    touched,
    handleBlur,
    handleChange,
    handleSubmit,
    setFieldValue,
  } = useFormik({
    initialValues: {
      sports: sportOptions,
      tournament: tournamentOptions,
      match: matchOptions,
    },
    validationSchema: importFancySchema,
    onSubmit: (values) => {
      console.log("Submitting", values);
    },
  });

  return (
    <form onSubmit={handleSubmit}>
      <div className="row">
        <div className="col-md-6">
          <Label htmlFor="sports" className="form-label" isRequired={true}>
            Sports
          </Label>
          <CustomSelect
            options={sportOptions}
            value={values.sports}
            onChange={(selectedOption) => {
              setFieldValue("sports", selectedOption);
              setSelectAll((prev) => ({
                ...prev,
                sports: selectedOption?.value,
              }));
            }}
            placeholder="Select Sports"
            isMulti={false}
          />
          {errors.sports && touched.sports && <Error>{errors.sports}</Error>}
        </div>

        <div className="col-md-6">
          <Label htmlFor="tournament" className="form-label" isRequired={true}>
            Tournament
          </Label>
          <CustomSelect
            options={tournamentOptions}
            value={values.tournament}
            onChange={(selectedOption) => {
              setFieldValue("tournament", selectedOption);
              setSelectAll((prev) => ({
                ...prev,
                tournament: selectedOption?.value,
              }));
            }}
            placeholder="Select Tournament"
            isMulti={false}
          />
          {errors.tournament && touched.tournament && (
            <Error>{errors.tournament}</Error>
          )}
        </div>

        <div className="col-md-6">
          <Label htmlFor="match" className="form-label" isRequired={true}>
            Matches
          </Label>
          <CustomSelect
            options={matchOptions}
            value={values.match}
            onChange={(selectedOption) =>
              setFieldValue("match", selectedOption)
            }
            placeholder="Select Match"
            isMulti={false}
          />
          {errors.match && touched.match && <Error>{errors.match}</Error>}
        </div>
      </div>
    </form>
  );
};

export default ImportFancyModal;
