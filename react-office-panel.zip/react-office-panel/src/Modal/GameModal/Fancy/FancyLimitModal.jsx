import React from "react";
import { useFormik } from "formik";
import { useSelector } from "react-redux";

import { Button, Error, Label } from "../../../Components";
import { limitFancySchema } from "../../../Schema/Game/FancySchema";
import { API_POST_CHECK_USER } from "../../../utils/api/ApiConstant";
import { postAxios } from "../../../Services/commonService";

const FancyLimitModal = ({ rowData, handlePutRequest, handleShowHide }) => {
  const { user } = useSelector((state) => state.user);
  const { values, touched, errors, handleBlur, handleChange, handleSubmit } =
    useFormik({
      initialValues: {
        minStack: rowData?.fancySetting?.minStack,
        maxStack: rowData?.fancySetting?.maxStack,
        maxProfit: rowData?.fancySetting?.maxProfit,
        betDelay: rowData?.fancySetting?.betDelay,
        password: "",
      },
      validationSchema: limitFancySchema,
      onSubmit: (values) => {
        const payload = { ...rowData, ...values };
        handleFormSubmit(payload);
      },
    });

  const handleFormSubmit = async (payload) => {
    const userPayload = { id: user.user_id, password: payload.password };
    const userRes = await postAxios(API_POST_CHECK_USER, userPayload);
    if (userRes) {
      //remove password key value here
      // Create a shallow copy of `payload` and remove `password`
      const { password, ...updatedValues } = payload;

      // Call the `handlePutRequest` function with the updated payload
      handlePutRequest(rowData, updatedValues, "fancySetting");
    } else {
      handleShowHide();
    }
  };

  return (
    <form onSubmit={handleSubmit}>
      <div className="row">
        <div className="col-md-6">
          <Label htmlFor="minStack" className="form-label" isRequired={true}>
            Min Stack
          </Label>
          <input
            type="number"
            className="form-control"
            name="minStack"
            id="minStack"
            placeholder="0"
            onChange={handleChange}
            onBlur={handleBlur}
            value={values.minStack}
          />
          {errors.minStack && touched.minStack && (
            <Error>{errors.minStack}</Error>
          )}
        </div>
        <div className="col-md-6">
          <Label htmlFor="maxStack" className="form-label" isRequired={true}>
            max Stack
          </Label>
          <input
            type="number"
            className="form-control"
            name="maxStack"
            id="maxStack"
            placeholder="0"
            onChange={handleChange}
            onBlur={handleBlur}
            value={values.maxStack}
          />
          {errors.maxStack && touched.maxStack && (
            <Error>{errors.maxStack}</Error>
          )}
        </div>
        <div className="col-md-6">
          <Label htmlFor="maxProfit" className="form-label" isRequired={true}>
            Max profit
          </Label>
          <input
            type="number"
            className="form-control"
            name="maxProfit"
            id="maxProfit"
            placeholder="0"
            onChange={handleChange}
            onBlur={handleBlur}
            value={values.maxProfit}
          />
          {errors.maxProfit && touched.maxProfit && (
            <Error>{errors.maxProfit}</Error>
          )}
        </div>
        <div className="col-md-6">
          <Label htmlFor="betDelay" className="form-label" isRequired={true}>
            Bet delay
          </Label>
          <input
            type="number"
            className="form-control"
            name="betDelay"
            id="betDelay"
            placeholder="0"
            onChange={handleChange}
            onBlur={handleBlur}
            value={values.betDelay}
          />
          {errors.betDelay && touched.betDelay && (
            <Error>{errors.betDelay}</Error>
          )}
        </div>
        <div className="col-md-12">
          <Label htmlFor="password" className="form-label" isRequired={true}>
            Transaction password
          </Label>
          <input
            type="password"
            className="form-control"
            name="password"
            id="password"
            placeholder="Enter password"
            onChange={handleChange}
            onBlur={handleBlur}
            value={values.password}
          />
          {errors.password && touched.password && (
            <Error>{errors.password}</Error>
          )}
        </div>
      </div>
      <Button type="submit" id="form-submit-btn" isHidden={true}>
        Submit
      </Button>
    </form>
  );
};

export default FancyLimitModal;
