import React from "react";
import { Button } from "../../../Components";

const SuspandModal = ({ rowData, handlePutRequest }) => {
  const handleSubmit = async (e) => {
    e.preventDefault();

    handlePutRequest(
      rowData,
      {
        id: "MS940896",
        name: "suspend",
        value: "SUSPENDED",
      },
      "marketStatus"
    );
  };
  return (
    <form onSubmit={handleSubmit}>
      <h5>Suspension Modal</h5>
      <h6>Do you really want to Suspend this Game? </h6>
      <Button type="submit" id="form-submit-btn" isHidden={true}>
        submit
      </Button>
    </form>
  );
};

export default SuspandModal;
