import { useFormik } from "formik";
import React from "react";

import { Button, Error, Label } from "../../../Components";
import { fancySettingSchema } from "../../../Schema/Game/FancySchema";
import { API_UPDATE_MARKETBYTYPE } from "../../../utils/api/ApiConstant";

const FancySettingModal = ({ rowData, handleShowHide, handlePutRequest }) => {
  const { values, touched, errors, handleChange, handleBlur, handleSubmit } =
    useFormik({
      initialValues: {
        maxStack: rowData?.fancySetting?.maxStack,
        minStack: rowData?.fancySetting?.minStack,
        maxProfit: rowData?.fancySetting?.maxProfit,
        betDelay: rowData?.fancySetting?.betDelay,
      },
      validationSchema: fancySettingSchema,
      onSubmit: (values) => {
        const payload = {
          ...rowData,
          fancySetting: { ...values },
        };
        const url = `${API_UPDATE_MARKETBYTYPE}/${rowData?.marketId}`;
        handlePutRequest({
          url,
          payload,
          modalRequest: true,
          updateRowData: true,
        });
      },
    });
  console.log("🚀 ~ FancySettingModal ~ errors:", errors);

  return (
    <form onSubmit={handleSubmit}>
      <div className="row">
        <div className="col-md-6">
          <Label htmlFor="maxProfit" className="form-label" isRequired={true}>
            Max Profit
          </Label>
          <input
            type="number"
            className="form-control"
            name="maxProfit"
            id="maxProfit"
            placeholder="Enter Max Profit"
            onChange={handleChange}
            onBlur={handleBlur}
            value={values.maxProfit}
            autoFocus={true}
          />
          {errors.maxProfit && touched.maxProfit && (
            <Error>{errors.maxProfit}</Error>
          )}
        </div>
        <div className="col-md-6">
          <Label htmlFor="betDelay" className="form-label" isRequired={true}>
            Bet Delay
          </Label>
          <input
            type="number"
            className="form-control"
            name="betDelay"
            id="betDelay"
            placeholder="Enter Bet Delay"
            onChange={handleChange}
            onBlur={handleBlur}
            value={values.betDelay}
          />
          {errors.betDelay && touched.betDelay && (
            <Error>{errors.betDelay}</Error>
          )}
        </div>
        <div className="col-md-6">
          <Label htmlFor="maxStack" className="form-label" isRequired={true}>
            Max stack
          </Label>
          <input
            type="number"
            className="form-control"
            name="maxStack"
            id="maxStack"
            placeholder="Enter Max stack"
            onChange={handleChange}
            onBlur={handleBlur}
            value={values.maxStack}
          />
          {errors.maxStack && touched.maxStack && (
            <Error>{errors.maxStack}</Error>
          )}
        </div>
        <div className="col-md-6">
          <Label htmlFor="minStack" className="form-label" isRequired={true}>
            Min Stack
          </Label>
          <input
            type="number"
            className="form-control"
            name="minStack"
            id="minStack"
            placeholder="Enter Min Stack"
            onChange={handleChange}
            onBlur={handleBlur}
            value={values.minStack}
          />
          {errors.minStack && touched.minStack && (
            <Error>{errors.minStack}</Error>
          )}
        </div>
      </div>

      <Button type="submit" id="form-submit-btn" isHidden={true}>
        Submit
      </Button>
    </form>
  );
};

export default FancySettingModal;
