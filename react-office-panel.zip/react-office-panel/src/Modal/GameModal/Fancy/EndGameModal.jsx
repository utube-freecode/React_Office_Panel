import { useFormik } from "formik";
import React from "react";

import { Button, Error, Label } from "../../../Components";
import { endGameSchema } from "../../../Schema/Game/FancySchema";
import { encryptPayload } from "../../../helper/common";
import { postAxios } from "../../../Services/commonService";
import { API_POST_SETTLEFANCY } from "../../../utils/api/ApiConstant";

const EndGameModal = ({ rowData, handleShowHide }) => {
  const { values, touched, errors, handleChange, handleBlur, handleSubmit } =
    useFormik({
      initialValues: {
        result: "",
        token: "",
      },
      validationSchema: endGameSchema,
      onSubmit: (values) => {
        const payload = {
          ...values,
          market_uniq_id: rowData?.fancyId,
          type: rowData?.marketType,
          token: encryptPayload(values?.token),
        };
        handleFormSubmit(payload);
      },
    });

  const handleFormSubmit = async (payload) => {
    const res = await postAxios(API_POST_SETTLEFANCY, payload);
    console.log("🚀 ~ handleFormSubmit ~ res:", res);
    if (res) {
      handleShowHide();
    }
  };

  return (
    <form onSubmit={handleSubmit}>
      <div className="row">
        <div className="col-md-6">
          <Label htmlFor="result" className="form-label" isRequired={true}>
            Result
          </Label>
          <input
            type="number"
            className="form-control"
            name="result"
            id="result"
            placeholder="Enter result"
            onChange={handleChange}
            onBlur={handleBlur}
            value={values.result}
            autoFocus={true}
          />
          {errors.result && touched.result && <Error>{errors.result}</Error>}
        </div>
        <div className="col-md-6">
          <Label htmlFor="token" className="form-label" isRequired={true}>
            Password
          </Label>
          <input
            type="password"
            className="form-control"
            name="token"
            id="token"
            placeholder="Enter password"
            onChange={handleChange}
            onBlur={handleBlur}
            value={values.token}
          />
          {errors.token && touched.token && <Error>{errors.token}</Error>}
        </div>
      </div>

      <Button type="submit" id="form-submit-btn" isHidden={true}>
        Submit
      </Button>
    </form>
  );
};

export default EndGameModal;
