import React from "react";
import { useFormik } from "formik";
import { limitMarketSchema } from "../../../Schema/Game/MarketSchema";
import { Error, Label } from "../../../Components";
import { API_UPDATE_MARKETBYTYPE } from "../../../utils/api/ApiConstant";

const LimitMarketModal = ({ rowData, handleShowHide, handlePutRequest }) => {
  const { values, touched, errors, handleChange, handleBlur, handleSubmit } =
    useFormik({
      initialValues: {
        minStack: rowData?.fancySetting?.minStack || 0,
        maxStack: rowData?.fancySetting?.maxStack || 0,
        maxProfit: rowData?.fancySetting?.maxProfit || 0,
        betDelay: rowData?.fancySetting?.betDelay || 0,
        maxOdds: rowData?.fancySetting?.maxOdds || 0,
        volume: rowData?.fancySetting?.volume || 0,
      },
      validationSchema: limitMarketSchema,
      onSubmit: async (values) => {
        const body = {
          ...rowData,
          fancySetting: {
            ...rowData?.fancySetting,
            minStack: values?.minStack,
            maxStack: values?.maxStack,
            maxProfit: values?.maxProfit,
            betDelay: values?.betDelay,
            maxOdds: values?.maxOdds,
            volume: values?.volume,
          },
        };

        const res = handlePutRequest(
          `${API_UPDATE_MARKETBYTYPE}`,
          rowData,
          body.fancySetting,
          "fancySetting"
        );

        if (res) {
          handleShowHide();
        }
      },
    });
  return (
    <form onSubmit={handleSubmit}>
      <div className="row">
        <div className="col-md-6">
          <Label htmlFor="minStack" className="form-label" isRequired={true}>
            Min Stack
          </Label>
          <input
            type="number"
            className="form-control"
            name="minStack"
            id="minStack"
            placeholder="0"
            onChange={handleChange}
            onBlur={handleBlur}
            value={values.minStack}
          />
          {errors.minStack && touched.minStack && (
            <Error>{errors.minStack}</Error>
          )}
        </div>
        <div className="col-md-6">
          <Label htmlFor="maxStack" className="form-label" isRequired={true}>
            Max Stack
          </Label>
          <input
            type="number"
            className="form-control"
            name="maxStack"
            id="maxStack"
            placeholder="0"
            onChange={handleChange}
            onBlur={handleBlur}
            value={values.maxStack}
          />
          {errors.maxStack && touched.maxStack && (
            <Error>{errors.maxStack}</Error>
          )}
        </div>

        <div className="col-md-6">
          <Label htmlFor="maxProfit" className="form-label" isRequired={true}>
            Max Profit
          </Label>
          <input
            type="number"
            className="form-control"
            name="maxProfit"
            id="maxProfit"
            placeholder="0"
            onChange={handleChange}
            onBlur={handleBlur}
            value={values.maxProfit}
          />
          {errors.maxProfit && touched.maxProfit && (
            <Error>{errors.maxProfit}</Error>
          )}
        </div>

        <div className="col-md-6">
          <Label htmlFor="betDelay" className="form-label" isRequired={true}>
            Bet Delay
          </Label>
          <input
            type="number"
            className="form-control"
            name="betDelay"
            id="betDelay"
            placeholder="0"
            onChange={handleChange}
            onBlur={handleBlur}
            value={values.betDelay}
          />
          {errors.betDelay && touched.betDelay && (
            <Error>{errors.betDelay}</Error>
          )}
        </div>

        <div className="col-md-6">
          <Label htmlFor="maxOdds" className="form-label" isRequired={true}>
            Max Odds
          </Label>
          <input
            type="number"
            className="form-control"
            name="maxOdds"
            id="maxOdds"
            placeholder="0"
            onChange={handleChange}
            onBlur={handleBlur}
            value={values.maxOdds}
          />
          {errors.maxOdds && touched.maxOdds && <Error>{errors.maxOdds}</Error>}
        </div>

        <div className="col-md-6">
          <Label htmlFor="volume" className="form-label" isRequired={true}>
            Volume
          </Label>
          <input
            type="number"
            className="form-control"
            name="volume"
            id="volume"
            placeholder="0"
            onChange={handleChange}
            onBlur={handleBlur}
            value={values.volume}
          />
          {errors.volume && touched.volume && <Error>{errors.volume}</Error>}
        </div>
      </div>
      <button type="submit" id="form-submit-btn" hidden>
        Submit
      </button>
    </form>
  );
};

export default LimitMarketModal;
