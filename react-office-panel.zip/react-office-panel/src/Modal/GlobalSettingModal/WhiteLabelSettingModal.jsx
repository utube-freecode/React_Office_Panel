import React, { useState } from "react";
import Tab from "react-bootstrap/Tab";
import Tabs from "react-bootstrap/Tabs";
import { useQuery } from "@tanstack/react-query";

import {
  WhiteLabelBookmakerSettings,
  WhiteLabelCasinoLiveSettings,
  WhiteLabelCasinoSettings,
  WhiteLabelCupSettings,
  WhiteLabelFancyConfigureSettings,
  WhiteLabelFancySettings,
  WhiteLabelLineConfigureSettings,
  WhiteLabelLineMarketSettings,
  WhiteLabelMatchOddsSettings,
} from "../../Components";
import {
  API_COMMON_GAME_SETTING,
  API_GET_ALL_SETTINGS,
} from "../../utils/api/ApiConstant";
import { getAxiosDGServer } from "../../Services/DgService";

const WhiteLabelSettingModal = () => {
  const [activeKey, setActiveKey] = useState("CupSettings");

  const { data: allSettingData } = useQuery({
    queryKey: ["allSettingData"],
    queryFn: async () => await getAxiosDGServer(API_GET_ALL_SETTINGS, {}),
    staleTime: 30000,
  });
  const { data: casinoData } = useQuery({
    queryKey: ["casinoData"],
    queryFn: async () =>
      await getAxiosDGServer(`${API_COMMON_GAME_SETTING}/casino`, {}),
    staleTime: 30000,
  });
  console.log("🚀  ~ allSettingData:", allSettingData);
  console.log("🚀 ~ casinoData:", casinoData);

  const renderContent = () => {
    switch (activeKey) {
      case "CupSettings":
        return <WhiteLabelCupSettings />;
      case "CasinoLiveSettings":
        return <WhiteLabelCasinoLiveSettings />;
      case "MatchOddsSettings":
        return <WhiteLabelMatchOddsSettings />;
      case "FancySettings":
        return <WhiteLabelFancySettings />;
      case "BookmakerSettings":
        return <WhiteLabelBookmakerSettings />;
      case "FancyConfigureSettings":
        return <WhiteLabelFancyConfigureSettings />;
      case "LineMarketSettings":
        return <WhiteLabelLineMarketSettings />;
      case "LineConfigureSettings":
        return <WhiteLabelLineConfigureSettings />;
      case "CasinoSettings":
        return <WhiteLabelCasinoSettings />;
      default:
        return null;
    }
  };

  return (
    <>
      <div className="card-body">
        <Tabs
          id="controlled-tab-example game-setting-flex"
          activeKey={activeKey}
          onSelect={(k) => setActiveKey(k)}
          className="mb-3 d-flex"
        >
          <Tab eventKey="CupSettings" title="Cup Settings" />
          <Tab eventKey="CasinoLiveSettings" title="Casino Live Settings" />
          <Tab eventKey="MatchOddsSettings" title="Match Odds Settings" />
          <Tab eventKey="FancySettings" title="Fancy Settings" />
          <Tab eventKey="BookmakerSettings" title="Bookmaker Settings" />
          <Tab
            eventKey="FancyConfigureSettings"
            title="Fancy Configure Settings"
          />
          <Tab eventKey="LineMarketSettings" title="Line Market Settings" />
          <Tab
            eventKey="LineConfigureSettings"
            title="Line Configure Settings"
          />
          <Tab eventKey="CasinoSettings" title="Casino Settings" />
        </Tabs>
        {/* {renderContent()} */}
      </div>
    </>
  );
};

export default WhiteLabelSettingModal;
