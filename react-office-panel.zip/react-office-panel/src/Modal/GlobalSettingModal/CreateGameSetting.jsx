import React from "react";
import { useFormik } from "formik";

import { useFilteredData } from "../../Hooks";
import { Button, CustomSelect, Error, Label } from "../../Components";
import { postAxios } from "../../Services/commonService";
import { API_COMMON_GAME_SETTING } from "../../utils/api/ApiConstant";

const CreateGameSetting = ({ handleShowHide }) => {
  const validate = (values) => {
    const errors = {};
    if (!values.sports) {
      errors.sports = "Sports is required";
    }
    return errors;
  };

  const { values, touched, errors, handleSubmit, setFieldValue } = useFormik({
    initialValues: {
      sports: null,
    },
    validate,
    onSubmit: (values) => {
      const payload = {
        sport: {
          id: values.sports.value,
          name: values.sports.label,
        },
        volume: 0,
        minStack: 0,
        maxStack: 0,
        maxProfit: 0,
        maxLoss: 0,
        betDelay: 0,
        minOdds: 0,
        maxOdds: 0,
        preInPlayProfit: 0,
        preInPlayStack: 0,
      };
      handleFormSubmit(payload);
    },
  });

  const { sportOptions } = useFilteredData({
    sport: null,
  });

  const handleFormSubmit = async (payload) => {
    const res = await postAxios(API_COMMON_GAME_SETTING, payload);
    if (res) {
      handleShowHide();
    }
  };

  return (
    <form onSubmit={handleSubmit}>
      <div
        className="row"
        style={{ paddingRight: "11px", paddingLeft: "11px" }}
      >
        <div className="col-md-12">
          <Label htmlFor="sports" className="form-label">
            Sports
          </Label>
          <CustomSelect
            options={sportOptions}
            value={values.sports}
            onChange={(selectedOption) =>
              setFieldValue("sports", selectedOption)
            }
            placeholder="Select Sports"
            isMulti={false}
          />
          {errors.sports && touched.sports && <Error>{errors.sports}</Error>}
        </div>
      </div>
      <Button type="submit" id="form-submit-btn" isHidden={true}></Button>
    </form>
  );
};

export default CreateGameSetting;
