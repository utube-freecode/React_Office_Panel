import React, { useMemo } from "react";
import { DataTable } from "../../Components";
import { useQuery } from "@tanstack/react-query";
import { API_VIEW_BET } from "../../utils/api/ApiConstant";
import { postAxiosDGServer } from "../../Services/DgService";

const ViewBetModal = ({ rowData, handleShowHide }) => {
  const { isLoading, data: viewBetData } = useQuery({
    queryKey: ["viewBetApiData"],
    queryFn: async () => await postAxiosDGServer(API_VIEW_BET, rowData),
  });

  const fetchData = () => {
    if (!viewBetData) return { data: [], pages: 0 };

    return {
      data: viewBetData?.docs || [],
      pages: viewBetData.pages || 0,
    };
  };

  const columns = useMemo(
    () => [
      {
        accessorKey: "fancyName",
        header: "username",
      },
      {
        accessorKey: "match.name",
        header: "match",
      },
      {
        accessorKey: "result",
        header: "result",
      },
      {
        accessorKey: "demo",
        header: "preresult",
      },
      {
        accessorKey: "marketType",
        header: "type",
      },
    ],
    []
  );

  return (
    <>
      <DataTable
        columns={columns}
        fetchData={fetchData}
        isSearchable={false}
        isPagination={false}
        isPageSize={false}
        isLoading={isLoading}
      />
    </>
  );
};

export default ViewBetModal;
