import { useFormik } from "formik";
import React from "react";
import { resultSchema } from "../../../Schema/Report/OpenMarketSchemas";
import { encryptPayload } from "../../../helper/common";
import { postAxios } from "../../../Services/commonService";
import {
  API_POST_MATCHSETTLED,
  API_POST_SETTLEBOOKMAKER,
  API_POST_SETTLEFANCY,
} from "../../../utils/api/ApiConstant";

const ResultModal = ({ handleShowHide, rowData }) => {
  const {
    values,
    touched,
    errors,
    handleBlur,
    handleChange,
    handleSubmit,
    setFieldValue,
  } = useFormik({
    initialValues: {
      password: "",
      result: null,
    },
    validationSchema: resultSchema,
    onSubmit: async (values) => {
      if (rowData?.marketType === "Match Odds") {
        const body = {
          teamId: values?.result?.selectionId,
          matchId: rowData?.marketId,
          matchName: values?.result?.runnerName,
          type: rowData?.marketType,
          marketId: rowData?.marketId,
          token: encryptPayload(values?.password),
        };

        const res = await postAxios(`${API_POST_MATCHSETTLED}`, body);

        if (res) {
          handleShowHide();
        }
      } else if (rowData?.marketType === "Bookmaker") {
        const body = {
          teamId: values?.result?.selectionId,
          matchId: rowData?.marketId,
          matchName: values?.result?.runnerName,
          type: rowData?.marketType,
          marketId: rowData?.marketId,
          token: encryptPayload(values?.password),
        };

        const res = await postAxios(`${API_POST_SETTLEBOOKMAKER}`, body);

        if (res) {
          handleShowHide();
        }
      } else {
        const body = {
          market_uniq_id: rowData?.fancyId,
          type: rowData?.marketType,
          result: values?.result,
          token: encryptPayload(values?.password),
        };

        const res = await postAxios(`${API_POST_SETTLEFANCY}`, body);

        if (res) {
          handleShowHide();
        }
      }
    },
  });

  const getMarketName = () => {
    if (rowData?.marketType === "Fancy") return rowData?.fancyName;
    if (rowData?.marketType === "Bookmaker") return rowData?.displayName;
    if (rowData?.marketType === "Match Odds") return rowData?.match?.name;
    return null;
  };

  return (
    <form onSubmit={handleSubmit}>
      <div className="row m-0 p-0">
        <h6>Market Type: {rowData?.marketType}</h6>
        <h6>Market Name: {getMarketName()}</h6>
        {rowData?.marketType !== "Match Odds" && (
          <h6>Match Name: {rowData?.match?.name}</h6>
        )}

        {rowData?.marketType === "Fancy" ? (
          <div className="col-md-6 m-0 p-1">
            <label htmlFor="result" className="form-label">
              Result
            </label>
            <input
              type="text"
              className="form-control"
              name="result"
              id="result"
              placeholder="Enter result"
              onChange={handleChange}
              value={values.result}
              onBlur={handleBlur}
              required
            />
            {touched.result && errors.result && (
              <div className="text-danger">{errors.result}</div>
            )}
          </div>
        ) : (
          <div>
            <h5>Select</h5>
            {rowData?.runners?.map((item, index) => (
              <div className="form-check" key={index}>
                <input
                  className="form-check-input"
                  type="radio"
                  name="result"
                  id={`flexRadioDefault${index}`}
                  onChange={() => setFieldValue("result", item)}
                  checked={values.result?.runnerName === item?.runnerName}
                />

                <label
                  className="form-check-label"
                  htmlFor={`flexRadioDefault${index}`}
                >
                  {item?.runnerName}
                </label>
              </div>
            ))}
          </div>
        )}
        <div className="col-md-6 m-0 p-1">
          <label htmlFor="password" className="form-label">
            Password
          </label>
          <input
            type="password"
            className="form-control"
            name="password"
            id="password"
            placeholder="Enter password"
            onChange={handleChange}
            value={values.password}
            onBlur={handleBlur}
          />
          {touched.password && errors.password && (
            <div className="text-danger">{errors.password}</div>
          )}
        </div>
        <button type="submit" id="form-submit-btn" hidden>
          Submit
        </button>
      </div>
    </form>
  );
};

export default ResultModal;
