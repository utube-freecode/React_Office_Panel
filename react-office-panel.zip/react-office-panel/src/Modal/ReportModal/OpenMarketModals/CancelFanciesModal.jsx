import React from "react";
import { useDispatch } from "react-redux";
import { useFormik } from "formik";

import { Button, DateRangePicker } from "../../../Components";
import { postAxios } from "../../../Services/commonService";
import { API_ADD_MARKET } from "../../../utils/api/ApiConstant";
import { uiActions } from "../../../store/ui/ui-slice";
import { dateFormat } from "../../../helper/common";

const CancelFanciesModal = ({ handleShowHide }) => {
  const dispatch = useDispatch();
  const { values, handleSubmit, setFieldValue } = useFormik({
    initialValues: {
      startDate: null,
      endDate: null,
    },
    enableReinitialize: true,
    onSubmit: async (values) => {
      dispatch(uiActions.setFormSubmitLoading(true));
      const startDate = values?.startDate
        ? dateFormat(values?.startDate).formattedDate
        : null;
      const endDate = values?.endDate
        ? dateFormat(values?.endDate).formattedDate
        : null;
      const payload = {
        ...values,
        startDate,
        endDate,
      };

      handleFormSubmit(payload);
    },
  });

  const handleFormSubmit = async (payload) => {
    const url = `${API_ADD_MARKET}/bulkCancelGame`;
    const res = await postAxios(url, payload);
    dispatch(uiActions.setFormSubmitLoading(false));

    if (res) {
      handleShowHide();
    }
  };

  return (
    <form className="row" onSubmit={handleSubmit}>
      <DateRangePicker
        values={values}
        setFieldValue={setFieldValue}
        className="col-md-6"
        startMinDate={null}
      />

      <Button type="submit" id="form-submit-btn" isHidden={true}>
        Submit
      </Button>
    </form>
  );
};

export default CancelFanciesModal;
