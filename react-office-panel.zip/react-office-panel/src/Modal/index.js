import CheckPasswordModal from "./CheckPasswordModal";
import CommonModal from "./CommonModal";
import ConfimationModal from "./ConfimationModal";

// Game Modals
import SportModal from "./GameModal/SportModal";

import TournamentModal from "./GameModal/tournament/TournamentModal";
import LimitModal from "./GameModal/tournament/LimitModal";

//fancy
import FancyModal from "./GameModal/Fancy/FancyModal";
import ImportFancyModal from "./GameModal/Fancy/ImportFancyModal";
import SuspandModal from "./GameModal/Fancy/SuspandModal";
import FancyLimitModal from "./GameModal/Fancy/FancyLimitModal";
import EndGameModal from "./GameModal/Fancy/EndGameModal";
import FancyConfigureModal from "./GameModal/Fancy/FancyConfigureModal";
import FancySettingModal from "./GameModal/Fancy/FancySettingModal";

// bookmaker
import AddBookmakerModal from "./GameModal/Bookmaker/AddBookmakerModal";
import LimitBookmakerModal from "./GameModal/Bookmaker/LimitBookmakerModal";
import BookmakerMessage from "./GameModal/Bookmaker/BookmakerMessage";
import BookmakerSetting from "./GameModal/Bookmaker/BookmakerSetting";

import UploadModal from "./GameModal/UploadModal";
import MarketModal from "./GameModal/MarketModal";
import Message from "./GameModal/Message";

import AddCommentryModal from "./GameModal/Match/AddCommentryModal";
import LiveTv from "./GameModal/Match/LiveTv";
import AddScoreCardId from "./GameModal/Match/AddScoreCardId";
import LimitMarketModal from "./GameModal/Market/LimitMarketModal";

// report
import ViewBetModal from "./ReportModal/ViewBetModal";
import ResultModal from "./ReportModal/OpenMarketModals/ResultModal";
import CancelFanciesModal from "./ReportModal/OpenMarketModals/CancelFanciesModal";

// RoleManageModals
import AddEditUser from "./RoleManageModals/AddEditUser";
import ResetPassword from "./RoleManageModals/ResetPassword";
import AddEditModuleAccessModal from "./RoleManageModals/AddEditModuleAccessModal";
import RoleDetailModal from "./RoleManageModals/RoleDetailModal";
import AddGameSettings from "./RoleManageModals/AddGameSettings";

// global setting
import CreateGameSetting from "./GlobalSettingModal/CreateGameSetting";
import WhiteLabelSettingModal from "./GlobalSettingModal/WhiteLabelSettingModal";

// configeration
import LiveTvModal from "./ConfigurationModal/LiveTvModal";
import ApiSettingModal from "./ConfigurationModal/ApiSettingModal";
import ImportConfigModal from "./ConfigurationModal/ImportConfigModal";

export {
  CommonModal,
  ImportConfigModal,
  SportModal,
  UploadModal,
  CheckPasswordModal,
  ConfimationModal,
  TournamentModal,
  LimitModal,
  AddGameSettings,
  MarketModal,
  ResetPassword,
  AddEditModuleAccessModal,
  LiveTv,
  AddScoreCardId,
  Message,
  LimitMarketModal,
  AddCommentryModal,
  FancyModal,
  ImportFancyModal,
  AddEditUser,
  SuspandModal,
  FancyLimitModal,
  AddBookmakerModal,
  LimitBookmakerModal,
  ViewBetModal,
  ResultModal,
  CancelFanciesModal,
  RoleDetailModal,
  CreateGameSetting,
  WhiteLabelSettingModal,
  LiveTvModal,
  ApiSettingModal,
  EndGameModal,
  FancyConfigureModal,
  FancySettingModal,
  BookmakerSetting,
  BookmakerMessage,
};
