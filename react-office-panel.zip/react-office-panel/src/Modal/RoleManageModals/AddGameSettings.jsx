import React from "react";
import { useFilteredData } from "../../Hooks";
import { CustomSelect, Error, Label } from "../../Components";
import { useFormik } from "formik";
import { postAxios } from "../../Services/commonService";
import { API_GET_USERGLOBALSETTINGS } from "../../utils/api/ApiConstant";

const AddGameSettings = ({ handleShowHide }) => {
  const {
    values,
    touched,
    errors,
    handleBlur,
    handleChange,
    handleSubmit,
    setFieldValue,
  } = useFormik({
    initialValues: {
      sports: null,
    },
    onSubmit: async (values) => {
      const body = {
        sport: {
          id: values?.sports?.value,
          name: values?.sports?.label,
        },
        minStack: 0,
        maxStack: 0,
        maxProfit: 0,
        maxLoss: 0,
        betDelay: 0,
        minOdds: 0,
        maxOdds: 0,
        preInPlayProfit: 0,
        preInPlayStack: 0,
      };

      const res = await postAxios(API_GET_USERGLOBALSETTINGS, body);

      if (res) {
        handleShowHide();
      }
    },
  });

  const { sportOptions } = useFilteredData({});
  return (
    <form onSubmit={handleSubmit}>
      <div className="row">
        <div className="col-md-6">
          <Label htmlFor="sports" className="form-label" isRequired={true}>
            Sports
          </Label>
          <CustomSelect
            options={sportOptions}
            value={values.sports}
            onChange={(selectedOption) =>
              setFieldValue("sports", selectedOption)
            }
            placeholder="Select Sports"
            isMulti={false}
            required={true}
          />
          {errors.sports && touched.sports && <Error>{errors.sports}</Error>}
        </div>
      </div>
      <button type="submit" id="form-submit-btn" hidden>
        submit
      </button>
    </form>
  );
};

export default AddGameSettings;
