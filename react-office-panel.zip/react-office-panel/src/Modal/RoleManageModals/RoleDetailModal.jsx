import React from "react";
import { ActiveInactiveBadge } from "../../Components";

const defaultModuleState = {
  selectAllAccess: false,
  viewAccess: false,
  createAccess: false,
  updateAccess: false,
  deleteAccess: false,
  allowBet: false,
  applyCommission: false,
  limit: false,
  message: false,
  suspended: false,
  enterRate: false,
  commentary: false,
  liveTv: false,
  result: false,
};

const RoleDetailModal = ({ rowData }) => {
  if (!rowData || !rowData.modules || rowData.modules.length === 0) {
    return <div>No data available</div>;
  }

  return (
    <div className="table-responsive">
      <table
        style={{ borderCollapse: "collapse", width: "100%" }}
        className="table table-striped table-auto"
      >
        <thead className="table-light">
          <tr>
            <th className="text-start">Tab Name</th>
            {Object.keys(defaultModuleState).map((key) => (
              <th key={key} className="text-start">
                {key.replace(/([A-Z])/g, " $1").toLowerCase()}
              </th>
            ))}
          </tr>
        </thead>
        <tbody>
          {rowData.modules.map((module, i) => (
            <tr key={i}>
              <td>{module.moduleName?.toUpperCase()}</td>
              {Object.keys(defaultModuleState).map((key) => (
                <td key={key}>
                  <ActiveInactiveBadge getValue={() => module[key] || false} />
                </td>
              ))}
            </tr>
          ))}
        </tbody>
      </table>
    </div>
  );
};

export default RoleDetailModal;
