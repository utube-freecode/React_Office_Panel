import { useFormik } from "formik";
import React from "react";
import { Label } from "../../Components";
import { postAxios, putAxios } from "../../Services/commonService";
import { API_GET_MODULES } from "../../utils/api/ApiConstant";

const AddEditModuleAccessModal = ({ rowData, handleShowHide, isEdit }) => {
  const { values, handleChange, handleSubmit, errors, touched, setFieldValue } =
    useFormik({
      initialValues: {
        moduleName: rowData?.moduleName || "",
        alias: rowData?.alias || "",
        createAccess: rowData?.createAccess || false,
        viewAccess: rowData?.viewAccess || false,
        updateAccess: rowData?.updateAccess || false,
        deleteAccess: rowData?.deleteAccess || false,
        allowBet: rowData?.allowBet || false,
        applyCommission: rowData?.applyCommission || false,
        limit: rowData?.limit || false,
        message: rowData?.message || false,
        suspended: rowData?.suspended || false,
        enterRate: rowData?.enterRate || false,
        commentary: rowData?.commentary || false,
        liveTv: rowData?.liveTv || false,
        result: rowData?.result || false,
      },
      onSubmit: async (values) => {
        if (isEdit) {
          const res = putAxios(`${API_GET_MODULES}/${rowData?._id}`, values);

          if (res) {
            handleShowHide();
          }
        } else {
          const res = postAxios(API_GET_MODULES, values);
          if (res) {
            handleShowHide();
          }
        }
      },
    });
  return (
    <form onSubmit={handleSubmit} autoComplete="off">
      <div className="row">
        <div className="col-md-6">
          <Label htmlFor="moduleName" className="form-label" isRequired={true}>
            Module Name
          </Label>
          <input
            type="text"
            className="form-control"
            name="moduleName"
            id="moduleName"
            placeholder="Enter Module Name"
            onChange={handleChange}
            value={values.moduleName}
            required
          />
        </div>
        <div className="col-md-6">
          <Label htmlFor="alias" className="form-label" isRequired={true}>
            Alias
          </Label>
          <input
            type="text"
            className="form-control"
            name="alias"
            id="alias"
            placeholder="Enter Alias"
            onChange={handleChange}
            value={values.alias}
            required
          />
        </div>
      </div>
      <div className="row mt-2">
        <div className="col-lg-3 col-6 m-0 p-1">
          <Label htmlFor="createAccess" className="form-label">
            Add Access ?
          </Label>
          <div className="form-check form-switch form-switch-success">
            <input
              className="form-check-input"
              type="checkbox"
              name="createAccess"
              id="createAccess"
              checked={values?.createAccess}
              onChange={handleChange}
              value={values?.createAccess}
            />
          </div>
        </div>
        <div className="col-lg-3 col-6 m-0 p-1">
          <Label htmlFor="viewAccess" className="form-label">
            View Access ?
          </Label>
          <div className="form-check form-switch form-switch-success">
            <input
              className="form-check-input"
              type="checkbox"
              name="viewAccess"
              id="viewAccess"
              checked={values?.viewAccess}
              onChange={handleChange}
              value={values?.viewAccess}
            />
          </div>
        </div>
        <div className="col-lg-3 col-6 m-0 p-1">
          <Label htmlFor="updateAccess" className="form-label">
            Edit Access ?
          </Label>
          <div className="form-check form-switch form-switch-success">
            <input
              className="form-check-input"
              type="checkbox"
              name="updateAccess"
              id="updateAccess"
              checked={values?.updateAccess}
              onChange={handleChange}
              value={values?.updateAccess}
            />
          </div>
        </div>
        <div className="col-lg-3 col-6 m-0 p-1">
          <Label htmlFor="deleteAccess" className="form-label">
            Delete Access ?
          </Label>
          <div className="form-check form-switch form-switch-success">
            <input
              className="form-check-input"
              type="checkbox"
              name="deleteAccess"
              id="deleteAccess"
              checked={values?.deleteAccess}
              onChange={handleChange}
              value={values?.deleteAccess}
            />
          </div>
        </div>

        <div className="col-lg-3 col-6 m-0 p-1">
          <Label htmlFor="allowBet" className="form-label">
            Allow Bet ?
          </Label>
          <div className="form-check form-switch form-switch-success">
            <input
              className="form-check-input"
              type="checkbox"
              name="allowBet"
              id="allowBet"
              checked={values?.allowBet}
              onChange={handleChange}
              value={values?.allowBet}
            />
          </div>
        </div>
        <div className="col-lg-3 col-6 m-0 p-1">
          <Label htmlFor="applyCommission" className="form-label">
            Apply Commission ?
          </Label>
          <div className="form-check form-switch form-switch-success">
            <input
              className="form-check-input"
              type="checkbox"
              name="applyCommission"
              id="applyCommission"
              checked={values?.applyCommission}
              onChange={handleChange}
              value={values?.applyCommission}
            />
          </div>
        </div>
        <div className="col-lg-3 col-6 m-0 p-1">
          <Label htmlFor="limit" className="form-label">
            Limit Access ?
          </Label>
          <div className="form-check form-switch form-switch-success">
            <input
              className="form-check-input"
              type="checkbox"
              name="limit"
              id="limit"
              checked={values?.limit}
              onChange={handleChange}
              value={values?.limit}
            />
          </div>
        </div>
        <div className="col-lg-3 col-6 m-0 p-1">
          <Label htmlFor="message" className="form-label">
            Message Access ?
          </Label>
          <div className="form-check form-switch form-switch-success">
            <input
              className="form-check-input"
              type="checkbox"
              name="message"
              id="message"
              checked={values?.message}
              onChange={handleChange}
              value={values?.message}
            />
          </div>
        </div>

        <div className="col-lg-3 col-6 m-0 p-1">
          <Label htmlFor="suspended" className="form-label">
            Suspended Access ?
          </Label>
          <div className="form-check form-switch form-switch-success">
            <input
              className="form-check-input"
              type="checkbox"
              name="suspended"
              id="suspended"
              checked={values?.suspended}
              onChange={handleChange}
              value={values?.suspended}
            />
          </div>
        </div>
        <div className="col-lg-3 col-6 m-0 p-1">
          <Label htmlFor="enterRate" className="form-label">
            Enter Rate ?
          </Label>
          <div className="form-check form-switch form-switch-success">
            <input
              className="form-check-input"
              type="checkbox"
              name="enterRate"
              id="enterRate"
              checked={values?.enterRate}
              onChange={handleChange}
              value={values?.enterRate}
            />
          </div>
        </div>
        <div className="col-lg-3 col-6 m-0 p-1">
          <Label htmlFor="commentary" className="form-label">
            Commentary ?
          </Label>
          <div className="form-check form-switch form-switch-success">
            <input
              className="form-check-input"
              type="checkbox"
              name="commentary"
              id="commentary"
              checked={values?.commentary}
              onChange={handleChange}
              value={values?.commentary}
            />
          </div>
        </div>
        <div className="col-lg-3 col-6 m-0 p-1">
          <Label htmlFor="result" className="form-label">
            Result Access ?
          </Label>
          <div className="form-check form-switch form-switch-success">
            <input
              className="form-check-input"
              type="checkbox"
              name="result"
              id="result"
              checked={values?.result}
              onChange={handleChange}
              value={values?.result}
            />
          </div>
        </div>
      </div>
      <button type="submit" id="form-submit-btn" hidden>
        submit
      </button>
    </form>
  );
};

export default AddEditModuleAccessModal;
