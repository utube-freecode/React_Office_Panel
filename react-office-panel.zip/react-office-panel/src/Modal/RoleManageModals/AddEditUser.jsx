import { useFormik } from "formik";
import React from "react";
import { CustomSelect, Error, Label } from "../../Components";
import { useQuery } from "@tanstack/react-query";
import {
  getAxiosForAuthResponse,
  postAxios,
  putAxios,
} from "../../Services/commonService";
import { API_USER, API_USER_ROLES } from "../../utils/api/ApiConstant";
import { AddUserSchema } from "../../Schema/RoleManagement/UserSchema";

const AddEditUser = ({ rowData, handleShowHide, isEdit }) => {
  const { values, handleChange, handleSubmit, errors, touched, setFieldValue } =
    useFormik({
      initialValues: {
        name: rowData?.name || "",
        username: rowData?.username || "",
        password: rowData?.password || "",
        role: rowData
          ? {
              value: rowData?._id,
              label: rowData?.role?.role_name,
              modulesAccessIds: rowData?.modulesAccessIds,
              description: rowData?.role?.description,
            }
          : null,
      },
      validationSchema: AddUserSchema,
      onSubmit: async (values) => {
        if (isEdit) {
          const body = {
            ...rowData,
            name: values?.name,
            role: {
              _id: values?.role?.value,
              role_name: values?.role?.label,
              description: values?.role?.description,
              __v: 0,
              modules: values?.role?.modulesAccessIds,
            },
            modulesAccessIds: values?.role?.modulesAccessIds,
          };
          const res = await putAxios(`${API_USER}/${rowData?._id}`, body);
          if (res) {
            handleShowHide();
          }
        } else {
          const body = {
            name: values?.name,
            username: values?.username,
            password: values?.password,
            role: values?.role?.value,
            parent_user_id: "5e3d4ed0d993f92c9c62d79c",
            userType: "STAFF",
            modulesAccessIds: values?.role?.modulesAccessIds,
          };
          const res = await postAxios(API_USER, body);
          if (res) {
            handleShowHide();
          }
        }
      },
    });

  const { data: roles } = useQuery({
    queryKey: ["roles"],
    queryFn: async () =>
      await getAxiosForAuthResponse(API_USER_ROLES, {
        page: 1,
        limit: -1,
      }),
  });

  const rolesOption =
    roles?.docs?.map((item) => ({
      value: item?._id,
      label: item?.role_name,
      modulesAccessIds: item?.modules,
      description: item?.description,
    })) || [];

  return (
    <form onSubmit={handleSubmit} autoComplete="off">
      <div className="row">
        <div className="col-md-6">
          <Label htmlFor="name" className="form-label" isRequired={true}>
            Name
          </Label>
          <input
            type="text"
            className="form-control"
            name="name"
            id="name"
            placeholder="Enter Name"
            onChange={handleChange}
            value={values.name}
          />
          {errors.name && touched.name && <Error>{errors.name}</Error>}
        </div>
        <div className="col-md-6">
          <Label htmlFor="name" className="form-label" isRequired={true}>
            Username
          </Label>
          <input
            type="text"
            className="form-control"
            name="username"
            id="username"
            placeholder="Enter Username"
            onChange={handleChange}
            value={values.username}
            disabled={isEdit}
          />
          {errors.username && touched.username && (
            <Error>{errors.username}</Error>
          )}
        </div>
        {!isEdit && (
          <div className="col-md-6">
            <Label htmlFor="name" className="form-label" isRequired={true}>
              Password
            </Label>
            <input
              type="text"
              className="form-control"
              name="password"
              id="password"
              placeholder="Enter Password"
              onChange={handleChange}
              value={values.password}
            />
            {errors.password && touched.password && (
              <Error>{errors.password}</Error>
            )}
          </div>
        )}
        <div className="col-md-6">
          <Label htmlFor="role" className="form-label" isRequired={true}>
            Select Role
          </Label>
          <CustomSelect
            options={rolesOption}
            value={values.role}
            onChange={(selectedOption) => setFieldValue("role", selectedOption)}
            placeholder="Select Role"
            isMulti={false}
          />
          {errors.role && touched.role && <Error>{errors.role}</Error>}
        </div>
      </div>
      <button type="submit" id="form-submit-btn" hidden>
        submit
      </button>
    </form>
  );
};

export default AddEditUser;
