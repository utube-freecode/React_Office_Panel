import { useFormik } from "formik";
import React from "react";
import { Error, Label } from "../../Components";
import { PasswordSchema } from "../../Schema/RoleManagement/UserSchema";
import { putAxios } from "../../Services/commonService";
import { API_UPDATE_PASSWORD } from "../../utils/api/ApiConstant";

const ResetPassword = ({ rowData, handleShowHide }) => {
  const { values, handleChange, handleSubmit, errors, touched } = useFormik({
    initialValues: {
      password: "",
    },
    validationSchema: PasswordSchema,
    onSubmit: async (values) => {
      const body = {
        id: rowData?._id,
        password: values?.password,
      };

      const res = await putAxios(
        `${API_UPDATE_PASSWORD}/${rowData?._id}`,
        body
      );
      console.log("res", res);
      if (res) {
        handleShowHide();
      }
    },
  });

  return (
    <form onSubmit={handleSubmit} autoComplete="off">
      <div className="row">
        <div className="col-md-6">
          <Label htmlFor="name" className="form-label" isRequired={true}>
            Password
          </Label>
          <input
            type="text"
            className="form-control"
            name="password"
            id="password"
            placeholder="Enter Password"
            onChange={handleChange}
            value={values.password}
          />
          {errors.password && touched.password && (
            <Error>{errors.password}</Error>
          )}
        </div>
      </div>
      <button type="submit" id="form-submit-btn" hidden>
        submit
      </button>
    </form>
  );
};

export default ResetPassword;
