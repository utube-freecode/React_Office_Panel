import React, { memo } from "react";
import { Modal } from "react-bootstrap";

import { Button, Loading } from "../Components";
import { useSelector } from "react-redux";

const CommonModal = ({
  children,
  isShow,
  handleShowHide,
  modalTitle,
  isFooter = true,
}) => {
  const { isLoading, isFormLoading } = useSelector((state) => state.ui);
  const handleSubmitClick = () => {
    const submiBtn = document.querySelector("#form-submit-btn");
    if (submiBtn && !isFormLoading) {
      submiBtn.click();
    }
  };

  const handleCustomClose = () => {
    const modal = document.getElementById("commonModal");
    modal.classList.remove("show");
    modal.removeAttribute("style");
  };

  return (
    <Modal
      show={isShow}
      onHide={handleShowHide}
      backdrop="static"
      keyboard={false}
      size="lg"
      centered
    >
      <Modal.Header closeButton>
        <Modal.Title>{modalTitle}</Modal.Title>
      </Modal.Header>
      <Modal.Body>{children}</Modal.Body>
      {isFooter && (
        <Modal.Footer>
          <Button className="btn-outline-danger" onClick={handleShowHide}>
            Close
          </Button>
          <Button
            className="btn-primary btn-md"
            onClick={handleSubmitClick}
            isDisabled={isFormLoading}
          >
            {/* {!isFormLoading ? "Save Changes" : <Loading size={15} />} */}
            Save Changes
          </Button>
        </Modal.Footer>
      )}
    </Modal>
  );
};

export default memo(CommonModal);
