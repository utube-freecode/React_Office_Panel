import { useFormik } from "formik";
import React from "react";
import { getAxiosImportServer } from "../../Services/importService";
import {
  API_ADD_MARKET,
  API_ADD_MATCH,
  API_POST_SPORT,
  API_POST_TOURNAMENT,
  IMPORT_GET_ALLDATA,
} from "../../utils/api/ApiConstant";
import { Button } from "../../Components";
import { postAxios } from "../../Services/commonService";

const ImportConfigModal = ({ rowData, handleShowHide }) => {
  const {
    values,
    touched,
    errors,
    handleBlur,
    handleChange,
    handleSubmit,
    setFieldValue,
  } = useFormik({
    initialValues: {
      type: "",
    },
    // validationSchema: resultSchema,
    onSubmit: async (values) => {
      const matchData = await getAxiosImportServer(
        `${IMPORT_GET_ALLDATA}/${rowData?.rowData?.marketId}/${rowData?.match?.event?.id}/${rowData?.tournament?.competition?.id}/${rowData?.sport?.eventType?.id}`,
        {}
      );

      if (matchData) {
        const bodySport = {
          id: matchData[0]?.result[0]?.eventType?.id,
          name: matchData[0]?.result[0]?.eventType?.name,
          type: values?.type,
        };
        const resSport = await postAxios(API_POST_SPORT, bodySport);

        const bodyTournament = {
          id: matchData[0]?.result[0]?.competition?.id,
          name: matchData[0]?.result[0]?.competition?.id,
          sport: matchData[0]?.result[0]?.eventType,
        };
        const resTournament = await postAxios(
          API_POST_TOURNAMENT,
          bodyTournament
        );

        const bodyMatch = {
          id: matchData[0]?.result[0]?.event?.id,
          name: matchData[0]?.result[0]?.event?.name,
          countryCode: matchData[0]?.result[0]?.event?.countryCode,
          timezone: matchData[0]?.result[0]?.event?.timezone,
          openDate: matchData[0]?.result[0]?.event?.openDate,
          tournament: matchData[0]?.result[0]?.competition,
          sport: matchData[0]?.result[0]?.eventType,
          matchTempId: matchData[0]?.result[0]?.matchTempId,
        };
        const resMatch = await postAxios(API_ADD_MATCH, bodyMatch);

        const bodyMarket = {
          marketId: matchData[0]?.result[0]?.marketIdSec,
          marketType: "Match Odds",
          displayName: matchData[0]?.result[0]?.displayName,
          marketTypeId: ["5ebc1code68br4bik5b3035"],
          marketStartTime: matchData[0]?.result[0]?.marketStartTime,
          totalMatched: 0,
          runners: matchData[0]?.result[0]?.runners,
          isActive: true,
          match: {
            id: matchData[0]?.result[0]?.event?.id,
            name: matchData[0]?.result[0]?.event?.name,
          },
          tournament: matchData[0]?.result[0]?.competition,
          sport: matchData[0]?.result[0]?.eventType,
          gameSetting: null,
          cupSetting: null,
          marketStatus: {
            id: "MS081893",
            name: "OPEN",
          },
        };

        const resMarket = await postAxios(API_ADD_MARKET, bodyMarket);
        if (resMarket) {
          handleShowHide();
        }
      }
    },
  });
  return (
    <form onSubmit={handleSubmit}>
      <div className="row m-0 p-0">
        <div className="form-check">
          <input
            className="form-check-input"
            type="radio"
            name="Match Odds"
            id={`Match Odds`}
            onChange={() => setFieldValue("type", "Match Odds")}
            checked={values.type === "Match Odds"}
          />

          <label className="form-check-label" htmlFor={`Match Odds`}>
            Match Odds
          </label>
        </div>
        {/* <div className="form-check">
          <input
            className="form-check-input"
            type="radio"
            name="cup"
            id={`cup`}
            onChange={() => setFieldValue("type", "cup")}
            checked={values.type === "cup"}
          />

          <label className="form-check-label" htmlFor={`cup`}>
            Cup
          </label>
        </div> */}
      </div>
      <Button type="submit" id="form-submit-btn" isHidden={true}>
        Submit
      </Button>
    </form>
  );
};

export default ImportConfigModal;
