import React from "react";
import { useFormik } from "formik";

import { Button, Error, Label } from "../../Components";
import { API_ADD_MATCH } from "../../utils/api/ApiConstant";
import { postAxios, putAxios } from "../../Services/commonService";
import { LiveTvSchema } from "../../Schema/Configuration/LiveTvSchema";

const LiveTvModal = ({ handleShowHide, rowData }) => {
  console.log("🚀 ~ LiveTvModal ~ rowData:", rowData);
  const { values, errors, touched, handleBlur, handleChange, handleSubmit } =
    useFormik({
      initialValues: {
        channelName: rowData?.channelName,
        channelUrl: rowData?.channelUrl,
      },
      enableReinitialize: true,
      validationSchema: LiveTvSchema,
      onSubmit: (values) => {
        const payload = { ...values, _id: rowData?._id };
        console.log("🚀 ~ LiveTvModal ~ payload:", payload);
        handleFormSubmit(payload);
      },
    });

  const handleFormSubmit = async (payload) => {
    let res;
    if (rowData?._id) {
      res = await putAxios(
        `${API_ADD_MATCH}/updateChannel/${rowData?._id}`,
        payload
      );
    } else {
      res = await postAxios(`${API_ADD_MATCH}/createChannel`, payload);
    }
    if (res) {
      handleShowHide();
    }
  };

  return (
    <form onSubmit={handleSubmit}>
      <div className="row m-0 p-0">
        <div className="col-lg-6 col-12 mb-2">
          <Label htmlFor="channelName" className="form-label" isRequired={true}>
            Channel Name
          </Label>
          <input
            className="form-control"
            type="text"
            name="channelName"
            id="channelName"
            onChange={handleChange}
            onBlur={handleBlur}
            value={values.channelName}
            placeholder="enter name"
          />
          {errors.channelName && touched.channelName && (
            <Error>{errors.channelName}</Error>
          )}
        </div>
        <div className="col-md-6 m-0 p-1">
          <Label htmlFor="channelUrl" className="form-label" isRequired={true}>
            Channel url
          </Label>
          <input
            className="form-control"
            type="text"
            name="channelUrl"
            id="channelUrl"
            onChange={handleChange}
            onBlur={handleBlur}
            value={values.channelUrl}
            placeholder="enter url"
          />
          {errors.channelUrl && touched.channelUrl && (
            <Error>{errors.channelUrl}</Error>
          )}
        </div>
      </div>
      <Button type="submit" id="form-submit-btn" isHidden={true}>
        Submit
      </Button>
    </form>
  );
};

export default LiveTvModal;
