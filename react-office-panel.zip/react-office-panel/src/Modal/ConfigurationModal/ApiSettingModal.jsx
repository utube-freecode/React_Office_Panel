import React from "react";
import { useFormik } from "formik";

import { Button, Error, Label } from "../../Components";
import {
  API_ADD_MATCH,
  API_CREATE_MARKET_CONFIG,
  API_STATUS_MARKET_CONFIG,
} from "../../utils/api/ApiConstant";
import { postAxios, putAxios } from "../../Services/commonService";
import { ApiSettingSchema } from "../../Schema/Configuration/ApiSettingSchema";

const ApiSettingModal = ({ handleShowHide, rowData }) => {
  const { values, errors, touched, handleBlur, handleChange, handleSubmit } =
    useFormik({
      initialValues: {
        apiName: rowData?.apiName,
        apiUrl: rowData?.apiUrl,
        isActive: rowData?.isActive ?? false,
      },
      enableReinitialize: true,
      validationSchema: ApiSettingSchema,
      onSubmit: (values) => {
        const payload = { ...values, _id: rowData?._id };
        handleFormSubmit(payload);
      },
    });

  const handleFormSubmit = async (payload) => {
    console.log("🚀 ~ handleFormSubmit ~ rowData:", rowData);
    let res;
    if (Object.keys(rowData).length > 0) {
      res = await putAxios(
        `${API_STATUS_MARKET_CONFIG}/${rowData?._id}`,
        payload
      );
    } else {
      res = await postAxios(API_CREATE_MARKET_CONFIG, payload);
    }
    if (res) {
      handleShowHide();
    }
  };

  return (
    <form onSubmit={handleSubmit}>
      <div className="row m-0 p-0">
        <div className="col-lg-6 col-12 mb-2">
          <Label htmlFor="apiName" className="form-label" isRequired={true}>
            Channel Name
          </Label>
          <input
            className="form-control"
            type="text"
            name="apiName"
            id="apiName"
            onChange={handleChange}
            onBlur={handleBlur}
            value={values.apiName}
            placeholder="enter name"
          />
          {errors.apiName && touched.apiName && <Error>{errors.apiName}</Error>}
        </div>
        <div className="col-md-6 m-0 p-1">
          <Label htmlFor="apiUrl" className="form-label" isRequired={true}>
            Channel url
          </Label>
          <input
            className="form-control"
            type="text"
            name="apiUrl"
            id="apiUrl"
            onChange={handleChange}
            onBlur={handleBlur}
            value={values.apiUrl}
            placeholder="enter url"
          />
          {errors.apiUrl && touched.apiUrl && <Error>{errors.apiUrl}</Error>}
        </div>
      </div>
      <Button type="submit" id="form-submit-btn" isHidden={true}>
        Submit
      </Button>
    </form>
  );
};

export default ApiSettingModal;
