import { useQuery } from "@tanstack/react-query";
import { getAxiosForAuthResponse } from "../Services/commonService";
import {
  API_ADD_MATCH,
  API_GET_ALL_MATCH,
  API_GET_FILTER_SPORT,
  API_GET_FILTER_TOURNAMENT,
} from "../utils/api/ApiConstant";
import { dateFormat } from "../helper/common";

const useFilteredData = ({
  sport,
  tournament,
  allMatch = false,
  dependantMatch = true,
  enableTournament = true,
  apiParam = "All",
}) => {
  // Fetch Sports
  const { data: sportData } = useQuery({
    queryKey: ["filterSport"],
    queryFn: async () =>
      !allMatch
        ? await getAxiosForAuthResponse(API_GET_FILTER_SPORT, {
            page: 1,
            limit: -1,
          })
        : [],
    staleTime: 300000,
    enabled: !allMatch, // Only fetch sport when a match is false
  });

  // Fetch Tournaments based on selected sport
  const { data: tournamentData } = useQuery({
    queryKey: ["filterTournament", sport],
    queryFn: async () =>
      sport
        ? await getAxiosForAuthResponse(
            `${API_GET_FILTER_TOURNAMENT}/${sport}`,
            { page: 1, limit: 100 }
          )
        : [],
    staleTime: 300000,
    enabled: !!sport && enableTournament, // Only fetch tournaments when a sport is selected and enableTournament is not true
  });

  // Fetch Matches based on selected tournament
  const { data: matchData } = useQuery({
    queryKey: ["filterMatch", tournament],
    queryFn: async () => {
      if (tournament && dependantMatch) {
        return await getAxiosForAuthResponse(`${API_ADD_MATCH}/${tournament}`, {
          page: 1,
          limit: 25,
        });
      }
      return [];
    },
    staleTime: 300000,
    enabled: !!tournament && !!dependantMatch, // Enable query only if both conditions are true
  });

  const { data: matchAllData } = useQuery({
    queryKey: ["filterMatchAll"],
    queryFn: async () =>
      allMatch
        ? await getAxiosForAuthResponse(`${API_GET_ALL_MATCH}/${apiParam}`, {})
        : [],

    enabled: allMatch, // Only fetch Matches when a match is true
  });

  // Map data to options
  const sportOptions =
    sportData?.docs
      ?.filter((item) => item.isActive)
      ?.map((item) => ({ value: item.id, label: item.name })) || [];

  const tournamentOptions =
    tournamentData?.docs
      ?.filter((item) => item.isActive)
      ?.map((item) => ({ value: item.id, label: item.name })) || [];

  const matchOptions =
    matchData?.docs
      ?.filter((item) => item.isActive)
      ?.map((item) => ({ value: item.id, label: item.name })) || [];

  let matchAllOptions;
  if (matchAllData) {
    matchAllOptions =
      matchAllData?.map((item) => ({
        value: item._id?.id,
        label: `${item._id?.name} (${
          dateFormat(item._id?.marketStartTime).formattedDate
        })`,
      })) || [];
  }

  return {
    sportOptions,
    tournamentOptions,
    matchOptions,
    matchAllOptions,
  };
};

export default useFilteredData;
