import React from "react";
import { Link } from "react-router-dom";

const Breadcrumb = ({ breadcrumb, title }) => {
  return (
    <div className="page-breadcrumb d-none d-sm-flex align-items-center mb-3">
      {breadcrumb?.map((val, i) => {
        return (
          <div className="breadcrumb-title pe-3 m-1" key={i}>
            {val.link && (
              <Link href={`${val?.link}`} className="btn btn-grd-primary">
                {val?.name || title}
              </Link>
            )}
          </div>
        );
      })}
      <span>{title}</span>
    </div>
  );
};

export default Breadcrumb;
