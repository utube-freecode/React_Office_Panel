import React, { useEffect } from "react";
import { useFormik } from "formik";

import { Error, CustomSelect, Label, Button } from "../";
import { useFilteredData } from "../../Hooks";

const Filter = ({
  isSport = false,
  isTournament = false,
  isMatch = false,
  allMatch = false,
  handleFilterParams,
  apiParam,
  defaultParams = {},
  isType = false,
  marketTypeData = [],
}) => {
  const { values, touched, errors, handleSubmit, setFieldValue, resetForm } =
    useFormik({
      initialValues: {
        sports: null,
        tournament: null,
        match: null,
        marketType: null,
      },
      enableReinitialize: true,
      onSubmit: async (values) => {
        handleFilterParams(values);
      },
    });

  const { sportOptions, tournamentOptions, matchAllOptions } = useFilteredData({
    sport: values?.sports?.value,
    tournament: values?.tournament?.value,
    dependantMatch: isMatch,
    allMatch,
    enableTournament: isTournament,
    apiParam,
  });

  useEffect(() => {
    // Handle default sportId
    if (
      defaultParams.sportId &&
      sportOptions?.length > 0 &&
      !values.sports?.value
    ) {
      const selectedSport = sportOptions.find(
        (option) => option.value == defaultParams.sportId
      );

      if (selectedSport) {
        setFieldValue("sports", selectedSport);
      }
    }

    // Handle default tournamentId
    if (
      defaultParams.tournamentId &&
      tournamentOptions?.length > 0 &&
      !values.tournament?.value
    ) {
      const selectedTournament = tournamentOptions.find(
        (option) => option.value == defaultParams.tournamentId
      );

      if (selectedTournament) {
        setFieldValue("tournament", selectedTournament);
      }
    }

    // Handle default matchId
    if (
      defaultParams.matchId &&
      matchAllOptions?.length > 0 &&
      !values.match?.value
    ) {
      const selectedMatch = matchAllOptions.find(
        (option) => option.value == defaultParams.matchId
      );

      if (selectedMatch) {
        setFieldValue("match", selectedMatch);
      }
    }
  }, [
    defaultParams.sportId,
    defaultParams.tournamentId,
    defaultParams.matchId,
    sportOptions,
    tournamentOptions,
    matchAllOptions,
    setFieldValue,
    values.sports,
    values.tournament,
    values.match,
  ]);

  const handleClear = () => {
    resetForm({
      values: {
        sports: null,
        tournament: null,
        match: null,
        marketType: null,
      },
    });

    setFieldValue("sports", null);
    setFieldValue("tournament", null);
    setFieldValue("match", null);
    setFieldValue("marketType", null);

    handleFilterParams({
      sports: null,
      tournament: null,
      match: null,
      marketType: null,
    });
  };

  return (
    <form onSubmit={handleSubmit}>
      <div
        className="row"
        style={{ paddingRight: "11px", paddingLeft: "11px" }}
      >
        {isSport && (
          <div className="col-md-3">
            <Label htmlFor="sports" className="form-label">
              Sports
            </Label>
            <CustomSelect
              options={sportOptions}
              value={values.sports}
              onChange={(selectedOption) =>
                setFieldValue("sports", selectedOption)
              }
              placeholder="Select Sports"
              isMulti={false}
            />
            {errors.sports && touched.sports && <Error>{errors.sports}</Error>}
          </div>
        )}

        {isTournament && (
          <div className="col-md-3">
            <Label htmlFor="tournament" className="form-label">
              Tournament
            </Label>
            <CustomSelect
              options={tournamentOptions}
              value={values.tournament}
              onChange={(selectedOption) =>
                setFieldValue("tournament", selectedOption)
              }
              placeholder="Select Tournament"
              isMulti={false}
            />
            {errors.tournament && touched.tournament && (
              <Error>{errors.tournament}</Error>
            )}
          </div>
        )}

        {allMatch && (
          <div className="col-md-3">
            <Label htmlFor="match" className="form-label">
              Matches
            </Label>
            <CustomSelect
              options={matchAllOptions}
              value={values.match}
              onChange={(selectedOption) =>
                setFieldValue("match", selectedOption)
              }
              placeholder="Select Match"
              isMulti={false}
            />
            {errors.match && touched.match && <Error>{errors.match}</Error>}
          </div>
        )}

        {isType && marketTypeData && (
          <div className="col-lg-2 col-md-6 col-12 m-0 p-1">
            <Label htmlFor="marketType" className="form-label">
              Type
            </Label>
            <CustomSelect
              options={marketTypeData}
              value={values.marketType}
              onChange={(selectedOption) =>
                setFieldValue("marketType", selectedOption)
              }
              placeholder="Select marketType"
              isMulti={false}
            />
          </div>
        )}

        <div className="col align-self-end mt-lg-3  mt-1">
          <div className="d-flex justify-content-end align-items-center ">
            <Button type="submit" className="btn-success mx-1">
              Search
            </Button>
            <Button type="button" onClick={handleClear} className="btn-danger">
              Clear
            </Button>
          </div>
        </div>
      </div>
    </form>
  );
};

export default Filter;
