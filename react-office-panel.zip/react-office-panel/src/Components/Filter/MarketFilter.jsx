import React from "react";
import { useFormik } from "formik";

import { useFilteredData } from "../../Hooks";
import { dateFormat } from "../../helper/common";
import { Label, CustomSelect, Button, DateRangePicker } from "../";

const MarketFilter = ({
  isSport = false,
  isTournament = false,
  isMatch = false,
  allMatch = false,
  handleFilterParams,
  apiParam,
  defaultParams = {},
  isBulkOperation = false,
  isType = false,
  marketTypeData = [],
  isDate = false,
  handleShowHide,
}) => {
  const { values, touched, errors, handleSubmit, setFieldValue, resetForm } =
    useFormik({
      initialValues: {
        sports: null,
        tournament: null,
        match: null,
        marketType: null,
        startDate: null,
        endDate: null,
      },
      enableReinitialize: true,
      onSubmit: async (values) => {
        const startDate = values?.startDate
          ? dateFormat(values?.startDate).formattedDate
          : null;
        const endDate = values?.endDate
          ? dateFormat(values?.endDate).formattedDate
          : null;
        const payload = {
          ...values,
          startDate,
          endDate,
        };
        handleFilterParams(payload);
      },
    });

  const { sportOptions, tournamentOptions, matchOptions } = useFilteredData({
    sport: values?.sports?.value,
    tournament: values?.tournament?.value,
    dependantMatch: isMatch,
    allMatch,
    enableTournament: isTournament,
    apiParam,
    isType,
  });

  const handleClear = () => {
    resetForm({
      values: {
        sports: null,
        tournament: null,
        match: null,
      },
    });

    setFieldValue("sports", null);
    setFieldValue("tournament", null);
    setFieldValue("match", null);

    handleFilterParams({
      sports: null,
      tournament: null,
      match: null,
    });
  };

  return (
    <form onSubmit={handleSubmit}>
      <div
        className="row"
        style={{ paddingRight: "11px", paddingLeft: "11px" }}
      >
        {isSport && (
          <div className="col-lg-2 col-md-6 col-12 m-0 p-1">
            <Label htmlFor="sports" className="form-label">
              Sports
            </Label>
            <CustomSelect
              options={sportOptions}
              value={values.sports}
              onChange={(selectedOption) =>
                setFieldValue("sports", selectedOption)
              }
              placeholder="Select Sports"
              isMulti={false}
            />
          </div>
        )}

        {isTournament && (
          <div className="col-lg-2 col-md-6 col-12 m-0 p-1">
            <Label htmlFor="tournament" className="form-label">
              Tournament
            </Label>
            <CustomSelect
              options={tournamentOptions}
              value={values.tournament}
              onChange={(selectedOption) =>
                setFieldValue("tournament", selectedOption)
              }
              placeholder="Select Tournament"
              isMulti={false}
            />
          </div>
        )}

        {isMatch && (
          <div className="col-lg-2 col-md-6 col-12 m-0 p-1">
            <Label htmlFor="match" className="form-label">
              Matches
            </Label>
            <CustomSelect
              options={matchOptions}
              value={values.match}
              onChange={(selectedOption) =>
                setFieldValue("match", selectedOption)
              }
              placeholder="Select Match"
              isMulti={false}
            />
          </div>
        )}

        {isType && marketTypeData && (
          <div className="col-lg-2 col-md-6 col-12 m-0 p-1">
            <Label htmlFor="marketType" className="form-label">
              Type
            </Label>
            <CustomSelect
              options={marketTypeData}
              value={values.marketType}
              onChange={(selectedOption) =>
                setFieldValue("marketType", selectedOption)
              }
              placeholder="Select marketType"
              isMulti={false}
            />
          </div>
        )}

        {isDate && (
          <DateRangePicker
            values={values}
            setFieldValue={setFieldValue}
            className="col-lg-2 col-md-6 col-12 m-0 p-1"
          />
        )}

        <div className="col align-self-end mt-lg-3  mt-1">
          <div className="d-flex justify-content-end align-items-center ">
            <Button type="submit" className="btn-success me-1 btn-md">
              Search
            </Button>
            <Button
              type="button"
              onClick={handleClear}
              className="btn-danger btn-md me-1"
            >
              Clear
            </Button>
            {isBulkOperation && (
              <Button
                type="button"
                onClick={handleShowHide}
                className="btn-primary btn-md"
              >
                Bulk Operation
              </Button>
            )}
          </div>
        </div>
      </div>
    </form>
  );
};

export default MarketFilter;
