import React from "react";
import Icon from "../../assets/icons/Icon";

const Loading = ({ size = 25 }) => {
  return (
    <div className="spinner-box">
      <Icon name="CgSpinner" className="spinner" size={size} />
    </div>
  );
};

export default Loading;
