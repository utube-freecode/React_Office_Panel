import React, { memo } from "react";
import { useSelector } from "react-redux";
import Loading from "./Loading";

const Switch = ({ getValue, onChange, name, value }) => {
  const { isFormLoading } = useSelector((state) => state.ui);
  return (
    <div className="form-check form-switch form-switch-success">
      <input
        className="form-check-input"
        type="checkbox"
        name={name}
        checked={getValue()}
        onChange={onChange}
        onFocus={(e) => e.target.blur()}
        value={value}
      />
    </div>
  );
};

export default memo(Switch);
