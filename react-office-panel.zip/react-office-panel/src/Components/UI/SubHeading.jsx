import React, { memo } from "react";

import Button from "./Button";
import { Link } from "react-router-dom";

const SubHeading = ({
  subTitle = "",
  isAddBtn = true,
  handleShowHide,
  isImportBtn = false,
  isAddBtnPage = false,
  redirectPath = "",
  isDynamicBtn = false,
  dynamicBtnName = "",
  onClick,
}) => {
  return (
    <>
      <div className="card-header my-1">
        <div className="row align-items-center m-0 p-0">
          <div className="col-auto m-0 p-0">
            <h4 className="card-title">{subTitle}</h4>
          </div>

          <div className="col-auto ms-auto m-0 p-0">
            {isImportBtn && (
              <Button
                icon="FaPlus"
                className="btn btn-primary m-1"
                onClick={() => handleShowHide("import")}
              >
                Import
              </Button>
            )}

            {isAddBtn && (
              <Button
                icon="FaPlus"
                className="btn btn-primary m-1"
                onClick={() => handleShowHide("add")}
              >
                Add
              </Button>
            )}

            {isAddBtnPage && (
              <Button icon="FaPlus" className="btn btn-primary m-1">
                <Link to={redirectPath}>Add link</Link>
              </Button>
            )}

            {isDynamicBtn && (
              <Button className="btn btn-primary m-1" onClick={onClick}>
                {dynamicBtnName}
              </Button>
            )}
          </div>
        </div>
      </div>
    </>
  );
};

export default memo(SubHeading);
