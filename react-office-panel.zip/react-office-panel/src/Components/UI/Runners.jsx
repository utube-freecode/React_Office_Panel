import React, { Fragment, useState } from "react";
import Button from "./Button";
import Label from "./Label";
import Icon from "../../assets/icons/Icon";
import { generateRandomId } from "../../helper/common";
import Error from "./Error";

const Runners = ({ handleRunners, errors, touched }) => {
  const [runners, setRunners] = useState([
    {
      selectionId: generateRandomId(),
      runnerName: "",
      handicap: 1,
      sortPriority: 0,
      metadata: {
        runnerId: generateRandomId(),
      },
    },
  ]);

  const handleAdd = () => {
    const updatedItems = [
      ...runners,
      {
        selectionId: generateRandomId(),
        runnerName: "",
        handicap: 1,
        sortPriority: 0,
        metadata: {
          runnerId: generateRandomId(),
        },
      },
    ];
    setRunners(updatedItems);
    handleRunners(updatedItems);
  };

  const handleRemove = (indexToDelete) => {
    if (indexToDelete > -1) {
      const updatedItems = [
        ...runners.slice(0, indexToDelete),
        ...runners.slice(indexToDelete + 1),
      ];
      setRunners(updatedItems);
      handleRunners(updatedItems);
    }
  };

  const handleChange = (e, index) => {
    const { value } = e.target;
    const updatedItems = [...runners];
    updatedItems[index].runnerName = value;
    setRunners(updatedItems);
    handleRunners(updatedItems);
  };

  return (
    <div className="row">
      <div className="col-12">
        <h5>Runner Index</h5>
        <Button type="button" onClick={handleAdd} className="btn-primary">
          Add
        </Button>
      </div>
      {runners &&
        runners.map((runner, i) => (
          <div className="col-6" key={i}>
            <Label className="form-label">{`Runner ${i + 1}`}</Label>
            <div className="w-100 d-flex justify-space-between align-items-center ">
              <input
                name="runnerName"
                className="form-control"
                id={i}
                value={runner.runnerName}
                placeholder={`Enter runner ${i + 1}`}
                onChange={(e) => handleChange(e, i)}
              />
              <Icon
                name="FaRegTrashAlt"
                notAllowed={runners.length > 1 ? false : true}
                cursorPointer={runners.length > 1 ? true : false}
                className="text-danger"
                onClick={() => {
                  if (runners.length > 1) handleRemove(i);
                }}
              />
            </div>
            {errors &&
              touched &&
              touched[i]?.runnerName &&
              errors[i]?.runnerName && <Error>{errors[i]?.runnerName}</Error>}
          </div>
        ))}
    </div>
  );
};

export default Runners;
