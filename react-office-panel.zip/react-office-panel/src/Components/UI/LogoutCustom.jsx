import React from "react";
import { Dropdown } from "react-bootstrap";
import Icon from "../../assets/icons/Icon";

const LogoutCustom = ({ name, onClick }) => {
  return (
    <Dropdown className="d-inline mx-1">
      <Dropdown.Toggle
        id="dropdown-autoclose-true"
        className="px-1 py-1"
        style={{
          padding: 0,
          background: "none",
          border: "none",
        }}
      >
        {name}
      </Dropdown.Toggle>

      <Dropdown.Menu>
        <Dropdown.Item href="#" onClick={onClick}>
          <Icon name="FaPowerOff" className="fs-18 me-1 align-text-bottom" />
          Logout
        </Dropdown.Item>
      </Dropdown.Menu>
    </Dropdown>
  );
};

export default LogoutCustom;
