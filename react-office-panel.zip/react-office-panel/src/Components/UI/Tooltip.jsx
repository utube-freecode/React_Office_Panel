import React from "react";
import ReactTooltip from "react-tooltip";

const Tooltip = ({ children, content, position = "top", id }) => {
  const uniqueId = id || `tooltip-${Math.random().toString(36).substr(2, 9)}`;

  return (
    <>
      <span data-tip={content} data-for={uniqueId}>
        {children}
      </span>
      <ReactTooltip id={uniqueId} effect="solid" place={position} />
    </>
  );
};

export default Tooltip;
