import React, { memo } from "react";

const KeyValue = ({ obj }) => {
  return (
    <div className="col-lg-1 col-md-2 col-4 m-0 p-1">
      <div className="main_box_bet">
        <p>{obj?.key}</p>
        <ul className="list_bet">
          <li>{obj?.value1}</li>
          <li>{obj?.value2}</li>
        </ul>
      </div>
    </div>
  );
};

export default memo(KeyValue);
