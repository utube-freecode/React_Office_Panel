import React, { useState, useEffect, useRef } from "react";

const SearchInput = ({ onSearchChange }) => {
  const [searchTerm, setSearchTerm] = useState("");
  const debounceTimeout = useRef(null);

  const handleChange = (e) => {
    const value = e.target.value;
    setSearchTerm(value); // Update the local state immediately

    // Clear the previous timeout
    if (debounceTimeout.current) {
      clearTimeout(debounceTimeout.current);
    }

    // Set a new timeout
    debounceTimeout.current = setTimeout(() => {
      onSearchChange(value); // Call the provided onSearchChange after the delay
    }, 500); // Adjust the delay as needed
  };

  // Cleanup the timeout on unmount
  useEffect(() => {
    return () => {
      if (debounceTimeout.current) {
        clearTimeout(debounceTimeout.current);
      }
    };
  }, []);

  return (
    <input
      type="text"
      className="form-control table_curt_Search"
      name="search"
      id="search"
      placeholder="Search..."
      value={searchTerm}
      onChange={handleChange}
    />
  );
};

export default SearchInput;
