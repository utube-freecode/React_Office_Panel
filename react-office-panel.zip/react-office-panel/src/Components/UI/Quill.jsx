import React, { useEffect, useState, useCallback } from "react";
import ReactQuill from "react-quill";
import "react-quill/dist/quill.snow.css";
import DOMPurify from "dompurify";

// Debounce function to delay onChange call
const debounce = (func, delay) => {
  let timer;
  return (...args) => {
    clearTimeout(timer);
    timer = setTimeout(() => func(...args), delay);
  };
};

const defaultModules = {
  toolbar: [
    [{ header: [1, 2, false] }],
    ["bold", "italic", "underline", "strike"],
    [{ list: "ordered" }, { list: "bullet" }],
    ["link", "image"],
    ["clean"],
  ],
  clipboard: {
    matchVisual: false, // Retains all HTML content as is
  },
};

const defaultFormats = [
  "header",
  "bold",
  "italic",
  "underline",
  "strike",
  "list",
  "bullet",
  "link",
  "image",
  "table", // Ensure table-related tags are supported
];

const Quill = ({
  value = "",
  onChange,
  placeholder = "Enter text here...",
  readOnly = false,
  modules = defaultModules,
  formats = defaultFormats,
}) => {
  const [editorValue, setEditorValue] = useState(value);

  useEffect(() => {
    // Only sanitize the initial value, not on every keystroke
    setEditorValue(DOMPurify.sanitize(value));
  }, [value]);

  // Debounced onChange handler
  const debouncedOnChange = useCallback(
    debounce((content) => {
      onChange(content); // Send the content to the parent component
    }, 300),
    [onChange]
  );

  const handleChange = (content) => {
    setEditorValue(content); // Immediate state update
    debouncedOnChange(content); // Delayed call to onChange
  };

  return (
    <ReactQuill
      theme="snow"
      value={editorValue}
      onChange={handleChange}
      placeholder={placeholder}
      readOnly={readOnly}
      modules={modules}
      formats={formats}
    />
  );
};

export default Quill;
