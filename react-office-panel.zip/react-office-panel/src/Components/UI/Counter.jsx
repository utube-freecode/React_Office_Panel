import React, { useState, useEffect } from "react";

const Counter = ({ initialValue = 0, countFinish, ballRestart }) => {
  const [count, setCount] = useState(initialValue);
  console.log("🚀 ~ Counter ~ initialValue:", initialValue);

  useEffect(() => {
    setCount(initialValue);
  }, [initialValue, ballRestart]);

  useEffect(() => {
    if (count > 0) {
      const timer = setInterval(() => {
        setCount((prevCount) => prevCount - 1);
      }, 1000);

      return () => clearInterval(timer);
    }

    if (count === 0 && initialValue) {
      countFinish();
    }
  }, [count]);

  return (
    <>
      <span>{count}</span>
    </>
  );
};

export default Counter;
