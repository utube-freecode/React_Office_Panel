import React from "react";

const CheckBox = () => {
  return <div>CheckBox</div>;
};

export default CheckBox;
