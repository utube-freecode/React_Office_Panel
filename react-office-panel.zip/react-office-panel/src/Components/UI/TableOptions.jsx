import React from "react";
import { Dropdown } from "react-bootstrap";
import { HiMenuAlt1 } from "react-icons/hi";
const TableOptions = ({ tableOptions }) => {
  return (
    <Dropdown className="d-inline mx-1">
      <Dropdown.Toggle id="dropdown-autoclose-true" className="px-1 py-1">
        <HiMenuAlt1 size={18} />
      </Dropdown.Toggle>

      <Dropdown.Menu>
        {Object.keys(tableOptions).map((key, i) => (
          <Dropdown.Item href="#" onClick={tableOptions[key]} key={i}>
            {key}
          </Dropdown.Item>
        ))}
      </Dropdown.Menu>
    </Dropdown>
  );
};

export default TableOptions;
