import React, { memo } from "react";

const Label = ({ className, children, isRequired = false, htmlFor = "" }) => {
  return (
    <label className={`${className}`} htmlFor={htmlFor}>
      {children}
      {isRequired ? <span className="text-danger">*</span> : ""}
    </label>
  );
};

export default memo(Label);
