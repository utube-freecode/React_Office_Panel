import React from "react";
import { Label, DatePickerComponent } from "../";

const DateRangePicker = ({
  values,
  setFieldValue,
  className = "col-lg-2 col-md-6 col-12",
  startMinDate = new Date(),
}) => {
  return (
    <>
      <div className={className}>
        <Label htmlFor="startDate" className="form-label">
          Start Date
        </Label>
        <DatePickerComponent
          selectedDate={values.startDate}
          onChange={(date) => {
            setFieldValue("startDate", date);
            setFieldValue("endDate", null);
          }}
          placeholderText="Pick a start date"
          // minDate={startMinDate}
          isClearable={false}
          dateFormat="dd-MM-yyyy"
        />
      </div>
      <div className={className}>
        <Label htmlFor="endDate" className="form-label">
          End Date
        </Label>
        <DatePickerComponent
          selectedDate={values.endDate}
          onChange={(date) => setFieldValue("endDate", date)}
          placeholderText="Pick an end date"
          // minDate={values.startDate}
          isClearable={false}
          disabled={!values.startDate}
          dateFormat="dd-MM-yyyy"
        />
      </div>
    </>
  );
};

export default DateRangePicker;
