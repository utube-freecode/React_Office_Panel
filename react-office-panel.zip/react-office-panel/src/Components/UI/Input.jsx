import React from "react";

const Input = ({
  className,
  name,
  id,
  type,
  value,
  onChange,
  autoFocus = false,
  disabled = false,
  placeholder = "",
  onKeyDown,
}) => {
  return (
    <>
      <input
        className={className}
        name={name}
        id={id}
        type={type}
        value={value}
        onChange={onChange}
        autoFocus={autoFocus}
        disabled={disabled}
        placeholder={placeholder}
        onKeyDown={onKeyDown}
      />
    </>
  );
};

export default Input;
