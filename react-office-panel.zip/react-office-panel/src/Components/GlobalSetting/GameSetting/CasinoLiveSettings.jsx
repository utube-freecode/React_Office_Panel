import React, { useEffect, useState } from "react";
import { useQuery } from "@tanstack/react-query";

import { API_COMMON_GAME_SETTING } from "../../../utils/api/ApiConstant";
import { getAxios, putAxios } from "../../../Services/commonService";
import { Input, Loading } from "../../";
import { cleanUpValue } from "../../../helper/common";
import Icon from "../../../assets/icons/Icon";

const CasinoLiveSettings = () => {
  const apiUrl = `${API_COMMON_GAME_SETTING}/casinoLive`;
  const [finalData, setFinalData] = useState([]);
  const { isLoading, data: CasinoLiveSettingsData } = useQuery({
    queryKey: ["CasinoLiveSettingsData"],
    queryFn: async () =>
      await getAxios(apiUrl, {
        page: 1,
        limit: 10,
      }),
    staleTime: 300000,
  });

  useEffect(() => {
    if (CasinoLiveSettingsData?.docs) {
      setFinalData(CasinoLiveSettingsData?.docs);
    }
  }, [CasinoLiveSettingsData]);

  const handleChange = (e, casino) => {
    const { name, value } = e.target;
    const updatedData = finalData.map((row) =>
      row?._id === casino?._id ? { ...row, [name]: value } : row
    );
    setFinalData(updatedData);
  };

  const handleEdit = async (rowData) => {
    await putAxios(`${apiUrl}/${rowData?._id}`, rowData);
  };

  return (
    <div className="table-responsive">
      <table
        style={{ borderCollapse: "collapse", width: "100%" }}
        className="table table-striped table-auto"
      >
        <thead className="table-light">
          <tr>
            <th>No.</th>
            <th className="text-start">sports</th>
            <th className="text-start">volume</th>
            <th className="text-start">min stack</th>
            <th className="text-start">max stack</th>
            <th className="text-start">max profit</th>
            <th className="text-start">max loss</th>
            <th className="text-start">bet delay</th>
            <th className="text-start">min odds</th>
            <th className="text-start">max odds</th>
            <th className="text-start">commission</th>
            <th className="text-start">pre in play profit</th>
            <th className="text-start">pre in play stake</th>
            <th className="text-start">action</th>
          </tr>
        </thead>
        <tbody>
          {isLoading ? (
            <tr>
              <td colSpan="14" style={{ textAlign: "center" }}>
                <Loading />
              </td>
            </tr>
          ) : (
            finalData &&
            finalData.length > 0 &&
            finalData.map((casino, i) => (
              <tr key={i}>
                <td>{i + 1}</td>
                <td className="text-start">
                  {cleanUpValue(casino?.sport?.name)}
                </td>
                <td className="text-start">
                  <Input
                    className="form-control"
                    name="volume"
                    id="volume"
                    type="number"
                    value={casino?.volume}
                    onChange={(e) => handleChange(e, casino)}
                  />
                </td>
                <td className="text-start">
                  <Input
                    className="form-control"
                    name="minStack"
                    id="minStack"
                    type="number"
                    value={casino?.minStack}
                    onChange={(e) => handleChange(e, casino)}
                  />
                </td>
                <td className="text-start">
                  <Input
                    className="form-control"
                    name="maxStack"
                    id="maxStack"
                    type="number"
                    value={casino?.maxStack}
                    onChange={(e) => handleChange(e, casino)}
                  />
                </td>
                <td className="text-start">
                  <Input
                    className="form-control"
                    name="maxProfit"
                    id="maxProfit"
                    type="number"
                    value={casino?.maxProfit}
                    onChange={(e) => handleChange(e, casino)}
                  />
                </td>
                <td className="text-start">
                  <Input
                    className="form-control"
                    name="maxLoss"
                    id="maxLoss"
                    type="number"
                    value={casino?.maxLoss}
                    onChange={(e) => handleChange(e, casino)}
                  />
                </td>
                <td className="text-start">
                  <Input
                    className="form-control"
                    name="betDelay"
                    id="betDelay"
                    type="number"
                    value={casino?.betDelay}
                    onChange={(e) => handleChange(e, casino)}
                  />
                </td>
                <td className="text-start">
                  <Input
                    className="form-control"
                    name="minOdds"
                    id="minOdds"
                    type="number"
                    value={casino?.minOdds}
                    onChange={(e) => handleChange(e, casino)}
                  />
                </td>
                <td className="text-start">
                  <Input
                    className="form-control"
                    name="maxOdds"
                    id="maxOdds"
                    type="number"
                    value={casino?.maxOdds}
                    onChange={(e) => handleChange(e, casino)}
                  />
                </td>
                <td className="text-start">
                  <Input
                    className="form-control"
                    name="commission"
                    id="commission"
                    type="number"
                    value={casino?.commission}
                    onChange={(e) => handleChange(e, casino)}
                  />
                </td>
                <td className="text-start">
                  <Input
                    className="form-control"
                    name="preInPlayProfit"
                    id="preInPlayProfit"
                    type="number"
                    value={casino?.preInPlayProfit}
                    onChange={(e) => handleChange(e, casino)}
                  />
                </td>
                <td className="text-start">
                  <Input
                    className="form-control"
                    name="preInPlayStack"
                    id="preInPlayStack"
                    type="number"
                    value={casino?.preInPlayStack}
                    onChange={(e) => handleChange(e, casino)}
                  />
                </td>
                <td className="text-start">
                  <div className="icon_font_box">
                    <Icon
                      name="FaEdit"
                      cursorPointer={true}
                      onClick={() => handleEdit(casino)}
                    />
                  </div>
                </td>
              </tr>
            ))
          )}
        </tbody>
      </table>
    </div>
  );
};

export default CasinoLiveSettings;
