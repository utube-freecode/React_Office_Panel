import React, { useEffect, useState } from "react";
import { useQuery } from "@tanstack/react-query";

import { API_LINE_MARKET_SETTING } from "../../../utils/api/ApiConstant";
import { getAxios, putAxios } from "../../../Services/commonService";
import { Button, Input, Loading } from "../../";
import Icon from "../../../assets/icons/Icon";

const LineMarketSettings = () => {
  const [finalData, setFinalData] = useState([]);
  const { isLoading, data: LineMarketSettingsData } = useQuery({
    queryKey: ["LineMarketSettingsData"],
    queryFn: async () =>
      await getAxios(API_LINE_MARKET_SETTING, {
        page: 1,
        limit: -1,
      }),
    staleTime: 300000,
  });
  console.log(
    "🚀 ~ LineMarketSettings ~ LineMarketSettingsData:",
    LineMarketSettingsData
  );

  useEffect(() => {
    if (LineMarketSettingsData?.docs) {
      setFinalData(LineMarketSettingsData?.docs);
    }
  }, [LineMarketSettingsData]);

  const handleChange = (e, line) => {
    const { name, value } = e.target;
    const updatedData = finalData.map((row) =>
      row?._id === line?._id ? { ...row, [name]: value } : row
    );
    setFinalData(updatedData);
  };

  const handleEdit = async (isAllUpdate, rowData) => {
    const url = isAllUpdate
      ? `${API_LINE_MARKET_SETTING}/updateAllLineSetting`
      : `${API_LINE_MARKET_SETTING}/${rowData?._id}`;
    await putAxios(url, rowData);
  };

  return (
    <div className="table-responsive">
      <table
        style={{ borderCollapse: "collapse", width: "100%" }}
        className="table table-striped table-auto"
      >
        <thead className="table-light">
          <tr>
            <th>No.</th>
            <th className="text-start">min stack</th>
            <th className="text-start">max stack</th>
            <th className="text-start">max profit</th>
            <th className="text-start">bet delay</th>
            <th className="text-start">max stake per odds</th>
            <th className="text-start">volume</th>
            <th className="text-start">mul. volume</th>
            <th className="text-start">action</th>
          </tr>
        </thead>
        <tbody>
          {isLoading ? (
            <tr>
              <td colSpan="14" style={{ textAlign: "center" }}>
                <Loading />
              </td>
            </tr>
          ) : (
            finalData &&
            finalData.length > 0 &&
            finalData.map((line, i) => (
              <tr key={i}>
                <td>{i + 1}</td>
                <td className="text-start">
                  <Input
                    className="form-control"
                    name="minStack"
                    id="minStack"
                    type="number"
                    value={line?.minStack}
                    onChange={(e) => handleChange(e, line)}
                  />
                </td>
                <td className="text-start">
                  <Input
                    className="form-control"
                    name="maxStack"
                    id="maxStack"
                    type="number"
                    value={line?.maxStack}
                    onChange={(e) => handleChange(e, line)}
                  />
                </td>
                <td className="text-start">
                  <Input
                    className="form-control"
                    name="maxProfit"
                    id="maxProfit"
                    type="number"
                    value={line?.maxProfit}
                    onChange={(e) => handleChange(e, line)}
                  />
                </td>
                <td className="text-start">
                  <Input
                    className="form-control"
                    name="betDelay"
                    id="betDelay"
                    type="number"
                    value={line?.betDelay}
                    onChange={(e) => handleChange(e, line)}
                  />
                </td>
                <td className="text-start">
                  <Input
                    className="form-control"
                    name="maxStackPerOdds"
                    id="maxStackPerOdds"
                    type="number"
                    value={line?.maxStackPerOdds}
                    onChange={(e) => handleChange(e, line)}
                  />
                </td>
                <td className="text-start">
                  <Input
                    className="form-control"
                    name="MultiplierVolume"
                    id="MultiplierVolume"
                    type="number"
                    value={line?.MultiplierVolume}
                    onChange={(e) => handleChange(e, line)}
                  />
                </td>
                <td className="text-start">
                  <Input
                    className="form-control"
                    name="volume"
                    id="volume"
                    type="number"
                    value={line?.volume}
                    onChange={(e) => handleChange(e, line)}
                  />
                </td>
                <td className="text-start">
                  <div className="icon_font_box">
                    <Icon
                      name="FaEdit"
                      cursorPointer={true}
                      onClick={() => handleEdit(false, line)}
                    />
                    <Button
                      className="btn-primary btn-sm"
                      onClick={() => handleEdit(true, line)}
                    >
                      U-A
                    </Button>
                  </div>
                </td>
              </tr>
            ))
          )}
        </tbody>
      </table>
    </div>
  );
};

export default LineMarketSettings;
