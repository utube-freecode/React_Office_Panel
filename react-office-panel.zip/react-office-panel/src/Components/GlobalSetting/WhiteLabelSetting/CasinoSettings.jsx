import React, { useEffect, useState } from "react";
import { useQuery } from "@tanstack/react-query";

import { API_COMMON_GAME_SETTING } from "../../../utils/api/ApiConstant";
import { getAxios, putAxios } from "../../../Services/commonService";
import { Button, Input, Loading } from "../../";
import { cleanUpValue } from "../../../helper/common";
import Icon from "../../../assets/icons/Icon";

const CasinoSettings = () => {
  const [finalData, setFinalData] = useState([]);
  const { isLoading, data: CasinoSettingsData } = useQuery({
    queryKey: ["CasinoSettingsData"],
    queryFn: async () =>
      await getAxios(`${API_COMMON_GAME_SETTING}/casino`, {
        page: 1,
        limit: 10,
      }),
    staleTime: 300000,
  });
  console.log("🚀 ~ CasinoSettings ~ CasinoSettingsData:", CasinoSettingsData);

  useEffect(() => {
    if (CasinoSettingsData?.docs) {
      setFinalData(CasinoSettingsData?.docs);
    }
  }, [CasinoSettingsData]);

  const handleChange = (e, cup) => {
    const { name, value } = e.target;
    const updatedData = finalData.map((row) =>
      row?._id === cup?._id ? { ...row, [name]: value } : row
    );
    setFinalData(updatedData);
  };

  const handleEdit = async (rowData) => {
    const url = `${API_COMMON_GAME_SETTING}/casino/${rowData?._id}`;
    await putAxios(url, rowData);
  };

  return (
    <div className="table-responsive">
      <table
        style={{ borderCollapse: "collapse", width: "100%" }}
        className="table table-striped table-auto"
      >
        <thead className="table-light">
          <tr>
            <th>No.</th>
            <th className="text-start">sports</th>
            <th className="text-start">volume</th>
            <th className="text-start">min stack</th>
            <th className="text-start">max stack</th>
            <th className="text-start">max profit</th>
            <th className="text-start">max loss</th>
            <th className="text-start">bet delay</th>
            <th className="text-start">min odds</th>
            <th className="text-start">max odds</th>
            <th className="text-start">commission</th>
            <th className="text-start">pre in play profit</th>
            <th className="text-start">pre in play stake</th>
            <th className="text-start">action</th>
          </tr>
        </thead>
        <tbody>
          {isLoading ? (
            <tr>
              <td colSpan="14" style={{ textAlign: "center" }}>
                <Loading />
              </td>
            </tr>
          ) : (
            finalData &&
            finalData.length > 0 &&
            finalData.map((cup, i) => (
              <tr key={i}>
                <td>{i + 1}</td>
                <td className="text-start">{cleanUpValue(cup?.sport?.name)}</td>
                <td className="text-start">
                  <Input
                    className="form-control"
                    name="volume"
                    id="volume"
                    type="number"
                    value={cup?.volume}
                    onChange={(e) => handleChange(e, cup)}
                  />
                </td>
                <td className="text-start">
                  <Input
                    className="form-control"
                    name="minStack"
                    id="minStack"
                    type="number"
                    value={cup?.minStack}
                    onChange={(e) => handleChange(e, cup)}
                  />
                </td>
                <td className="text-start">
                  <Input
                    className="form-control"
                    name="maxStack"
                    id="maxStack"
                    type="number"
                    value={cup?.maxStack}
                    onChange={(e) => handleChange(e, cup)}
                  />
                </td>
                <td className="text-start">
                  <Input
                    className="form-control"
                    name="maxProfit"
                    id="maxProfit"
                    type="number"
                    value={cup?.maxProfit}
                    onChange={(e) => handleChange(e, cup)}
                  />
                </td>
                <td className="text-start">
                  <Input
                    className="form-control"
                    name="maxLoss"
                    id="maxLoss"
                    type="number"
                    value={cup?.maxLoss}
                    onChange={(e) => handleChange(e, cup)}
                  />
                </td>
                <td className="text-start">
                  <Input
                    className="form-control"
                    name="betDelay"
                    id="betDelay"
                    type="number"
                    value={cup?.betDelay}
                    onChange={(e) => handleChange(e, cup)}
                  />
                </td>
                <td className="text-start">
                  <Input
                    className="form-control"
                    name="minOdds"
                    id="minOdds"
                    type="number"
                    value={cup?.minOdds}
                    onChange={(e) => handleChange(e, cup)}
                  />
                </td>
                <td className="text-start">
                  <Input
                    className="form-control"
                    name="maxOdds"
                    id="maxOdds"
                    type="number"
                    value={cup?.maxOdds}
                    onChange={(e) => handleChange(e, cup)}
                  />
                </td>
                <td className="text-start">
                  <Input
                    className="form-control"
                    name="commission"
                    id="commission"
                    type="number"
                    value={cup?.commission}
                    onChange={(e) => handleChange(e, cup)}
                  />
                </td>
                <td className="text-start">
                  <Input
                    className="form-control"
                    name="preInPlayProfit"
                    id="preInPlayProfit"
                    type="number"
                    value={cup?.preInPlayProfit}
                    onChange={(e) => handleChange(e, cup)}
                  />
                </td>
                <td className="text-start">
                  <Input
                    className="form-control"
                    name="preInPlayStack"
                    id="preInPlayStack"
                    type="number"
                    value={cup?.preInPlayStack}
                    onChange={(e) => handleChange(e, cup)}
                  />
                </td>
                <td className="text-start">
                  <Icon
                    name="FaEdit"
                    cursorPointer={true}
                    onClick={() => handleEdit(cup)}
                  />
                </td>
              </tr>
            ))
          )}
        </tbody>
      </table>
    </div>
  );
};

export default CasinoSettings;
