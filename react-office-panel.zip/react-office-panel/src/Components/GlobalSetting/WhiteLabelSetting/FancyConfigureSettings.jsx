import React, { useEffect, useState } from "react";
import { useQuery } from "@tanstack/react-query";

import { API_FANCY_CONFIGURE } from "../../../utils/api/ApiConstant";
import { getAxios, putAxios } from "../../../Services/commonService";
import { Button, Input, Loading } from "../../";
import Icon from "../../../assets/icons/Icon";

const FancyConfigureSettings = () => {
  const [finalData, setFinalData] = useState([]);
  const { isLoading, data: FancyConfigureSettingsData } = useQuery({
    queryKey: ["FancyConfigureSettingsData"],
    queryFn: async () => await getAxios(`${API_FANCY_CONFIGURE}/get`, {}),
    staleTime: 300000,
  });
  console.log(
    "🚀 ~ FancyConfigureSettings ~ FancyConfigureSettingsData:",
    FancyConfigureSettingsData
  );

  useEffect(() => {
    if (FancyConfigureSettingsData) {
      setFinalData(FancyConfigureSettingsData);
    }
  }, [FancyConfigureSettingsData]);

  const handleChange = (e, fancy) => {
    const { name, value } = e.target;
    const updatedData = finalData.map((row) =>
      row?._id === fancy?._id ? { ...row, [name]: value } : row
    );
    setFinalData(updatedData);
  };

  const handleEdit = async (rowData) => {
    const url = `${API_FANCY_CONFIGURE}/update/${rowData?._id}`;
    await putAxios(url, rowData);
  };

  return (
    <div className="table-responsive">
      <table
        style={{ borderCollapse: "collapse", width: "100%" }}
        className="table table-striped table-auto"
      >
        <thead className="table-light">
          <tr>
            <th>No.</th>
            <th className="text-start">rate range</th>
            <th className="text-start">ball start</th>
            <th className="text-start">rate difference</th>
            <th className="text-start">action</th>
          </tr>
        </thead>
        <tbody>
          {isLoading ? (
            <tr>
              <td colSpan="14" style={{ textAlign: "center" }}>
                <Loading />
              </td>
            </tr>
          ) : (
            finalData &&
            finalData.length > 0 &&
            finalData.map((fancy, i) => (
              <tr key={i}>
                <td>{i + 1}</td>
                <td className="text-start">
                  <Input
                    className="form-control"
                    name="ballStart"
                    id="ballStart"
                    type="number"
                    value={fancy?.ballStart}
                    onChange={(e) => handleChange(e, fancy)}
                  />
                </td>
                <td className="text-start">
                  <Input
                    className="form-control"
                    name="rateRange"
                    id="rateRange"
                    type="number"
                    value={fancy?.rateRange}
                    onChange={(e) => handleChange(e, fancy)}
                  />
                </td>
                <td className="text-start">
                  <Input
                    className="form-control"
                    name="rateDiffrence"
                    id="rateDiffrence"
                    type="number"
                    value={fancy?.rateDiffrence}
                    onChange={(e) => handleChange(e, fancy)}
                  />
                </td>
                <td className="text-start">
                  <Icon
                    name="FaEdit"
                    cursorPointer={true}
                    onClick={() => handleEdit(fancy)}
                  />
                </td>
              </tr>
            ))
          )}
        </tbody>
      </table>
    </div>
  );
};

export default FancyConfigureSettings;
