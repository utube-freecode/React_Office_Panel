import React, { useEffect, useState } from "react";
import { useQuery } from "@tanstack/react-query";

import { API_GET_FANCYSETTINGS } from "../../../utils/api/ApiConstant";
import { getAxios, putAxios } from "../../../Services/commonService";
import { Button, Input, Loading } from "../../";
import Icon from "../../../assets/icons/Icon";

const FancySettings = () => {
  const [finalData, setFinalData] = useState([]);
  const { isLoading, data: FancySettingsData } = useQuery({
    queryKey: ["FancySettingsData"],
    queryFn: async () =>
      await getAxios(API_GET_FANCYSETTINGS, {
        page: 1,
        limit: -1,
      }),
    staleTime: 300000,
  });
  console.log("🚀 ~ FancySettings ~ FancySettingsData:", FancySettingsData);

  useEffect(() => {
    if (FancySettingsData?.docs) {
      setFinalData(FancySettingsData?.docs);
    }
  }, [FancySettingsData]);

  const handleChange = (e, cup) => {
    const { name, value } = e.target;
    const updatedData = finalData.map((row) =>
      row?._id === cup?._id ? { ...row, [name]: value } : row
    );
    setFinalData(updatedData);
  };

  const handleEdit = async (isAllUpdate, rowData) => {
    const url = isAllUpdate
      ? `${API_GET_FANCYSETTINGS}/updateAllFancySetting`
      : `${API_GET_FANCYSETTINGS}/${rowData?._id}`;
    await putAxios(url, rowData);
  };

  return (
    <div className="table-responsive">
      <table
        style={{ borderCollapse: "collapse", width: "100%" }}
        className="table table-striped table-auto"
      >
        <thead className="table-light">
          <tr>
            <th>No.</th>
            <th className="text-start">min stack</th>
            <th className="text-start">max stack</th>
            <th className="text-start">max profit</th>
            <th className="text-start">bet delay</th>
            <th className="text-start">max stack per odds</th>
            <th className="text-start">action</th>
          </tr>
        </thead>
        <tbody>
          {isLoading ? (
            <tr>
              <td colSpan="14" style={{ textAlign: "center" }}>
                <Loading />
              </td>
            </tr>
          ) : (
            finalData &&
            finalData.length > 0 &&
            finalData.map((cup, i) => (
              <tr key={i}>
                <td>{i + 1}</td>
                <td className="text-start">
                  <Input
                    className="form-control"
                    name="minStack"
                    id="minStack"
                    type="number"
                    value={cup?.minStack}
                    onChange={(e) => handleChange(e, cup)}
                  />
                </td>
                <td className="text-start">
                  <Input
                    className="form-control"
                    name="maxStack"
                    id="maxStack"
                    type="number"
                    value={cup?.maxStack}
                    onChange={(e) => handleChange(e, cup)}
                  />
                </td>
                <td className="text-start">
                  <Input
                    className="form-control"
                    name="maxProfit"
                    id="maxProfit"
                    type="number"
                    value={cup?.maxProfit}
                    onChange={(e) => handleChange(e, cup)}
                  />
                </td>
                <td className="text-start">
                  <Input
                    className="form-control"
                    name="betDelay"
                    id="betDelay"
                    type="number"
                    value={cup?.betDelay}
                    onChange={(e) => handleChange(e, cup)}
                  />
                </td>
                <td className="text-start">
                  <Input
                    className="form-control"
                    name="maxStackPerOdds"
                    id="maxStackPerOdds"
                    type="number"
                    value={cup?.maxStackPerOdds}
                    onChange={(e) => handleChange(e, cup)}
                  />
                </td>
                <td className="text-start">
                  <Icon
                    name="FaEdit"
                    cursorPointer={true}
                    onClick={() => handleEdit(false, cup)}
                  />
                  <Button
                    className="btn-primary btn-sm"
                    onClick={() => handleEdit(true, cup)}
                  >
                    U-A
                  </Button>
                </td>
              </tr>
            ))
          )}
        </tbody>
      </table>
    </div>
  );
};

export default FancySettings;
