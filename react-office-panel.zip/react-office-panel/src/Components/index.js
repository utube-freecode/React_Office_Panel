//... UI components...
import Button from "./UI/Button";
import Error from "./UI/Error";
import Image from "./UI/Image";
import Label from "./UI/Label";
import SubHeading from "./UI/SubHeading";
import CustomSelect from "./UI/CustomSelect";
import TableOptions from "./UI/TableOptions";
import {
  TruFalseBadge,
  OpenCloseBadge,
  StaticBadge,
  YesNoBadge,
  ActiveInactiveBadge,
} from "./UI/Badge";
import Switch from "./UI/Switch";
import Runners from "./UI/Runners";
import Loading from "./UI/Loading";
import DateRangePicker from "./UI/DateRangePicker";
import Input from "./UI/Input";
import Quill from "./UI/Quill";
import LogoutCustom from "./UI/LogoutCustom";
import KeyValue from "./UI/KeyValue";
import Counter from "./UI/Counter";
import SearchInput from "./UI/SearchInput";
import Tooltip from "./UI/Tooltip";

// filter components
import Filter from "./Filter/Filter";
import MarketFilter from "./Filter/MarketFilter";

// game setting components
import BookmakerSettings from "./GlobalSetting/GameSetting/BookmakerSettings";
import CasinoLiveSettings from "./GlobalSetting/GameSetting/CasinoLiveSettings";
import CasinoSettings from "./GlobalSetting/GameSetting/CasinoSettings";
import CupSettings from "./GlobalSetting/GameSetting/CupSettings";
import FancyConfigureSettings from "./GlobalSetting/GameSetting/FancyConfigureSettings";
import FancySettings from "./GlobalSetting/GameSetting/FancySettings";
import LineConfigureSettings from "./GlobalSetting/GameSetting/LineConfigureSettings";
import LineMarketSettings from "./GlobalSetting/GameSetting/LineMarketSettings";
import MatchOddsSettings from "./GlobalSetting/GameSetting/MatchOddsSettings";

// white label seting
import WhiteLabelBookmakerSettings from "./GlobalSetting/WhiteLabelSetting/BookmakerSettings";
import WhiteLabelCasinoLiveSettings from "./GlobalSetting/WhiteLabelSetting/CasinoLiveSettings";
import WhiteLabelCasinoSettings from "./GlobalSetting/WhiteLabelSetting/CasinoSettings";
import WhiteLabelCupSettings from "./GlobalSetting/WhiteLabelSetting/CupSettings";
import WhiteLabelFancyConfigureSettings from "./GlobalSetting/WhiteLabelSetting/FancyConfigureSettings";
import WhiteLabelFancySettings from "./GlobalSetting/WhiteLabelSetting/FancySettings";
import WhiteLabelLineConfigureSettings from "./GlobalSetting/WhiteLabelSetting/LineConfigureSettings";
import WhiteLabelLineMarketSettings from "./GlobalSetting/WhiteLabelSetting/LineMarketSettings";
import WhiteLabelMatchOddsSettings from "./GlobalSetting/WhiteLabelSetting/MatchOddsSettings";

//... other components...
import DisplayOrder from "./DisplayOrder";
import DataTable from "./DataTable";
import DatePickerComponent from "./DatePickerComponent";
import Breadcrumb from "./Breadcrumb";

export {
  Image,
  Label,
  Error,
  Button,
  DisplayOrder,
  DataTable,
  SubHeading,
  CustomSelect,
  DatePickerComponent,
  TableOptions,
  TruFalseBadge,
  OpenCloseBadge,
  StaticBadge,
  Switch,
  YesNoBadge,
  Runners,
  Loading,
  Filter,
  Breadcrumb,
  MarketFilter,
  DateRangePicker,
  ActiveInactiveBadge,
  BookmakerSettings,
  CasinoLiveSettings,
  CasinoSettings,
  CupSettings,
  FancyConfigureSettings,
  FancySettings,
  LineConfigureSettings,
  LineMarketSettings,
  MatchOddsSettings,
  Input,
  WhiteLabelBookmakerSettings,
  WhiteLabelCasinoLiveSettings,
  WhiteLabelCasinoSettings,
  WhiteLabelCupSettings,
  WhiteLabelFancyConfigureSettings,
  WhiteLabelFancySettings,
  WhiteLabelLineConfigureSettings,
  WhiteLabelLineMarketSettings,
  WhiteLabelMatchOddsSettings,
  Quill,
  LogoutCustom,
  KeyValue,
  Counter,
  SearchInput,
  Tooltip,
};
