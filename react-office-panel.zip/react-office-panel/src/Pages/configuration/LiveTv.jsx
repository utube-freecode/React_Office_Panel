import React, { useMemo, useState } from "react";
import { useQuery } from "@tanstack/react-query";

import { DataTable, SubHeading } from "../../Components";
import {
  API_ADD_MATCH,
  API_GET_GETALLCHANNELS,
} from "../../utils/api/ApiConstant";
import { getAxios, postAxios } from "../../Services/commonService";
import Icon from "../../assets/icons/Icon";
import { CommonModal, ConfimationModal, LiveTvModal } from "../../Modal";

const LiveTv = () => {
  const [isShow, setIsShow] = useState({
    isOpen: false,
    rowData: null,
    name: "",
    modalTitle: "",
    modalContent: null,
    apiFlag: false,
  });

  const { isLoading, data: livetvData } = useQuery({
    queryKey: ["livetvData", isShow.apiFlag],
    queryFn: async () => await getAxios(API_GET_GETALLCHANNELS),
  });

  const handleDelete = async ({ rowData }) => {
    const res = await postAxios(`${API_ADD_MATCH}/deleteChannel`, rowData);
    console.log("🚀 ~ handleDelete ~ res:", res);
    if (res) {
      setIsShow((prev) => ({
        ...prev,
        apiFlag: !prev.apiFlag,
      }));
    }
  };

  const columns = useMemo(
    () => [
      {
        accessorKey: "channelName",
        header: "channel name",
      },
      {
        accessorKey: "channelUrl",
        header: "channel url",
      },
      {
        accessorKey: "isActive",
        header: "action",
        cell: ({ row }) => (
          <div className="icon_font_box">
            <Icon
              name="FaEdit"
              cursorPointer={true}
              onClick={() => {
                setIsShow((prev) => ({
                  ...prev,
                  isOpen: true,
                  rowData: row?.original,
                  name: "edit",
                  modalTitle: "Edit Live Tv",
                  modalContent: LiveTvModal,
                }));
              }}
            />
            <ConfimationModal
              isIcon={true}
              iconName="FaTrash"
              getValue={() => {}}
              onStatusChange={() => handleDelete({ rowData: row?.original })}
            />
          </div>
        ),
      },
    ],
    []
  );

  const fetchData = () => {
    if (!livetvData) return { data: [], pages: 0 };

    return {
      data: livetvData,
      pages: livetvData.pages,
    };
  };

  return (
    <>
      <SubHeading
        subTitle="live tv list"
        handleShowHide={() =>
          setIsShow((prev) => ({
            ...prev,
            isOpen: true,
            rowData: {},
            name: "add",
            modalTitle: "Add live tv",
            modalContent: LiveTvModal,
          }))
        }
      />
      <div className="card-body">
        <DataTable
          columns={columns}
          fetchData={fetchData}
          isLoading={isLoading}
          isSearchable={false}
          isPagination={false}
          isPageSize={false}
        />
      </div>

      <CommonModal
        isShow={isShow.isOpen}
        handleShowHide={() =>
          setIsShow((prev) => ({
            ...prev,
            isOpen: false,
            rowData: {},
            name: "",
          }))
        }
        modalTitle={isShow.modalTitle}
      >
        {isShow.modalContent &&
          React.createElement(isShow.modalContent, {
            handleShowHide: () =>
              setIsShow((prev) => ({
                ...prev,
                isOpen: false,
                rowData: {},
                name: "",
                modalTitle: "",
                apiFlag: !prev.apiFlag,
              })),
            rowData: isShow.rowData,
          })}
      </CommonModal>
    </>
  );
};

export default LiveTv;
