import { useQuery } from "@tanstack/react-query";
import { useLocation, useNavigate, useParams } from "react-router-dom";
import React from "react";
import { getAxiosImportServer } from "../../Services/importService";
import { IMPORT_GET_MATCH } from "../../utils/api/ApiConstant";
import { DataTable, SubHeading } from "../../Components";

const ImportStep3 = () => {
  const location = useLocation();
  const rowData = location.state;
  const navigate = useNavigate();
  const { id, name } = useParams();
  const { isLoading, data } = useQuery({
    queryKey: ["importMatchData"],
    queryFn: async () =>
      await getAxiosImportServer(`${IMPORT_GET_MATCH}/${id}/4/${name}`, {}),
  });

  const fetchData = () => {
    if (!data) return { data: [], pages: 0 };

    return {
      data: data[0]?.result,
      pages: data?.pages,
    };
  };

  const columns = [
    {
      accessorKey: "event.name",
      header: "Name",
      cell: ({ getValue, row }) => {
        return (
          <span
            onClick={() =>
              navigate(
                `/config/import4/${row?.original?.event?.id}/${row?.original?.event?.name}`,
                {
                  state: {
                    ...rowData,
                    match: row?.original,
                  },
                }
              )
            }
            className="cursor-pointer"
          >
            {getValue()}
          </span>
        );
      },
    },
    {
      accessorKey: "marketCount",
      header: "Market Count",
    },
  ];

  return (
    <>
      <SubHeading
        subTitle="roles list"
        isAddBtnPage={false}
        isAddBtn={false}
        redirectPath="create"
      />
      <div className="card-body">
        <DataTable
          columns={columns}
          fetchData={fetchData}
          isSearchable={false}
          isPagination={false}
          isPageSize={false}
          // currentPage={currentPage}
          // onPageChange={handlePageChange}
          // onRecordsPerPageChange={handleRecordsperPage}
          // recordsPerPage={recordsPerPage}
          // onSearchChange={handleSearch}
          // searchTerm={searchTerm}
          isLoading={isLoading}
          // handleHeaderSort={handleHeaderSort}
        />
      </div>
    </>
  );
};

export default ImportStep3;
