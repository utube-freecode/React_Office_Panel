import { useQuery } from "@tanstack/react-query";
import { useNavigate } from "react-router-dom";
import React from "react";
import { getAxiosImportServer } from "../../Services/importService";
import { IMPORT_GET_SPORT } from "../../utils/api/ApiConstant";
import { DataTable, SubHeading } from "../../Components";

const Import = () => {
  const navigate = useNavigate();
  const { isLoading, data } = useQuery({
    queryKey: ["importSportData"],
    queryFn: async () => await getAxiosImportServer(IMPORT_GET_SPORT, {}),
  });

  const fetchData = () => {
    if (!data) return { data: [], pages: 0 };

    return {
      data: data[0].result,
      pages: data?.pages,
    };
  };

  const columns = [
    {
      accessorKey: "eventType.name",
      header: "Name",
      cell: ({ getValue, row }) => {
        return (
          <span
            onClick={() =>
              navigate(
                `/config/import2/${row?.original?.eventType?.id}/${row?.original?.eventType?.name}`,
                { state: row?.original }
              )
            }
            className="cursor-pointer"
          >
            {getValue()}
          </span>
        );
      },
    },
    {
      accessorKey: "marketCount",
      header: "Market Count",
    },
  ];

  return (
    <>
      <SubHeading
        subTitle="roles list"
        isAddBtnPage={false}
        isAddBtn={false}
        redirectPath="create"
      />
      <div className="card-body">
        <DataTable
          columns={columns}
          fetchData={fetchData}
          isSearchable={false}
          isPagination={false}
          isPageSize={false}
          // currentPage={currentPage}
          // onPageChange={handlePageChange}
          // onRecordsPerPageChange={handleRecordsperPage}
          // recordsPerPage={recordsPerPage}
          // onSearchChange={handleSearch}
          // searchTerm={searchTerm}
          isLoading={isLoading}
          // handleHeaderSort={handleHeaderSort}
        />
      </div>
    </>
  );
};

export default Import;
