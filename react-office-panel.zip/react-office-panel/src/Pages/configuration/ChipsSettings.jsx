import { useQuery } from "@tanstack/react-query";
import React, { useState, useEffect } from "react";
import { getAxios, putAxios } from "../../Services/commonService";
import { API_GET_CURRENCY } from "../../utils/api/ApiConstant";
import { Input, SubHeading } from "../../Components";

const ChipsSettings = () => {
  const [formData, setFormData] = useState([]);
  const [flag, setFlag] = useState(false);
  console.log("🚀 ~ ChipsSettings ~ formData:", formData);

  const { data: chipsSettingData } = useQuery({
    queryKey: ["chipsSettingData", flag],
    queryFn: async () => await getAxios(API_GET_CURRENCY, {}),
  });
  console.log("🚀 ~ ChipsSettings ~ chipsSettingData:", chipsSettingData);

  useEffect(() => {
    if (chipsSettingData?.[0]?.buttons) {
      setFormData(chipsSettingData[0].buttons);
    }
  }, [chipsSettingData]);

  const handleChange = (e, index) => {
    const { name, value } = e.target;
    const updatedFormData = [...formData];
    updatedFormData[index] = { ...updatedFormData[index], [name]: value };
    setFormData(updatedFormData);
  };

  const handleUpdate = async () => {
    const url = `${API_GET_CURRENCY}/${chipsSettingData?.[0]?.userId?._id}`;
    const payload = {
      userId: {
        ...chipsSettingData?.[0]?.userId,
      },
      buttons: formData,
      _id: chipsSettingData?.[0]?._id,
    };

    // update single record
    await putAxios(url, payload);

    // update all records
    // await putAxios(
    //   `${API_GET_CURRENCY}/updateAllUser`,
    //   payload
    // );

    setFlag((prev) => !prev);
  };

  return (
    <>
      <SubHeading
        subTitle="Update Chips"
        isAddBtn={false}
        isDynamicBtn={true}
        dynamicBtnName="Update"
        onClick={handleUpdate}
      />
      <div className="row">
        <div className="col-lg-12 col-12">
          <div className="table-responsive w-100">
            <table
              style={{ borderCollapse: "collapse", width: "100%" }}
              className="table table-striped table-auto"
            >
              <thead className="table-light">
                <tr>
                  <th>Label</th>
                  <th>Value</th>
                </tr>
              </thead>
              <tbody>
                {formData.map((chip, i) => (
                  <tr key={i}>
                    <td>
                      <Input
                        className="form-control"
                        name="name"
                        value={chip?.name || ""}
                        onChange={(e) => handleChange(e, i)}
                      />
                    </td>
                    <td>
                      <Input
                        className="form-control"
                        name="value"
                        value={chip?.value || ""}
                        onChange={(e) => handleChange(e, i)}
                      />
                    </td>
                  </tr>
                ))}
              </tbody>
            </table>
          </div>
        </div>
      </div>
    </>
  );
};

export default ChipsSettings;
