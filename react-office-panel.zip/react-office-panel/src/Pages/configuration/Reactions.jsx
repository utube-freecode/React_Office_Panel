import React, { useCallback, useMemo, useState } from "react";
import { useQuery } from "@tanstack/react-query";
import { debounce } from "lodash";

import { DataTable, SubHeading } from "../../Components";
import { API_GET_WHITE_LABEL_SETTING } from "../../utils/api/ApiConstant";
import { postAxios, postAxiosDataTable } from "../../Services/commonService";
import { dateFormat } from "../../helper/common";
import Icon from "../../assets/icons/Icon";

const Reactions = () => {
  const [currentPage, setCurrentPage] = useState(1);
  const [recordsPerPage, setRecordsPerPage] = useState(50);
  const [searchTerm, setSearchTerm] = useState("");
  const [headerSort, setHeaderSort] = useState({ column: 0, dir: "asc" });
  const [isShow, setIsShow] = useState({
    isOpen: false,
    rowData: null,
    name: "",
    modalTitle: "",
    modalContent: null,
    apiFlag: false,
  });

  const payload = {
    draw: currentPage,
    length: recordsPerPage,
    search: {
      value: searchTerm,
      regex: false,
    },
    columns: [
      {
        data: "",
        name: "",
        searchable: true,
        orderable: false,
        search: {
          value: "",
          regex: false,
        },
      },
      {
        data: "name",
        name: "",
        searchable: true,
        orderable: true,
        search: {
          value: "",
          regex: false,
        },
      },
      {
        data: "isActive",
        name: "",
        searchable: true,
        orderable: true,
        search: {
          value: "",
          regex: false,
        },
      },
      {
        data: "betLock",
        name: "",
        searchable: true,
        orderable: true,
        search: {
          value: "",
          regex: false,
        },
      },
      {
        data: "isManual",
        name: "",
        searchable: true,
        orderable: true,
        search: {
          value: "",
          regex: false,
        },
      },
      {
        data: "isView",
        name: "",
        searchable: true,
        orderable: true,
        search: {
          value: "",
          regex: false,
        },
      },
      {
        data: "autoImport",
        name: "",
        searchable: true,
        orderable: true,
        search: {
          value: "",
          regex: false,
        },
      },
      {
        data: "displayOrder",
        name: "",
        searchable: true,
        orderable: true,
        search: {
          value: "",
          regex: false,
        },
      },
    ],
    order: [headerSort],
  };

  const handlePageChange = (page) => {
    setCurrentPage(page);
  };

  const handleRecordsperPage = (value) => {
    setRecordsPerPage(value);
  };

  const handleSearch = (value) => {
    setSearchTerm(value);
    debouncedSearch(value);
  };

  const handleHeaderSort = ({ index, direction }) => {
    setHeaderSort({ column: index, dir: direction });
  };

  const { isLoading, data: reactionData } = useQuery({
    queryKey: [
      "reactionData",
      currentPage,
      recordsPerPage,
      searchTerm,
      isShow.apiFlag,
      headerSort,
    ],
    queryFn: async () =>
      await postAxiosDataTable(
        `${API_GET_WHITE_LABEL_SETTING}/reaction`,
        payload
      ),
  });

  const columns = useMemo(
    () => [
      {
        accessorKey: "action_name",
        header: "name",
      },
      {
        accessorKey: "game_name",
        header: "game name",
        cell: ({ row }) => {
          const initialValue = row?.original;

          return (
            initialValue.game_name || initialValue?.data?.[0]?.body?.matchName
          );
        },
      },
      {
        accessorKey: "game_type",
        header: "game type",
      },
      {
        accessorKey: "wlb_name",
        header: "white label name",
      },
      {
        accessorKey: "updatedAt",
        header: "auto settle",
        cell: ({ getValue }) => dateFormat(getValue()).formattedDateTime,
      },
      {
        accessorKey: "displayOrder",
        header: "display order",
        cell: ({ row }) => {
          const initialValue = row?.original;

          return (
            <div className="icon_font_box">
              <Icon
                name="FaEdit"
                cursorPointer={true}
                onClick={() => handleUpdate(initialValue)}
              />
            </div>
          );
        },
      },
    ],
    []
  );

  const fetchData = () => {
    if (!reactionData) return { data: [], pages: 0 };

    return {
      data: reactionData.docs,
      pages: reactionData.pages,
    };
  };

  const handleUpdate = async (rowData) => {
    const url = `${API_GET_WHITE_LABEL_SETTING}/update-reaction`;
    const res = await postAxios(url, rowData);
    if (res) {
      setIsShow((prev) => ({
        ...prev,
        apiFlag: !prev.apiFlag,
      }));
    }
  };

  return (
    <>
      <SubHeading subTitle="reaction list" isAddBtn={false} />
      <div className="card-body">
        <DataTable
          columns={columns}
          fetchData={fetchData}
          currentPage={currentPage}
          onPageChange={handlePageChange}
          onRecordsPerPageChange={handleRecordsperPage}
          recordsPerPage={recordsPerPage}
          onSearchChange={handleSearch}
          isLoading={isLoading}
          handleHeaderSort={handleHeaderSort}
        />
      </div>
    </>
  );
};

export default Reactions;
