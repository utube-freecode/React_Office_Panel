import { useQuery } from "@tanstack/react-query";
import { useLocation, useParams } from "react-router-dom";
import React, { useState } from "react";
import { getAxiosImportServer } from "../../Services/importService";
import { IMPORT_GET_MATCHODDS } from "../../utils/api/ApiConstant";
import { Button, DataTable, SubHeading } from "../../Components";
import { CommonModal, ImportConfigModal } from "../../Modal";

const ImportStep4 = () => {
  const [isShow, setIsShow] = useState({
    isOpen: false,
    rowData: null,
    name: "",
    modalTitle: "",
    modalContent: null,
    apiFlag: false,
  });

  const location = useLocation();
  const rowData = location.state;
  const { id, name } = useParams();
  const { isLoading, data } = useQuery({
    queryKey: ["importMatchOddsData"],
    queryFn: async () =>
      await getAxiosImportServer(`${IMPORT_GET_MATCHODDS}/${id}/${name}`, {}),
  });

  const fetchData = () => {
    if (!data) return { data: [], pages: 0 };

    return {
      data: data[0]?.result,
      pages: data?.pages,
    };
  };

  const columns = [
    {
      accessorKey: "marketName",
      header: "Name",
    },
    {
      accessorKey: "marketType",
      header: "Market Type",
    },
    {
      accessorKey: "marketType",
      header: "Action",
      cell: ({ getValue, row }) => {
        return (
          <Button
            className="btn-primary p-1"
            onClick={() => {
              setIsShow((prev) => ({
                ...prev,
                isOpen: true,
                rowData: row?.original,
                name: "Import",
                modalTitle: "Import",
                modalContent: ImportConfigModal,
              }));
            }}
          >
            Import
          </Button>
        );
      },
    },
  ];

  return (
    <>
      <SubHeading
        subTitle="roles list"
        isAddBtnPage={false}
        isAddBtn={false}
        redirectPath="create"
      />
      <div className="card-body">
        <DataTable
          columns={columns}
          fetchData={fetchData}
          isSearchable={false}
          isPagination={false}
          isPageSize={false}
          // currentPage={currentPage}
          // onPageChange={handlePageChange}
          // onRecordsPerPageChange={handleRecordsperPage}
          // recordsPerPage={recordsPerPage}
          // onSearchChange={handleSearch}
          // searchTerm={searchTerm}
          isLoading={isLoading}
          // handleHeaderSort={handleHeaderSort}
        />
      </div>

      <CommonModal
        isShow={isShow.isOpen}
        handleShowHide={() =>
          setIsShow((prev) => ({
            ...prev,
            isOpen: false,
            rowData: {},
            name: "",
          }))
        }
        modalTitle={isShow.modalTitle}
      >
        {isShow.modalContent &&
          React.createElement(isShow.modalContent, {
            handleShowHide: () =>
              setIsShow((prev) => ({
                ...prev,
                isOpen: false,
                rowData: {},
                name: "",
                modalTitle: "",
                apiFlag: !prev.apiFlag,
              })),
            rowData: { ...rowData, rowData: isShow.rowData },
          })}
      </CommonModal>
    </>
  );
};

export default ImportStep4;
