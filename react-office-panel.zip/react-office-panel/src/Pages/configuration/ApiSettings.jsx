import React, { useMemo, useState } from "react";
import { useQuery, useQueryClient } from "@tanstack/react-query";

import { DataTable, SubHeading } from "../../Components";
import {
  API_ADD_MATCH,
  API_GET_MARKET_CONFIG,
  API_STATUS_MARKET_CONFIG,
} from "../../utils/api/ApiConstant";
import { getAxios, postAxios, putAxios } from "../../Services/commonService";
import Icon from "../../assets/icons/Icon";
import { ApiSettingModal, CommonModal, ConfimationModal } from "../../Modal";

const ApiSettings = () => {
  const queryClient = useQueryClient();
  const [isShow, setIsShow] = useState({
    isOpen: false,
    rowData: null,
    name: "",
    modalTitle: "",
    modalContent: null,
    apiFlag: false,
  });

  const { isLoading, data: apiSettingData } = useQuery({
    queryKey: ["apiSettingData", isShow.apiFlag],
    queryFn: async () => await getAxios(API_GET_MARKET_CONFIG, {}),
  });

  const columns = useMemo(
    () => [
      {
        accessorKey: "apiName",
        header: "api name",
      },
      {
        accessorKey: "apiUrl",
        header: "api url",
      },
      {
        accessorKey: "isActive",
        header: "status",
      },
      {
        accessorKey: "isActive",
        header: "isactive",
        cell: ({ getValue, row }) => (
          <ConfimationModal
            isSwitch={true}
            getValue={getValue}
            value={getValue()}
            onStatusChange={(newValue) =>
              handlePutRequest(
                `${API_STATUS_MARKET_CONFIG}/${row?.original?._id}`,
                row?.original,
                newValue,
                "isActive"
              )
            }
          />
        ),
      },
      {
        accessorKey: "isActive",
        header: "action",
        cell: ({ row }) => (
          <div className="icon_font_box">
            <Icon
              name="FaEdit"
              cursorPointer={true}
              onClick={() => {
                setIsShow((prev) => ({
                  ...prev,
                  isOpen: true,
                  rowData: row?.original,
                  name: "edit",
                  modalTitle: "Edit api setting",
                  modalContent: ApiSettingModal,
                }));
              }}
            />

            <ConfimationModal
              isIcon={true}
              iconName="FaTrash"
              getValue={() => {}}
              onStatusChange={() => handleDelete({ rowData: row?.original })}
            />
          </div>
        ),
      },
    ],
    []
  );

  const fetchData = () => {
    if (!apiSettingData) return { data: [], pages: 0 };

    return {
      data: apiSettingData,
      pages: apiSettingData.pages,
    };
  };

  const handleDelete = async ({ rowData }) => {
    const res = await postAxios(`${API_ADD_MATCH}/deleteChannel`, rowData);
    if (res) {
      setIsShow((prev) => ({
        ...prev,
        apiFlag: !prev.apiFlag,
      }));
    }
  };

  const handleQueryClient = (rowData, updatedRowData, key) => {
    const data = queryClient.setQueryData(
      ["apiSettingData", isShow.apiFlag],
      (oldData) => {
        if (!oldData) return oldData;

        return oldData.map((obj) =>
          obj.apiUrl === rowData.apiUrl
            ? { ...obj, [key]: updatedRowData[key] }
            : obj
        );
      }
    );

    return data;
  };

  const handlePutRequest = async (url, rowData, newValue, key) => {
    const updatedRowData = {
      ...rowData,
      [key]: newValue,
    };
    const res = await putAxios(url, updatedRowData);
    console.log("🚀 ~  ~ res:", res);

    if (res) {
      console.log("🚀 ~ handlePutRequest ~ res:", res);
      handleQueryClient(rowData, updatedRowData, key);
    }
  };

  return (
    <>
      <SubHeading
        subTitle="api setting list"
        handleShowHide={() =>
          setIsShow((prev) => ({
            ...prev,
            isOpen: true,
            rowData: {},
            name: "add",
            modalTitle: "Add live tv",
            modalContent: ApiSettingModal,
          }))
        }
      />
      <div className="card-body">
        <DataTable
          columns={columns}
          fetchData={fetchData}
          isLoading={isLoading}
          isSearchable={false}
          isPagination={false}
          isPageSize={false}
        />
      </div>

      <CommonModal
        isShow={isShow.isOpen}
        handleShowHide={() =>
          setIsShow((prev) => ({
            ...prev,
            isOpen: false,
            rowData: {},
            name: "",
          }))
        }
        modalTitle={isShow.modalTitle}
      >
        {isShow.modalContent &&
          React.createElement(isShow.modalContent, {
            handleShowHide: () =>
              setIsShow((prev) => ({
                ...prev,
                isOpen: false,
                rowData: {},
                name: "",
                modalTitle: "",
                apiFlag: !prev.apiFlag,
              })),
            rowData: isShow.rowData,
          })}
      </CommonModal>
    </>
  );
};

export default ApiSettings;
