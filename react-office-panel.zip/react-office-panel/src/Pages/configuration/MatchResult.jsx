import React, { useCallback, useMemo, useState } from "react";
import { useQuery } from "@tanstack/react-query";
import { debounce } from "lodash";

import { DataTable, StaticBadge, SubHeading } from "../../Components";
import {
  API_GET_WHITE_LABEL_SETTING,
  API_MATCH_MARKET_RESULT,
} from "../../utils/api/ApiConstant";
import { postAxios, postAxiosDataTable } from "../../Services/commonService";
import { cleanUpValue, dateFormat } from "../../helper/common";
import Icon from "../../assets/icons/Icon";

const MatchResult = () => {
  const [currentPage, setCurrentPage] = useState(1);
  const [recordsPerPage, setRecordsPerPage] = useState(50);
  const [searchTerm, setSearchTerm] = useState("");
  const [startRecord, setStartRecord] = useState(0);
  const [headerSort, setHeaderSort] = useState({ column: 0, dir: "asc" });
  const [isShow, setIsShow] = useState({
    isOpen: false,
    rowData: null,
    name: "",
    modalTitle: "",
    modalContent: null,
    apiFlag: false,
  });

  const payload = {
    columns: [
      {
        data: "",
        name: "",
        searchable: true,
        orderable: true,
        search: {
          value: "",
          regex: false,
        },
      },
      {
        data: "name",
        name: "",
        searchable: true,
        orderable: true,
        search: {
          value: "",
          regex: false,
        },
      },
      {
        data: "name",
        name: "",
        searchable: true,
        orderable: true,
        search: {
          value: "",
          regex: false,
        },
      },
      {
        data: "name",
        name: "",
        searchable: true,
        orderable: true,
        search: {
          value: "",
          regex: false,
        },
      },
      {
        data: "",
        name: "",
        searchable: true,
        orderable: true,
        search: {
          value: "",
          regex: false,
        },
      },
      {
        data: "",
        name: "",
        searchable: true,
        orderable: true,
        search: {
          value: "",
          regex: false,
        },
      },
      {
        data: "",
        name: "",
        searchable: true,
        orderable: true,
        search: {
          value: "",
          regex: false,
        },
      },
    ],
    start: startRecord,
    draw: currentPage,
    length: recordsPerPage,
    search: {
      value: searchTerm,
      regex: false,
    },
    order: [headerSort],
  };

  const handlePageChange = (page) => {
    setCurrentPage(page);
    setStartRecord((page - 1) * recordsPerPage);
  };

  const handleRecordsperPage = (value) => {
    setRecordsPerPage(value);
  };

  const handleSearch = (value) => {
    setSearchTerm(value);
    debouncedSearch(value);
  };

  const handleHeaderSort = ({ index, direction }) => {
    setHeaderSort({ column: index, dir: direction });
  };

  const { isLoading, data: marketResultData } = useQuery({
    queryKey: [
      "marketResultData",
      currentPage,
      recordsPerPage,
      searchTerm,
      isShow.apiFlag,
      headerSort,
      startRecord,
    ],
    queryFn: async () =>
      await postAxiosDataTable(API_MATCH_MARKET_RESULT, payload),
  });

  const columns = useMemo(
    () => [
      {
        accessorKey: "marketType",
        header: "match",
      },
      {
        accessorKey: "sport.name",
        header: "sport",
        cell: ({ getValue }) => cleanUpValue(getValue()),
      },
      {
        accessorKey: "tournament.name",
        header: "tournament name",
        cell: ({ getValue }) => cleanUpValue(getValue()),
      },
      {
        accessorKey: "marketStartTime",
        header: "tornament",
        cell: ({ getValue }) => dateFormat(getValue()).formattedDateTime,
      },
      {
        accessorKey: "result.winnerName",
        header: "winner team",
        cell: ({ getValue }) => <StaticBadge getValue={() => getValue()} />,
      },
      {
        accessorKey: "isActive",
        header: "auto",
      },
    ],
    []
  );

  const fetchData = () => {
    if (!marketResultData) return { data: [], pages: 0 };

    return {
      data: marketResultData.docs,
      pages: marketResultData.pages,
    };
  };

  const handleUpdate = async (rowData) => {
    console.log("🚀 ~ handleUpdate ~ rowData:", rowData);
    const url = `${API_GET_WHITE_LABEL_SETTING}/update-reaction`;
    console.log("🚀 ~ handleUpdate ~ url:", url);
    const res = await postAxios(url, rowData);
    console.log("🚀 ~ handleUpdate ~ res:", res);
    if (res) {
      setIsShow((prev) => ({
        ...prev,
        apiFlag: !prev.apiFlag,
      }));
    }
  };

  return (
    <>
      <SubHeading subTitle="reaction list" isAddBtn={false} />
      <div className="card-body">
        <DataTable
          columns={columns}
          fetchData={fetchData}
          currentPage={currentPage}
          onPageChange={handlePageChange}
          onRecordsPerPageChange={handleRecordsperPage}
          recordsPerPage={recordsPerPage}
          onSearchChange={handleSearch}
          isLoading={isLoading}
          handleHeaderSort={handleHeaderSort}
        />
      </div>
    </>
  );
};

export default MatchResult;
