import React, { useEffect, useMemo, useState } from "react";
import { Button, DataTable, SubHeading } from "../../Components";
import { useQuery } from "@tanstack/react-query";
import { getAxios, postAxios } from "../../Services/commonService";
import {
  API_GET_WHITE_LABEL_SETTING,
  API_WHITE_LABEL_WELCOME,
} from "../../utils/api/ApiConstant";
import Icon from "../../assets/icons/Icon";

const WelcomeSettings = () => {
  const [message, setMessage] = useState("");
  const { isLoading, data: welcomeWhiteLabelData } = useQuery({
    queryKey: ["welcomeWhiteLabelData"],
    queryFn: async () =>
      await getAxios(API_GET_WHITE_LABEL_SETTING, {
        page: 1,
        limit: -1,
      }),
  });
  const { isLoading: msgLoading, data: welcomeMsgWhiteLabelData } = useQuery({
    queryKey: ["welcomeMsgWhiteLabelData"],
    queryFn: async () => await getAxios(API_WHITE_LABEL_WELCOME, {}),
  });
  console.log(
    "🚀 ~ WelcomeSettings ~ welcomeMsgWhiteLabelData:",
    welcomeMsgWhiteLabelData
  );

  useEffect(() => {
    if (welcomeMsgWhiteLabelData?.massage) {
      setMessage(welcomeMsgWhiteLabelData?.massage);
    }
  }, [welcomeMsgWhiteLabelData]);

  const fetchData = () => {
    if (!welcomeWhiteLabelData) return { data: [], pages: 0 };

    return {
      data: welcomeWhiteLabelData?.docs,
      pages: welcomeWhiteLabelData?.pages,
    };
  };

  const columns = useMemo(
    () => [
      {
        accessorKey: "app_name",
        header: "name",
      },
      {
        accessorKey: "",
        header: "action",
        cell: ({ row }) => {
          return <Icon name="FaEdit" cursorPointer={true} onClick={() => {}} />;
        },
      },
    ],
    []
  );

  const handleSend = async () => {
    await postAxios(API_WHITE_LABEL_WELCOME, {
      massage: message,
    });
  };
  return (
    <>
      <SubHeading subTitle="Rule setting" isAddBtn={false} />
      <div className="card-body">
        <div className="row">
          <div className="col-lg-4 col-12 m-0 p-1">
            <DataTable
              columns={columns}
              fetchData={fetchData}
              isPageSize={false}
              isPagination={false}
              isSearchable={false}
              isLoading={isLoading}
            />
          </div>
          <div className="col-lg-8 col-12 m-0 p-1">
            <textarea
              className="form-control"
              placeholder="Enter message"
              rows={2}
              cols={5}
              value={message}
              onChange={(e) => setMessage(e.target.value)}
            />
            <div className="d-flex justify-content-end align-items-center w-100 mt-2">
              <Button className="btn-primary btn-md" onClick={handleSend}>
                send
              </Button>
            </div>
          </div>
        </div>
      </div>
    </>
  );
};

export default WelcomeSettings;
