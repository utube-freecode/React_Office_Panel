import React, { useMemo, useState } from "react";
import { Button, DataTable, Quill, SubHeading } from "../../Components";
import {
  getAxios,
  postCustomUrlAxios,
  putCustomUrlAxios,
} from "../../Services/commonService";
import {
  API_GET_WEBHOOK_RESTRICTION,
  API_GET_WHITE_LABEL_SETTING,
  API_PUT_WEBHOOK_RESTRICTION,
} from "../../utils/api/ApiConstant";
import { useQuery } from "@tanstack/react-query";
import Icon from "../../assets/icons/Icon";

const RulesSettings = () => {
  const [content, setContent] = useState(null);
  const [ruleData, setRuleData] = useState(null);

  const { isLoading, data: whiteLabelConfigData } = useQuery({
    queryKey: ["whiteLabelConfigData"],
    queryFn: async () =>
      await getAxios(API_GET_WHITE_LABEL_SETTING, {
        page: 1,
        limit: -1,
      }),
  });

  const handleCustomWebhook = async ({ rowData }) => {
    if (!rowData) return;
    setRuleData(rowData);
    const { app_url, app_token } = rowData;

    const res = await postCustomUrlAxios({
      subDomain: app_url,
      url: API_GET_WEBHOOK_RESTRICTION,
      apptoken: app_token,
      payload: rowData,
    });
    setContent(res?.[0]);
  };

  const columns = useMemo(
    () => [
      {
        accessorKey: "app_name",
        header: "name",
      },
      {
        accessorKey: "",
        header: "action",
        cell: ({ row }) => {
          return (
            <Icon
              name="FaEdit"
              cursorPointer={true}
              onClick={() => handleCustomWebhook({ rowData: row?.original })}
            />
          );
        },
      },
    ],
    []
  );

  const fetchData = () => {
    if (!whiteLabelConfigData) return { data: [], pages: 0 };

    return {
      data: whiteLabelConfigData?.docs,
      pages: whiteLabelConfigData?.pages,
    };
  };

  const handleQuillChange = (newContent) => {
    setContent((prev) => ({ ...prev, restriction: newContent }));
  };

  const handleAdd = async () => {
    const { app_url, app_token } = ruleData;

    // create payload
    const payload = {
      _id: ruleData._id,
      restriction: content.restriction,
    };

    await putCustomUrlAxios({
      subDomain: app_url,
      url: API_PUT_WEBHOOK_RESTRICTION,
      apptoken: app_token,
      payload,
    });
  };

  return (
    <>
      <SubHeading subTitle="Rule setting" isAddBtn={false} />
      <div className="card-body">
        <div className="row">
          <div className="col-lg-4 col-12 m-0 p-1">
            <DataTable
              columns={columns}
              fetchData={fetchData}
              isPageSize={false}
              isPagination={false}
              isSearchable={false}
              isLoading={isLoading}
            />
          </div>
          <div className="col-lg-8 col-12 m-0 p-1">
            <Quill value={content?.restriction} onChange={handleQuillChange} />
            <div className="d-flex justify-content-end align-items-center w-100 mt-2">
              <Button
                className="btn-outline-danger btn-md me-1"
                onClick={() => setContent(null)}
              >
                cancel
              </Button>
              <Button className="btn-primary btn-ms" onClick={handleAdd}>
                Add
              </Button>
            </div>
          </div>
        </div>
      </div>
    </>
  );
};

export default RulesSettings;
