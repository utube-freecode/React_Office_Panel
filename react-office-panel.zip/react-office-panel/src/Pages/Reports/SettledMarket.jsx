import React, { useCallback, useMemo, useState } from "react";

import { Button, DataTable, MarketFilter, SubHeading } from "../../Components";
import { CheckPasswordModal, CommonModal, ViewBetModal } from "../../Modal";
import { useQuery } from "@tanstack/react-query";
import { postAxiosDataTable, putAxios } from "../../Services/commonService";
import {
  API_ADD_MARKET,
  API_POST_MARKET_REPORT,
} from "../../utils/api/ApiConstant";
import { debounce } from "lodash";
import { currentDateTime, dateFormat } from "../../helper/common";

const marketTypeData = [
  {
    value: "Match Odds",
    label: "Match Odds",
  },
  {
    value: "Bookmaker",
    label: "Bookmaker",
  },
  {
    value: "Fancy",
    label: "Fancy",
  },
  {
    value: "Line",
    label: "Line",
  },
];

const SettledMarket = () => {
  const [currentPage, setCurrentPage] = useState(1);
  const [recordsPerPage, setRecordsPerPage] = useState(50);
  const [searchTerm, setSearchTerm] = useState("");
  const [headerSort, setHeaderSort] = useState({ column: 0, dir: "asc" });
  const [isShow, setIsShow] = useState({
    isOpen: false,
    rowData: null,
    name: "",
    modalTitle: "",
    modalContent: null,
    apiFlag: false,
  });
  const [filterData, setFilterData] = useState({
    sportId: null,
    tournamentId: null,
    matchId: null,
    marketType: null,
    matchDate: null,
    matchDateEnd: null,
  });

  const { isLoading, data: settledData } = useQuery({
    queryKey: [
      "settleApidData",
      currentPage,
      recordsPerPage,
      searchTerm,
      filterData,
      headerSort,
      isShow.apiFlag,
    ],
    queryFn: async () =>
      await postAxiosDataTable(API_POST_MARKET_REPORT, payload),
  });

  const payload = {
    draw: currentPage,
    length: recordsPerPage,
    search: {
      value: searchTerm,
      regex: false,
    },
    columns: [
      {
        data: "",
        name: "",
        searchable: true,
        orderable: false,
        search: {
          value: "",
          regex: false,
        },
      },
      {
        data: "tournament",
        name: "",
        searchable: true,
        orderable: true,
        search: {
          value: "",
          regex: false,
        },
      },
      {
        data: "match",
        name: "",
        searchable: true,
        orderable: true,
        search: {
          value: "",
          regex: false,
        },
      },
      {
        data: "marketType",
        name: "",
        searchable: true,
        orderable: true,
        search: {
          value: "",
          regex: false,
        },
      },
      {
        data: "",
        name: "",
        searchable: true,
        orderable: true,
        search: {
          value: "",
          regex: false,
        },
      },
      {
        data: "marketStartTime",
        name: "",
        searchable: true,
        orderable: true,
        search: {
          value: "",
          regex: false,
        },
      },
      {
        data: "updatedAt",
        name: "",
        searchable: true,
        orderable: true,
        search: {
          value: "",
          regex: false,
        },
      },
      {
        data: "",
        name: "",
        searchable: true,
        orderable: true,
        search: {
          value: "",
          regex: false,
        },
      },
    ],
    order: [headerSort],
    data: filterData,
    marketStatusID: "MS180893",
  };

  const columns = useMemo(
    () => [
      {
        accessorKey: "fancyName",
        header: "Runner Name",
        cell: ({ row }) => {
          return row?.original?.marketType === "Fancy"
            ? row?.original?.fancyName
            : row?.original?.marketType === "Bookmaker"
            ? row?.original?.displayName
            : row?.original?.marketType;
        },
      },
      {
        accessorKey: "match.name",
        header: "match",
      },
      {
        accessorKey: "demo",
        header: "Action",
        cell: ({ row, getValue }) => {
          const { match, fancyId, marketType } = row?.original;
          const handleViewBet = () => {
            setIsShow((prev) => ({
              ...prev,
              isOpen: true,
              rowData: {
                matchId: match?.id,
                status: "open",
                fancyId,
                marketId: null,
                lineId: null,
                marketTypeSelect: marketType,
              },
              name: "add",
              modalTitle: "View Bet",
              modalContent: ViewBetModal,
            }));
          };

          return (
            <div className="w-100 d-flex">
              <Button
                className="btn-success btn-sm me-1"
                onClick={handleViewBet}
              >
                V-B
              </Button>
              <CheckPasswordModal
                isBtn={true}
                onStatusChange={(newValue, token) =>
                  handleReopenMarket(newValue, token, row?.original)
                }
                rowData={row?.original}
                getValue={getValue}
                btnText="R-O"
                btnClass="btn-primary btn-sm me-1"
              />
            </div>
          );
        },
      },
      {
        accessorKey: "result",
        header: "result",
      },
      {
        accessorKey: "demo",
        header: "preresult",
        cell: ({ getValue }) => (getValue() ? getValue() : "-"),
      },
      {
        accessorKey: "marketType",
        header: "type",
      },
      {
        accessorKey: "marketStartTime",
        header: "match date",
        cell: ({ getValue }) => dateFormat(getValue()).formattedDateTime,
      },
      {
        accessorKey: "updatedAt",
        header: "settled date",
        cell: ({ getValue }) => dateFormat(getValue()).formattedDateTime,
      },
    ],
    []
  );

  const fetchData = () => {
    if (!settledData) return { data: [], pages: 0 };

    return {
      data: settledData?.docs || [],
      pages: settledData.pages || 0,
    };
  };

  const handlePageChange = (page) => {
    setCurrentPage(page);
  };

  const handleRecordsperPage = (value) => {
    setRecordsPerPage(value);
  };

  const handleSearch = (value) => {
    setSearchTerm(value);
    debouncedSearch(value);
  };

  const handleHeaderSort = ({ index, direction }) => {
    setHeaderSort({ column: index, dir: direction });
  };

  const handleReopenMarket = async (newValue, token, rowData) => {
    const { marketType, marketId, result } = rowData;

    const payload = {
      marketType,
      marketId,
      token,
      preResult: result,
      status: {
        id: "MS940896",
        value: "SUSPEND",
        name: "suspend",
      },
    };
    const url = `${API_ADD_MARKET}/reopen/${marketId}`;

    const res = await putAxios(url, payload);
    if (res) {
      setIsShow((prev) => ({
        ...prev,
        isOpen: false,
        rowData: null,
        name: "",
        modalTitle: "",
        modalContent: null,
        apiFlag: !prev.apiFlag,
      }));
    }
  };

  const handleFilterParams = useCallback((filterParams) => {
    if (filterParams) {
      const { sports, tournament, match, startDate, endDate, marketType } =
        filterParams;
      setFilterData((prev) => ({
        ...prev,
        sportId: sports?.value,
        tournamentId: tournament?.value,
        matchId: match?.value,
        marketType: marketType?.value,
        matchDate: startDate,
        matchDateEnd: endDate || startDate,
      }));
    } else {
      setFilterData((prev) => ({
        ...prev,
        sportId: null,
        tournamentId: null,
        matchId: null,
        matchDate: null,
        matchDateEnd: null,
        marketType: null,
      }));
    }
  }, []);

  return (
    <>
      {/* <Breadcrumb breadcrumb={[]} title={"Upload"} /> */}
      <SubHeading subTitle="settled market" isAddBtn={false} />

      <MarketFilter
        isSport={true}
        isTournament={true}
        isMatch={false}
        isBulkOperation={false}
        isType={true}
        isDate={true}
        marketTypeData={marketTypeData}
        handleFilterParams={handleFilterParams}
      />

      <div className="card-body">
        <DataTable
          columns={columns}
          fetchData={fetchData}
          currentPage={currentPage}
          onPageChange={handlePageChange}
          onRecordsPerPageChange={handleRecordsperPage}
          recordsPerPage={recordsPerPage}
          onSearchChange={handleSearch}
          isLoading={isLoading}
          handleHeaderSort={handleHeaderSort}
        />
      </div>

      {/* Modal for Add/Edit Sport */}
      <CommonModal
        isShow={isShow.isOpen}
        handleShowHide={() =>
          setIsShow((prev) => ({
            ...prev,
            isOpen: false,
            rowData: {},
            name: "",
          }))
        }
        modalTitle={isShow.modalTitle}
      >
        {isShow.modalContent &&
          React.createElement(isShow.modalContent, {
            handleShowHide: () =>
              setIsShow((prev) => ({
                ...prev,
                isOpen: false,
                rowData: {},
                name: "",
                modalTitle: "",
                apiFlag: !prev.apiFlag,
              })),
            rowData: isShow.rowData,
          })}
      </CommonModal>
    </>
  );
};

export default SettledMarket;
