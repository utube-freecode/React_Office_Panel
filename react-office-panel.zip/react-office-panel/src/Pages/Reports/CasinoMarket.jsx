import React from "react";

const CasinoMarket = () => {
  return <div>CasinoMarket</div>;
};

export default CasinoMarket;
