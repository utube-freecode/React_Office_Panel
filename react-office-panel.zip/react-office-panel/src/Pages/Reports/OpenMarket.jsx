import { useQuery, useQueryClient } from "@tanstack/react-query";
import { debounce } from "lodash";
import React, { useCallback, useState } from "react";
import { Button, DataTable, MarketFilter, SubHeading } from "../../Components";
import {
  CancelFanciesModal,
  CheckPasswordModal,
  CommonModal,
  ResultModal,
  ViewBetModal,
} from "../../Modal";
import {
  postAxios,
  postAxiosDataTable,
  putAxios,
} from "../../Services/commonService";
import {
  API_ADD_MARKET,
  API_GET_OPEN_MARKET,
} from "../../utils/api/ApiConstant";
import { cleanUpValue, dateFormat } from "../../helper/common";

const marketTypeData = [
  {
    value: "Match Odds",
    label: "Match Odds",
  },
  {
    value: "Bookmaker",
    label: "Bookmaker",
  },
  {
    value: "Fancy",
    label: "Fancy",
  },
  {
    value: "Line",
    label: "Line",
  },
  {
    value: "CasinoLive",
    label: "CasinoLive",
  },
];

const OpenMarket = () => {
  const [currentPage, setCurrentPage] = useState(1);
  const [recordsPerPage, setRecordsPerPage] = useState(50);
  const [searchTerm, setSearchTerm] = useState("");
  const [headerSort, setHeaderSort] = useState({ column: 0, dir: "asc" });
  const queryClient = useQueryClient();
  const [isShow, setIsShow] = useState({
    isOpen: false,
    rowData: null,
    name: "",
    modalTitle: "",
    modalContent: null,
    apiFlag: false,
  });
  const [filterData, setFilterData] = useState({
    sportId: null,
    tournamentId: null,
    matchId: null,
    marketType: null,
    startDate: null,
    endDate: null,
  });

  const payload = {
    draw: currentPage,
    columns: [
      {
        data: "match",
        name: "",
        searchable: true,
        orderable: false,
        search: {
          value: "",
          regex: false,
        },
      },
      {
        data: "",
        name: "",
        searchable: true,
        orderable: true,
        search: {
          value: "",
          regex: false,
        },
      },
      {
        data: "",
        name: "",
        searchable: true,
        orderable: true,
        search: {
          value: "",
          regex: false,
        },
      },
      {
        data: "marketType",
        name: "",
        searchable: true,
        orderable: true,
        search: {
          value: "",
          regex: false,
        },
      },
      {
        data: "",
        name: "",
        searchable: true,
        orderable: true,
        search: {
          value: "",
          regex: false,
        },
      },
      {
        data: "marketStartTime",
        name: "",
        searchable: true,
        orderable: true,
        search: {
          value: "",
          regex: false,
        },
      },
    ],
    order: [headerSort],
    start: (currentPage - 1) * recordsPerPage, // Calculate offset,
    length: recordsPerPage,
    search: { value: searchTerm, regex: false },
    types: "open",
    marketStatusID: ["MS930818", "MS180893"],
    data: filterData,
  };

  const handlePageChange = (page) => {
    setCurrentPage(page);
  };

  const handleRecordsperPage = (value) => {
    setRecordsPerPage(value);
  };

  const handleSearch = (value) => {
    setSearchTerm(value);
    debouncedSearch(value);
  };

  const handleHeaderSort = ({ index, direction }) => {
    setHeaderSort({ column: index, dir: direction });
  };

  const { isLoading, data } = useQuery({
    queryKey: [
      "openMarketData",
      currentPage,
      recordsPerPage,
      searchTerm,
      filterData,
      isShow.apiFlag,
      headerSort,
    ],
    queryFn: async () => await postAxiosDataTable(API_GET_OPEN_MARKET, payload),
  });

  const fetchData = () => {
    if (!data) return { data: [], pages: 0 };

    return {
      data: data.docs,
      pages: data.pages,
    };
  };

  const handleActions = async (
    newValue,
    token,
    rowData,
    apiAction,
    apiMethod,
    status
  ) => {
    const { marketType, marketId, match, assignTo } = rowData;

    const payload = {
      marketType,
      marketId,
      token,
      marketName: match?.name,
      status,
      userId: assignTo?.id,
    };
    const url = `${API_ADD_MARKET}/${apiAction}/${marketId}`;

    let res;
    if (apiMethod === "put") {
      res = await putAxios(url, payload);
    } else if (apiMethod === "post") {
      res = await postAxios(url, payload);
    }

    if (res) {
      setIsShow((prev) => ({
        ...prev,
        isOpen: false,
        rowData: {},
        name: "",
        modalTitle: "",
        apiFlag: !prev.apiFlag,
      }));
    }
  };

  const columns = [
    {
      accessorKey: "marketType",
      header: "Runner Name",
      tooltip: "This is the market type",
      cell: ({ row }) => {
        return row?.original?.marketType === "Fancy"
          ? row?.original?.fancyName
          : row?.original?.marketType === "Bookmaker"
          ? row?.original?.displayName
          : row?.original?.marketType;
      },
    },
    {
      accessorKey: "match.name",
      header: "Match",
      cell: ({ getValue }) => cleanUpValue(getValue()),
    },
    {
      header: "Result",
      cell: ({ row }) => {
        return (
          <Button
            className="btn-primary btn-sm me-1"
            onClick={() =>
              setIsShow((prev) => ({
                ...prev,
                isOpen: true,
                rowData: row?.original,
                name: "settlement",
                modalTitle: "Settlement",
                modalContent: ResultModal,
              }))
            }
          >
            R
          </Button>
        );
      },
    },
    {
      header: "Actions",
      cell: ({ row, getValue }) => {
        const { match, marketType, displayName, fancyName } = row?.original;
        const handleViewBet = () => {
          setIsShow((prev) => ({
            ...prev,
            isOpen: true,
            rowData: {
              matchId: match?.id,
              status: "open",
              fancyId: null,
              marketId: null,
              lineId: null,
              marketTypeSelect: marketType,
            },
            name: "add",
            modalTitle: "View Bet",
            modalContent: ViewBetModal,
          }));
        };
        return (
          <div>
            <Button className="btn-success btn-sm me-1" onClick={handleViewBet}>
              V-B
            </Button>
            <CheckPasswordModal
              isBtn={true}
              onStatusChange={(newValue, token) => {
                const status = {
                  id: "MS930818",
                  name: "Cancelled",
                  value: "CANCELLED",
                };
                handleActions(
                  newValue,
                  token,
                  row?.original,
                  "cancel",
                  "put",
                  status
                );
              }}
              rowData={row?.original}
              getValue={getValue}
              btnText="X"
              btnClass="btn-danger btn-sm me-1"
              modalTitle={`Cancel Market (${
                marketType === "Fancy"
                  ? fancyName
                  : marketType === "Bookmaker"
                  ? displayName
                  : marketType
              })`}
            />
            <CheckPasswordModal
              isBtn={true}
              onStatusChange={(newValue, token) => {
                handleActions(
                  newValue,
                  token,
                  row?.original,
                  "deleteMarket",
                  "post",
                  {}
                );
              }}
              rowData={row?.original}
              getValue={getValue}
              btnText="D-M"
              btnClass="btn-info btn-sm"
              modalTitle="Delete Market"
            />
          </div>
        );
      },
    },
    {
      accessorKey: "marketType",
      header: "Type",
      tooltip: "This is the market type",
    },
    { accessorKey: "marketStatus.name", header: "Status" },
    {
      accessorKey: "createdAt",
      header: "Created Date",
      cell: ({ getValue }) => {
        const value = getValue();
        return dateFormat(value).formattedDateTime;
      },
    },
    {
      accessorKey: "marketStartTime",
      header: "Match Date",
      cell: ({ getValue }) => {
        const value = getValue();
        return dateFormat(value).formattedDateTime;
      },
    },
  ];

  const handleFilterParams = useCallback((filterParams) => {
    const { sports, tournament, match, startDate, endDate, marketType } =
      filterParams;
    setFilterData((prev) => ({
      ...prev,
      sportId: sports?.value ?? null,
      tournamentId: tournament?.value ?? null,
      matchId: match?.value ?? null,
      marketType: marketType?.value ?? null,
      startDate,
      endDate: endDate || startDate,
    }));
  }, []);

  return (
    <>
      <SubHeading subTitle="open market" isAddBtn={false} />
      <MarketFilter
        isSport={true}
        isTournament={true}
        isMatch={true}
        isBulkOperation={true}
        isType={true}
        isDate={false}
        marketTypeData={marketTypeData}
        handleFilterParams={handleFilterParams}
        handleShowHide={() =>
          setIsShow((prev) => ({
            ...prev,
            isOpen: true,
            rowData: {},
            name: "",
            modalContent: CancelFanciesModal,
            modalTitle: "Cancel Fancies (Select Date Range)",
          }))
        }
      />
      <div className="card-body">
        <DataTable
          columns={columns}
          fetchData={fetchData}
          currentPage={currentPage}
          onPageChange={handlePageChange}
          onRecordsPerPageChange={handleRecordsperPage}
          recordsPerPage={recordsPerPage}
          onSearchChange={handleSearch}
          isLoading={isLoading}
          handleHeaderSort={handleHeaderSort}
        />
      </div>
      <CommonModal
        isShow={isShow.isOpen}
        handleShowHide={() =>
          setIsShow((prev) => ({
            ...prev,
            isOpen: false,
            rowData: {},
            name: "",
          }))
        }
        modalTitle={isShow.modalTitle}
      >
        {isShow.modalContent &&
          React.createElement(isShow.modalContent, {
            handleShowHide: () =>
              setIsShow((prev) => ({
                ...prev,
                isOpen: false,
                rowData: {},
                name: "",
                modalTitle: "",
                apiFlag: !prev.apiFlag,
              })),
            rowData: isShow.rowData,
          })}
      </CommonModal>
    </>
  );
};

export default OpenMarket;
