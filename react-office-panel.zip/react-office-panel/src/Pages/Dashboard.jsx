import React from "react";
import { useDispatch } from "react-redux";
import { useLocation } from "react-router-dom";
import { useQuery } from "@tanstack/react-query";

import { uiActions } from "../store/ui/ui-slice";
import { getAxios } from "../Services/commonService";
import { API_DASHBOARD_COUNT } from "../utils/api/ApiConstant";
import { SubHeading } from "../Components";

const Dashboard = () => {
  const location = useLocation();
  const { heading } = location.state || {};
  const dispatch = useDispatch();

  if (heading) {
    dispatch(uiActions.setHeading(heading));
  }

  const { isLoading, data: dashboardCount } = useQuery({
    queryKey: ["dashboardCountData"],
    queryFn: async () => await getAxios(API_DASHBOARD_COUNT, {}),
  });
  console.log("🚀 ~ Dashboard ~ dashboardCount:", dashboardCount);

  return (
    <>
      <SubHeading subTitle="Dashboard" isAddBtn={false} />
      {/* <div className="card-body">Dashboard</div> */}
      <div className="row card-body">
        <div className="col-md-6 col-lg-3">
          <div className="card">
            <div className="card-header">
              <div className="row align-items-center">
                <div className="col">
                  <h4 className="card-title">Exchange Rate</h4>
                </div>
              </div>
            </div>
            <div className="card-body pt-0">
              <div className="table-responsive">
                <table className="table mb-0">
                  <tbody>
                    <tr className="">
                      <td className="px-0">
                        <div className="d-flex align-items-center">
                          <h6 className="m-0 text-truncate">USA</h6>
                        </div>
                      </td>
                      <td className="px-0 text-end">
                        <span className="text-body ps-2 align-self-center text-end fw-medium">
                          0.835230
                          <span className="badge rounded text-success bg-success-subtle">
                            1.10%
                          </span>
                        </span>
                      </td>
                    </tr>
                    <tr className="">
                      <td className="px-0">
                        <div className="d-flex align-items-center">
                          <h6 className="m-0 text-truncate">Spain</h6>
                        </div>
                      </td>
                      <td className="px-0 text-end">
                        <span className="text-body ps-2 align-self-center text-end fw-medium">
                          0.896532
                          <span className="badge rounded text-success bg-success-subtle">
                            0.91%
                          </span>
                        </span>
                      </td>
                    </tr>
                    <tr className="">
                      <td className="px-0">
                        <div className="d-flex align-items-center">
                          <h6 className="m-0 text-truncate">French</h6>
                        </div>
                      </td>
                      <td className="px-0 text-end">
                        <span className="text-body ps-2 align-self-center text-end fw-medium">
                          0.875433
                          <span className="badge rounded text-danger bg-danger-subtle">
                            0.11%
                          </span>
                        </span>
                      </td>
                    </tr>
                    <tr className="">
                      <td className="px-0">
                        <div className="d-flex align-items-center">
                          <h6 className="m-0 text-truncate">Germany</h6>
                        </div>
                      </td>
                      <td className="px-0 text-end">
                        <span className="text-body ps-2 align-self-center text-end fw-medium">
                          0.795621
                          <span className="badge rounded text-success bg-success-subtle">
                            0.85%
                          </span>
                        </span>
                      </td>
                    </tr>
                    <tr className="">
                      <td className="px-0">
                        <div className="d-flex align-items-center">
                          <h6 className="m-0 text-truncate">French</h6>
                        </div>
                      </td>
                      <td className="px-0 text-end">
                        <span className="text-body ps-2 align-self-center text-end fw-medium">
                          0.875433
                          <span className="badge rounded text-danger bg-danger-subtle">
                            0.11%
                          </span>
                        </span>
                      </td>
                    </tr>
                    <tr className="">
                      <td className="px-0 pb-0">
                        <div className="d-flex align-items-center">
                          <h6 className="m-0 text-truncate">Bahamas</h6>
                        </div>
                      </td>
                      <td className="px-0 pb-0 text-end">
                        <span className="text-body ps-2 align-self-center text-end fw-medium">
                          0.845236
                          <span className="badge rounded text-danger bg-danger-subtle">
                            0.22%
                          </span>
                        </span>
                      </td>
                    </tr>
                  </tbody>
                </table>
              </div>
              <hr className="hr-dashed" />
              <div className="row">
                <div className="col-lg-6 text-center">
                  <div className="p-2 border-dashed border-theme-color rounded">
                    <p className="text-muted text-uppercase mb-0 fw-normal fs-13">
                      Higher Rate
                    </p>
                    <h5 className="mt-1 mb-0 fw-medium text-success">
                      0.833658
                    </h5>
                    <small>05 Sep 2024</small>
                  </div>
                </div>
                <div className="col-lg-6 text-center">
                  <div className="p-2 border-dashed border-theme-color rounded">
                    <p className="text-muted text-uppercase mb-0 fw-normal fs-13">
                      Lower Rate
                    </p>
                    <h5 className="mt-1 mb-0 fw-medium text-danger">
                      0.812547
                    </h5>
                    <small>05 Sep 2024</small>
                  </div>
                </div>
              </div>
            </div>
          </div>
        </div>
      </div>
    </>
  );
};

export default Dashboard;
