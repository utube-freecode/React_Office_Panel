import React, { useCallback, useMemo, useState } from "react";
import { useQuery, useQueryClient } from "@tanstack/react-query";
import { debounce } from "lodash";
import { dateFormat } from "../../../helper/common";
import {
  DataTable,
  DisplayOrder,
  Filter,
  StaticBadge,
  SubHeading,
  Switch,
  TableOptions,
} from "../../../Components";
import {
  CommonModal,
  FancyLimitModal,
  FancyModal,
  ImportFancyModal,
  LimitModal,
  Message,
  SuspandModal,
} from "../../../Modal";
import {
  API_UPDATE_MARKET,
  API_GET_MARKET,
} from "../../../utils/api/ApiConstant";
import { postAxiosDataTable, putAxios } from "../../../Services/commonService";
import { useNavigate } from "react-router-dom";

const Fancy = () => {
  const [currentPage, setCurrentPage] = useState(1);
  const [recordsPerPage, setRecordsPerPage] = useState(50);
  const [searchTerm, setSearchTerm] = useState("");
  const [headerSort, setHeaderSort] = useState({ column: 0, dir: "asc" });
  const queryClient = useQueryClient();
  const navigate = useNavigate();
  const [isShow, setIsShow] = useState({
    isOpen: false,
    rowData: null,
    name: "",
    modalTitle: "",
    modalContent: null,
    apiFlag: false,
  });
  const [filterData, setFilterData] = useState({
    sportId: null,
    tournamentId: null,
    matchId: null,
  });

  const payload = useMemo(() => {
    return {
      draw: currentPage,
      length: recordsPerPage,
      search: {
        value: searchTerm,
        regex: false,
      },
      id: "5ebc1code68br4bik5b1808",
      columns: [
        {
          data: "",
          name: "",
          searchable: true,
          orderable: false,
          search: {
            value: "",
            regex: false,
          },
        },
        {
          data: "fancyName",
          name: "",
          searchable: true,
          orderable: true,
          search: {
            value: "",
            regex: false,
          },
        },
        {
          data: "match.name",
          name: "",
          searchable: true,
          orderable: true,
          search: {
            value: "",
            regex: false,
          },
        },
        {
          data: "createdAt",
          name: "",
          searchable: true,
          orderable: true,
          search: {
            value: "",
            regex: false,
          },
        },
        {
          data: "marketStartTime",
          name: "",
          searchable: true,
          orderable: true,
          search: {
            value: "",
            regex: false,
          },
        },
        {
          data: "isActive",
          name: "",
          searchable: true,
          orderable: true,
          search: {
            value: "",
            regex: false,
          },
        },
        {
          data: "isActive",
          name: "",
          searchable: true,
          orderable: true,
          search: {
            value: "",
            regex: false,
          },
        },
        {
          data: "allowBat",
          name: "",
          searchable: true,
          orderable: true,
          search: {
            value: "",
            regex: false,
          },
        },
        {
          data: "assignTo",
          name: "",
          searchable: true,
          orderable: true,
          search: {
            value: "",
            regex: false,
          },
        },
        {
          data: "fancyModeType",
          name: "",
          searchable: true,
          orderable: true,
          search: {
            value: "",
            regex: false,
          },
        },
        {
          data: "displayOrder",
          name: "",
          searchable: true,
          orderable: true,
          search: {
            value: "",
            regex: false,
          },
        },
      ],
      order: [headerSort],
      matchName: filterData.matchId,
    };
  }, [currentPage, recordsPerPage, searchTerm, filterData.matchId, headerSort]);

  const { isLoading, data } = useQuery({
    queryKey: [
      "fancyData",
      currentPage,
      recordsPerPage,
      searchTerm,
      filterData.matchId,
      isShow.apiFlag,
      headerSort,
    ],
    queryFn: async () => await postAxiosDataTable(API_GET_MARKET, payload),
  });

  const handleQueryClient = (rowData, updatedRowData, key) => {
    return queryClient.setQueryData(
      [
        "fancyData",
        currentPage,
        recordsPerPage,
        searchTerm,
        filterData.matchId,
        isShow.apiFlag,
        headerSort,
      ],
      (oldData) => {
        return {
          ...oldData,
          docs: oldData.docs.map((match) =>
            match._id === rowData._id
              ? { ...match, [key]: updatedRowData[key] }
              : match
          ),
        };
      }
    );
  };

  const handlePutRequest = async (rowData, newValue, key) => {
    const updatedRowData = {
      ...rowData,
      [key]: newValue,
    };

    const response = putAxios(
      `${API_UPDATE_MARKET}/${updatedRowData._id}`,
      updatedRowData
    );

    if (response) {
      handleQueryClient(rowData, updatedRowData, key);
      setIsShow((prev) => ({
        ...prev,
        isOpen: false,
        rowData: {},
        name: "",
        modalTitle: "",
      }));
    }
  };

  const columns = useMemo(
    () => [
      {
        accessorKey: "",
        header: "Actions",
        cell: ({ getValue, row }) => {
          const handleLimit = () => {
            setIsShow((prev) => ({
              ...prev,
              isOpen: true,
              rowData: row?.original,
              modalTitle: "Limit",
              modalContent: FancyLimitModal,
            }));
          };

          const handleSuspend = () => {
            setIsShow((prev) => ({
              ...prev,
              isOpen: true,
              rowData: row?.original,
              modalTitle: "Suspand Game",
              modalContent: SuspandModal,
            }));
          };

          const handleMessage = () => {
            setIsShow((prev) => ({
              ...prev,
              isOpen: true,
              rowData: row?.original,
              modalTitle: "Message show",
              modalContent: Message,
            }));
          };

          const handleRate = () => {
            navigate(`view/${row?.original?.fancyId}`, {
              state: {
                rowOriginalData: row?.original,
              },
            });
          };

          const tableOptions = {
            rate: handleRate,
            limit: handleLimit,
            suspend: handleSuspend,
            message: handleMessage,
          };

          return <TableOptions tableOptions={tableOptions} />;
        },
      },
      {
        accessorKey: "fancyName",
        header: "Fancy Name",
      },
      {
        accessorKey: "match.name",
        header: "Matches",
      },
      {
        accessorKey: "isActive",
        header: "isActive",
        cell: ({ getValue, row }) => {
          return (
            <Switch
              getValue={getValue}
              onChange={() => {
                handlePutRequest(row?.original, !getValue(), "isActive");
              }}
            />
          );
        },
      },
      {
        accessorKey: "allowBat",
        header: "Allow Bat",
        cell: ({ getValue, row }) => {
          return (
            <Switch
              getValue={getValue}
              onChange={() => {
                handlePutRequest(row?.original, !getValue(), "allowBat");
              }}
            />
          );
        },
      },
      {
        accessorKey: "displayOrder",
        header: "Display Order",
        cell: ({ row }) => {
          const initialValue = row.original.displayOrder;

          return (
            <DisplayOrder
              initialValue={initialValue}
              onConfirm={(newValue) => {
                handlePutRequest(row?.original, newValue, "displayOrder");
              }}
            />
          );
        },
      },
      {
        accessorKey: "assignTo.username",
        header: "AssignTo",
      },
      {
        accessorKey: "marketStatus.name",
        header: "Status",
      },
      {
        accessorKey: "marketStartTime",
        header: "Match Date",
        cell: ({ row }) =>
          dateFormat(row.original.marketStartTime).formattedDateTime,
      },
      {
        accessorKey: "createdAt",
        header: "Created Date",
        cell: ({ row }) => dateFormat(row.original.createdAt).formattedDateTime,
      },
      {
        accessorKey: "fancyModeType",
        header: "Type",
        cell: ({ getValue }) => <StaticBadge getValue={getValue} />,
      },
    ],
    []
  );

  const handlePageChange = (page) => {
    setCurrentPage(page);
  };

  const handleRecordsperPage = (value) => {
    setRecordsPerPage(value);
  };

  const handleSearch = (value) => {
    setSearchTerm(value);
    debouncedSearch(value);
  };

  const handleHeaderSort = ({ index, direction }) => {
    setHeaderSort({ column: index, dir: direction });
  };

  const fetchData = () => {
    if (!data) return { data: [], pages: 0 };

    return {
      data: data?.docs || [],
      pages: data?.pages || 0,
    };
  };

  const handleFilterParams = (filterParams) => {
    const { match } = filterParams;
    setFilterData({
      ...filterData,
      matchId: match?.value,
    });
  };

  return (
    <>
      <SubHeading
        subTitle="fancy list"
        handleShowHide={(value) =>
          setIsShow((prev) => ({
            ...prev,
            isOpen: true,
            rowData: {},
            name: "add",
            modalTitle: value === "add" ? "Add Fancy" : "Import Fancy",
            modalContent: value === "add" ? FancyModal : ImportFancyModal,
          }))
        }
        isImportBtn={true}
      />
      <Filter
        allMatch={true}
        handleFilterParams={handleFilterParams}
        apiParam="Fancy"
      />
      <div className="card-body">
        <DataTable
          columns={columns}
          fetchData={fetchData}
          currentPage={currentPage}
          onPageChange={handlePageChange}
          onRecordsPerPageChange={handleRecordsperPage}
          recordsPerPage={recordsPerPage}
          onSearchChange={handleSearch}
          isLoading={isLoading}
          handleHeaderSort={handleHeaderSort}
        />
      </div>

      <CommonModal
        isShow={isShow.isOpen}
        handleShowHide={() =>
          setIsShow((prev) => ({
            ...prev,
            isOpen: false,
            rowData: {},
            name: "",
          }))
        }
        modalTitle={isShow.modalTitle}
      >
        {isShow.modalContent &&
          React.createElement(isShow.modalContent, {
            handleShowHide: () =>
              setIsShow((prev) => ({
                ...prev,
                isOpen: false,
                rowData: {},
                name: "",
                modalTitle: "",
                apiFlag: !prev.apiFlag,
              })),
            rowData: isShow.rowData,
            handlePutRequest,
          })}
      </CommonModal>
    </>
  );
};

export default Fancy;
