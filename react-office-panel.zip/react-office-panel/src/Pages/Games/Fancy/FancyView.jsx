import React, { Fragment, useCallback, useEffect, useState } from "react";
import { useLocation, useParams } from "react-router-dom";

import {
  Button,
  Counter,
  Input,
  KeyValue,
  Label,
  Loading,
  SubHeading,
  Switch,
} from "../../../Components";
import { useEscapeKey } from "../../../Hooks";
import { getAxios, postAxios, putAxios } from "../../../Services/commonService";
import {
  API_COMMON_FANCY,
  API_FANCY_LATEST,
  API_FANCY_RATE,
  API_FANCY_VOLUME,
  API_UPDATE_MARKET,
} from "../../../utils/api/ApiConstant";
import { useQuery } from "@tanstack/react-query";
import {
  CommonModal,
  EndGameModal,
  FancyConfigureModal,
  FancySettingModal,
} from "../../../Modal";
import useSocketContext from "../../../context/socketContext";
import { useSelector } from "react-redux";

const FancyView = () => {
  const { user } = useSelector((state) => state.user);
  const { id } = useParams();
  const location = useLocation();
  const { rowOriginalData } = location.state;
  const [rowData, setRowData] = useState(rowOriginalData);
  const [rate, setRate] = useState();
  const [showRate, setShowRate] = useState();
  const [action, setAction] = useState("");
  const [middleInput, setMiddleInput] = useState({
    no: { rate: "", diff: "" },
    yes: { rate: "", diff: "" },
  });
  const [counter, setCounter] = useState(0);
  const [allowBetChecked, setAllowBetChecked] = useState(null);
  const [isShow, setIsShow] = useState({
    isOpen: false,
    rowData: null,
    name: "",
    modalTitle: "",
    modalContent: null,
    apiFlag: false,
  });
  const [endChar, setEndChar] = useState("");
  const { FancySocket } = useSocketContext();
  const [ballStartFlag, setBallStartFlag] = useState(null);

  const { data: fancyLatestData } = useQuery({
    queryKey: ["fancyLatestData"],
    queryFn: async () => await getAxios(`${API_FANCY_LATEST}/${id}`, {}),
  });

  const { data: fancyViewData } = useQuery({
    queryKey: ["fancyViewData"],
    queryFn: async () => await getAxios(`${API_COMMON_FANCY}/${id}`, {}),
  });

  const { isLoading: volumeLoad, data: fancyVolumeData } = useQuery({
    queryKey: ["fancyVolumeData"],
    queryFn: async () => await getAxios(API_FANCY_VOLUME, {}),
  });

  useEffect(() => {
    FancySocket.emit("join-room", id);
  }, []);

  const handleEvent = useCallback((data) => {
    const { rates } = data;

    setMiddleInput({
      no: {
        rate: rates?.["0"]?.rate_1 || "",
        diff: rates?.["0"]?.value_1 || "",
      },
      yes: {
        rate: rates?.["0"]?.rate_2 || "",
        diff: rates?.["0"]?.value_2 || "",
      },
    });
  }, []);

  useEffect(() => {
    FancySocket.on("fancy-auto-rate", handleEvent);

    return () => {
      FancySocket.emit("leave-room", id);
    };
  }, [FancySocket]);

  useEffect(() => {
    setAllowBetChecked(fancyViewData?.allowBat);
    setRate(fancyViewData?.rate?.[0]?.master_code_id);
    if (
      fancyViewData &&
      fancyViewData?.fancyMode &&
      fancyViewData?.fancyMode.toLowerCase() !== "auto"
    ) {
      handleActionClick("suspend");
    }
  }, [fancyViewData]);

  useEffect(() => {
    if (ballStartFlag !== null) {
      console.log(
        "🚀 ~ useEffect ~ rowData?.fancyConfigurationSetting?.ballStart:",
        rowData?.fancyConfigurationSetting?.ballStart
      );
      setCounter(rowData?.fancyConfigurationSetting?.ballStart);
    }
  }, [ballStartFlag]);

  const handleRate = (e) => {
    let { value } = e.target;

    if (value === "") setEndChar("");

    setShowRate(value);
    const lastChar = value[value.length - 1]; // Get the last character

    if (/[a-zA-Z]/.test(lastChar)) {
      value = value.slice(0, -1); // Remove the last character if it's an alphabet
      setEndChar(lastChar);
    }
    setRate(value);
  };

  const handleEscape = () => {
    setAction("Ball Start");
    setCounter(0);
    setMiddleInput({
      no: { rate: "", diff: "" },
      yes: { rate: "", diff: "" },
    });
  };
  useEscapeKey(handleEscape);

  const handleActionClick = (val) => {
    switch (val) {
      case "live":
        if (rate) {
          setCounter(rowData?.fancyConfigurationSetting?.ballStart || 0);
          setMiddleInput((prev) => ({
            ...prev,
            no: {
              rate: rate,
              diff: 100,
            },
            yes: {
              rate:
                rate + (rowData?.fancyConfigurationSetting?.rateDiffrence || 0),
              diff: 100,
            },
          }));
        } else {
          setCounter(0);
        }
        break;

      case "ball start":
      case "suspend":
        setCounter(0);
        setMiddleInput({
          no: { rate: "", diff: "" },
          yes: { rate: "", diff: "" },
        });
        break;

      default:
        console.warn(`Unhandled action: ${val}`);
        break;
    }

    setAction(val);
  };

  const handleInputChange = (e, key) => {
    const { name, value } = e.target;
    setMiddleInput((prev) => ({
      ...prev,
      [key]: {
        ...prev[key],
        [name]: value,
      },
    }));
  };

  const handleKeyDown = (e) => {
    if (e.key === "Enter") {
      handleActionClick("live");

      // matched volumn by
      let match;
      if (endChar) {
        match = fancyVolumeData.find(
          (item) => item.key.toLowerCase() === endChar.toLowerCase()
        );
      }

      setMiddleInput((prev) => ({
        ...prev,
        no: {
          rate: rate,
          diff: match?.value1 || 100,
        },
        yes: {
          rate:
            Number(rate) + rowData?.fancyConfigurationSetting?.rateDiffrence,
          diff: match?.value2 || 100,
        },
      }));

      // handle counter using flag state
      setBallStartFlag((prev) => !prev);

      // handle request
      const payload = {
        master_code_id: showRate,
        id,
        fancyId: id,
        no1: "",
        no1Vol: "",
        no2: rate,
        no2Vol: match?.value1 || 100,
        no3: "",
        no3Vol: "",
        yes1: "",
        yes1Vol: "",
        yes2: Number(rate) + rowData?.fancyConfigurationSetting?.rateDiffrence,
        yes2Vol: match?.value2 || 100,
        yes3: "",
        yes3Vol: "",
        limit: "",
        statusValue: [
          {
            id: "MS960523",
            name: "active",
            value: "ACTIVE",
          },
        ],
        userId: user.user_id,
        userName: user.username,
      };
      handlePostRequest({ url: API_FANCY_RATE, payload, modalRequest: false });
    }
  };

  const countFinish = () => {
    setAction("ball start");
    setMiddleInput({
      no: { rate: "", diff: "" },
      yes: { rate: "", diff: "" },
    });
  };

  const handlePutRequest = async ({
    url,
    payload,
    modalRequest = false,
    updateRowData = false,
  }) => {
    const res = await putAxios(url, payload);

    if (res && updateRowData) setRowData(res);
    if (modalRequest && res) {
      setIsShow((prev) => ({
        ...prev,
        isOpen: false,
        rowData: {},
        name: "",
      }));
    }
  };

  const handlePostRequest = async ({ url, payload, modalRequest = false }) => {
    const res = await postAxios(url, payload);

    if (modalRequest && res) {
      setIsShow((prev) => ({
        ...prev,
        isOpen: false,
        rowData: {},
        name: "",
      }));
    }
  };

  return (
    <>
      <SubHeading subTitle={rowData?.fancyName} isAddBtn={false} />
      <div className="card-body">
        <div className="row">
          <div className="col-md-12 m-0 p-1">
            <div className="setting_but_box">
              <div className="d-flex">
                <Label htmlFor="allowBat">Allow bet</Label>
                <div className="form-check form-switch form-switch-success">
                  <input
                    className="form-check-input"
                    type="checkbox"
                    name="allowBat"
                    checked={allowBetChecked}
                    onChange={(e) => {
                      e.target.blur();
                      setAllowBetChecked(!allowBetChecked);
                      handlePutRequest({
                        url: `${API_UPDATE_MARKET}/${rowData?._id}`,
                        payload: {
                          ...rowData,
                          allowBat: !allowBetChecked,
                        },
                        modalRequest: true,
                      });
                    }}
                    value={allowBetChecked}
                    onFocus={(e) => e.target.blur()}
                  />
                </div>
              </div>

              <Button
                className="btn-primary btn-sm"
                onClick={() =>
                  setIsShow((prev) => ({
                    ...prev,
                    isOpen: true,
                    rowData: rowData,
                    modalTitle: "End game",
                    modalContent: EndGameModal,
                  }))
                }
              >
                End game
              </Button>
              <Button
                className="btn-primary btn-sm"
                onClick={() =>
                  setIsShow((prev) => ({
                    ...prev,
                    isOpen: true,
                    rowData: rowData,
                    modalTitle: "Fancy Configure",
                    modalContent: FancyConfigureModal,
                  }))
                }
              >
                Fancy Configure
              </Button>
              <Button
                className="btn-primary btn-sm"
                onClick={() =>
                  setIsShow((prev) => ({
                    ...prev,
                    isOpen: true,
                    rowData: rowData,
                    modalTitle: "Fancy Setting",
                    modalContent: FancySettingModal,
                  }))
                }
              >
                Fancy Setting
              </Button>
            </div>
          </div>
          <div className="col-12 m-0 p-0">
            <div className="row m-0 p-0 mb-2">
              {volumeLoad ? (
                <Loading />
              ) : (
                fancyVolumeData &&
                fancyVolumeData.map((x, i) => (
                  <Fragment key={i}>
                    <KeyValue obj={x} />
                  </Fragment>
                ))
              )}
            </div>
          </div>

          <div className="col-lg-6  m-0 p-1 ">
            <div className="card ">
              <div className="row m-0 p-0">
                <div className="col-12 m-0 p-1">
                  <p className="m-0 p-0 py-1 ">
                    Action counter:
                    <Counter
                      initialValue={counter}
                      countFinish={countFinish}
                      ballRestart={ballStartFlag}
                    />
                  </p>
                </div>
                <div className="col-12 m-0 p-1 mb-1">
                  <Input
                    type="text"
                    className="form-control w-100 py-2 form-select-lg text-center"
                    placeholder="Enter rate"
                    onChange={handleRate}
                    value={showRate}
                    onKeyDown={handleKeyDown}
                    disabled={
                      fancyViewData && fancyViewData?.fancyMode
                        ? fancyViewData?.fancyMode.toLowerCase() === "auto"
                        : false
                    }
                  />
                </div>
                <div className="col-lg-6 m-0 p-1">
                  <Button
                    className="btn-success w-100 py-3 btn-lg"
                    onClick={() => handleActionClick("live")}
                  >
                    Live
                  </Button>
                </div>
                <div className="col-lg-6 m-0 p-1">
                  <Button
                    className="btn-primary w-100 py-3 btn-lg"
                    onClick={() => handleActionClick("ball start")}
                  >
                    Ball Start
                  </Button>
                </div>
                <div className="col-lg-12 m-0 p-1">
                  <Button
                    className="btn-secondary w-100 btn-lg py-3"
                    onClick={() => handleActionClick("suspend")}
                  >
                    Suspend
                  </Button>
                </div>
              </div>
            </div>
          </div>

          <div className="col-md-6 m-0 p-1 ">
            <div className="card ">
              <div className="row m-0 p-0  ">
                <div className="col-lg-12 m-0 p-1">
                  <ul className="market_box">
                    <li className="market market_bg-a">No</li>
                    <li className="market market_bg-b">Yes</li>
                  </ul>
                </div>

                <div className="col-lg-12 m-0 p-1">
                  <Input
                    type="text"
                    className="form-control w-100 py-2 form-select-lg"
                    value={action}
                    disabled={true}
                  />
                </div>
                <div className="col-lg-12 m-0 p-1">
                  <div className="row m-0 p-0">
                    <div className="col-lg-6 m-0 p-1">
                      <div className="enter_market_box">
                        <Input
                          type="text"
                          className="form-control market_bg-a market_card  "
                          placeholder=""
                          value=""
                          disabled={true}
                        />
                        <Input
                          type="text"
                          className="form-control market_bg-a market_card "
                          placeholder=""
                          value=""
                          disabled={true}
                        />
                      </div>
                      <div className="enter_market_box">
                        <Input
                          type="text"
                          className="form-control market_bg-a market_card  "
                          placeholder=""
                          value={middleInput.no.rate}
                          name="rate"
                          onChange={(e) => handleInputChange(e, "no")}
                          disabled={true}
                        />
                        <Input
                          type="text"
                          className="form-control market_bg-a market_card  "
                          placeholder=""
                          value={middleInput.no.diff}
                          name="diff"
                          onChange={(e) => handleInputChange(e, "no")}
                          disabled={true}
                        />
                      </div>
                      <div className="enter_market_box">
                        <Input
                          type="text"
                          className="form-control market_bg-a market_card  "
                          placeholder=""
                          value=""
                          disabled={true}
                        />
                        <Input
                          type="text"
                          className="form-control  market_bg-a market_card  "
                          placeholder=""
                          value=""
                          disabled={true}
                        />
                      </div>
                    </div>
                    <div className="col-lg-6 m-0 p-1">
                      <div className="enter_market_box">
                        <Input
                          type="text"
                          className="form-control market_bg-b market_card "
                          placeholder=""
                          value=""
                          disabled={true}
                        />
                        <Input
                          type="text"
                          className="form-control market_bg-b market_card "
                          placeholder=""
                          value=""
                          disabled={true}
                        />
                      </div>
                      <div className="enter_market_box">
                        <Input
                          type="text"
                          className="form-control market_bg-b market_card "
                          placeholder=""
                          value={middleInput.yes.rate}
                          name="rate"
                          onChange={(e) => handleInputChange(e, "yes")}
                        />
                        <Input
                          type="text"
                          className="form-control market_bg-b market_card "
                          placeholder=""
                          value={middleInput.yes.diff}
                          name="diff"
                          onChange={(e) => handleInputChange(e, "yes")}
                        />
                      </div>
                      <div className="enter_market_box">
                        <Input
                          type="text"
                          className="form-control market_bg-b market_card "
                          placeholder=""
                          value=""
                          disabled={true}
                        />
                        <Input
                          type="text"
                          className="form-control market_bg-b market_card "
                          placeholder=""
                          value=""
                          disabled={true}
                        />
                      </div>
                    </div>
                  </div>
                </div>
              </div>
            </div>
          </div>
        </div>
      </div>

      <CommonModal
        isShow={isShow.isOpen}
        handleShowHide={() =>
          setIsShow((prev) => ({
            ...prev,
            isOpen: false,
            rowData: {},
            name: "",
          }))
        }
        modalTitle={isShow.modalTitle}
      >
        {isShow.modalContent &&
          React.createElement(isShow.modalContent, {
            handleShowHide: () =>
              setIsShow((prev) => ({
                ...prev,
                isOpen: false,
                rowData: {},
                name: "",
                modalTitle: "",
                apiFlag: !prev.apiFlag,
              })),
            rowData: isShow.rowData,
            handlePutRequest,
            handlePostRequest,
          })}
      </CommonModal>
    </>
  );
};

export default FancyView;
