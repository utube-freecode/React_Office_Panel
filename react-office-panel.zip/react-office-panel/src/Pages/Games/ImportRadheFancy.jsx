import React from "react";
import { useQuery } from "@tanstack/react-query";
import { useNavigate } from "react-router-dom";
import Loading from "../../Components/UI/Loading";
import { API_GET_IMPORTRADHEFANCY } from "../../utils/api/ApiConstant";
import { getAxios } from "../../Services/commonService";

const ImportRadheFancy = () => {
  const navigate = useNavigate();
  const { isLoading, data } = useQuery({
    queryKey: ["importRadheFancy"],
    queryFn: async () => await getAxios(API_GET_IMPORTRADHEFANCY, {}),
  });

  return (
    <div className="table-responsive">
      <table
        style={{ borderCollapse: "collapse", width: "100%" }}
        className="table table-striped table-auto"
      >
        <thead className="table-light">
          <tr>
            <th>No.</th>
            <th className="text-start">Game Name</th>
            <th className="text-start">Market ID</th>
            <th className="text-start">Game Time</th>
          </tr>
        </thead>
        <tbody>
          {isLoading ? (
            <tr>
              <td colSpan="5" style={{ textAlign: "center" }}>
                <Loading />
              </td>
            </tr>
          ) : (
            data &&
            Object.keys(data).map((key, i) => {
              const game = data[key];
              return (
                <tr key={game.game_srno}>
                  <td>{i + 1}</td>
                  <td
                    className="cursor-pointer text-start"
                    onClick={() =>
                      navigate(`/eventmaster/ImportRadheFancy/${game.marketid}`)
                    }
                  >
                    {game.game_name}
                  </td>
                  <td className="text-start">{game.marketid}</td>
                  <td className="text-start">
                    {new Date(game.game_time).toLocaleString()}
                  </td>
                </tr>
              );
            })
          )}
        </tbody>
      </table>
    </div>
  );
};

export default ImportRadheFancy;
