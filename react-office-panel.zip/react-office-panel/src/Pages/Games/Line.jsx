import React, { useCallback, useMemo, useState } from "react";
import { useQuery } from "@tanstack/react-query";
import { debounce } from "lodash";
import { useSelector } from "react-redux";

import { dateFormat } from "../../helper/common";
import { DataTable, Filter, SubHeading } from "../../Components";
import { postAxiosDataTable } from "../../Services/commonService";
import { API_GET_LINE } from "../../utils/api/ApiConstant";

const Line = () => {
  const [currentPage, setCurrentPage] = useState(1);
  const [recordsPerPage, setRecordsPerPage] = useState(50);
  const [searchTerm, setSearchTerm] = useState("");
  const { user } = useSelector((state) => state.user);
  const [headerSort, setHeaderSort] = useState({ column: 0, dir: "asc" });
  const [filterData, setFilterData] = useState({
    sportId: null,
    tournamentId: null,
    matchId: null,
  });

  const payload = useMemo(() => {
    return {
      draw: currentPage,
      length: recordsPerPage,
      search: {
        value: searchTerm,
        regex: false,
      },
      id: user?.user_id,
      columns: [
        {
          data: "",
          name: "",
          searchable: true,
          orderable: false,
          search: {
            value: "",
            regex: false,
          },
        },
        {
          data: "fancyName",
          name: "",
          searchable: true,
          orderable: true,
          search: {
            value: "",
            regex: false,
          },
        },
        {
          data: "match.name",
          name: "",
          searchable: true,
          orderable: true,
          search: {
            value: "",
            regex: false,
          },
        },
        {
          data: "createdAt",
          name: "",
          searchable: true,
          orderable: true,
          search: {
            value: "",
            regex: false,
          },
        },
        {
          data: "marketStartTime",
          name: "",
          searchable: true,
          orderable: true,
          search: {
            value: "",
            regex: false,
          },
        },
        {
          data: "isActive",
          name: "",
          searchable: true,
          orderable: true,
          search: {
            value: "",
            regex: false,
          },
        },
        {
          data: "isActive",
          name: "",
          searchable: true,
          orderable: true,
          search: {
            value: "",
            regex: false,
          },
        },
        {
          data: "allowBat",
          name: "",
          searchable: true,
          orderable: true,
          search: {
            value: "",
            regex: false,
          },
        },
        {
          data: "assignTo",
          name: "",
          searchable: true,
          orderable: true,
          search: {
            value: "",
            regex: false,
          },
        },
        {
          data: "fancyModeType",
          name: "",
          searchable: true,
          orderable: true,
          search: {
            value: "",
            regex: false,
          },
        },
        {
          data: "displayOrder",
          name: "",
          searchable: true,
          orderable: true,
          search: {
            value: "",
            regex: false,
          },
        },
      ],
      order: [headerSort],
      matchName: filterData.matchId,
    };
  }, [currentPage, recordsPerPage, searchTerm, filterData.matchId, headerSort]);

  const { data, isLoading } = useQuery({
    queryKey: [
      "lineData",
      currentPage,
      recordsPerPage,
      searchTerm,
      filterData.matchId,
      headerSort,
    ],
    queryFn: async () => await postAxiosDataTable(API_GET_LINE, payload),
  });

  const columns = useMemo(
    () => [
      {
        accessorKey: "fancyName",
        header: "Line Name",
      },
      {
        accessorKey: "match.name",
        header: "Matches",
      },
      {
        accessorKey: "isActive",
        header: "isActive",
        cell: ({ getValue }) => (
          <div className="form-check form-switch form-switch-success">
            <input
              className="form-check-input"
              type="checkbox"
              checked={getValue()}
              onChange={() => console.log(123)}
            />
          </div>
        ),
      },
      {
        accessorKey: "allowBat",
        header: "Allow Bat",
        cell: ({ getValue }) => (
          <div className="form-check form-switch form-switch-success">
            <input
              className="form-check-input"
              type="checkbox"
              checked={getValue()}
              onChange={() => console.log(123)}
            />
          </div>
        ),
      },
      {
        accessorKey: "displayOrder",
        header: "Display Order",
        cell: ({ getValue, row }) => (
          <div className="d-flex align-items-center">
            <input
              className="form-control input_cuter_box "
              type="text"
              value={row?.original?.displayOrder}
              id="example-text-input"
            ></input>
            <div className="form-check form-switch form-switch-success">
              <input
                className="form-check-input"
                type="checkbox"
                checked={getValue()}
                onChange={() => console.log(123)}
              />
            </div>
          </div>
        ),
      },
      {
        accessorKey: "assignTo.username",
        header: "AssignTo",
      },
      {
        accessorKey: "marketStatus.name",
        header: "Status",
        cell: ({ getValue }) => {
          const value = getValue();
          const flag = value ? "success" : "danger";
          return (
            <span className={`badge bg-${flag}-subtle text-${flag}`}>
              {value ? "OPEN" : "CLOSE"}
            </span>
          );
        },
      },
      {
        accessorKey: "marketStartTime",
        header: "Match Date",
        cell: ({ row }) =>
          dateFormat(row.original.marketStartTime).formattedDateTime,
      },
      {
        accessorKey: "createdAt",
        header: "Created Date",
        cell: ({ row }) => dateFormat(row.original.createdAt).formattedDateTime,
      },
      {
        accessorKey: "fancyModeType",
        header: "Type",
        cell: ({ getValue }) => (
          <span className={`badge bg-primary-subtle text-primary`}>
            {getValue()}
          </span>
        ),
      },
    ],
    []
  );

  const handlePageChange = (page) => {
    setCurrentPage(page);
  };

  const handleRecordsperPage = (value) => {
    setRecordsPerPage(value);
  };

  const handleSearch = (value) => {
    setSearchTerm(value);
    debouncedSearch(value);
  };

  const handleHeaderSort = ({ index, direction }) => {
    setHeaderSort({ column: index, dir: direction });
  };

  const fetchData = () => {
    if (!data) return { data: [], pages: 0 };

    return {
      data: data?.docs || [],
      pages: data?.pages || 0,
    };
  };

  const handleFilterParams = (filterParams) => {
    const { match } = filterParams;
    setFilterData({
      ...filterData,
      matchId: match?.value,
    });
  };

  return (
    <>
      <SubHeading subTitle="line list" isAddBtn={false} />
      <Filter
        allMatch={true}
        handleFilterParams={handleFilterParams}
        apiParam="Line"
      />
      <div className="card-body">
        <DataTable
          columns={columns}
          fetchData={fetchData}
          currentPage={currentPage}
          onPageChange={handlePageChange}
          onRecordsPerPageChange={handleRecordsperPage}
          recordsPerPage={recordsPerPage}
          onSearchChange={handleSearch}
          isLoading={isLoading}
          handleHeaderSort={handleHeaderSort}
        />
      </div>
    </>
  );
};

export default Line;
