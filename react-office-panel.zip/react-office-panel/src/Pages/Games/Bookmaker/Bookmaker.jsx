import { debounce } from "lodash";
import React, { useCallback, useState } from "react";
import { useSelector } from "react-redux";
import { useQuery, useQueryClient } from "@tanstack/react-query";

import { dateFormat } from "../../../helper/common";
import {
  DataTable,
  DisplayOrder,
  SubHeading,
  TableOptions,
} from "../../../Components";
import { postAxiosDataTable, putAxios } from "../../../Services/commonService";
import {
  API_GET_BOOKMAKER,
  API_UPDATE_MARKET,
} from "../../../utils/api/ApiConstant";
import {
  AddBookmakerModal,
  CommonModal,
  ConfimationModal,
  LimitBookmakerModal,
  LimitMarketModal,
  Message,
  SuspandModal,
} from "../../../Modal";
import { useNavigate } from "react-router-dom";

const Bookmaker = () => {
  const navigate = useNavigate();
  const [currentPage, setCurrentPage] = useState(1);
  const [recordsPerPage, setRecordsPerPage] = useState(50);
  const [searchTerm, setSearchTerm] = useState("");
  const [headerSort, setHeaderSort] = useState({ column: 0, dir: "asc" });
  const { user } = useSelector((state) => state.user);
  const [isShow, setIsShow] = useState({
    isOpen: false,
    rowData: null,
    name: "",
    modalTitle: "",
    modalContent: null,
    apiFlag: false,
  });
  const queryClient = useQueryClient();

  const payload = {
    draw: currentPage,
    columns: [
      {
        data: "id",
        name: "",
        searchable: true,
        orderable: false,
        search: {
          value: "",
          regex: false,
        },
      },
      {
        data: "marketType",
        name: "",
        searchable: true,
        orderable: true,
        search: {
          value: "",
          regex: false,
        },
      },
      {
        data: "displayName",
        name: "",
        searchable: true,
        orderable: true,
        search: {
          value: "",
          regex: false,
        },
      },
      {
        data: "match.name",
        name: "",
        searchable: true,
        orderable: true,
        search: {
          value: "",
          regex: false,
        },
      },
      {
        data: "createdAt",
        name: "",
        searchable: true,
        orderable: true,
        search: {
          value: "",
          regex: false,
        },
      },
      {
        data: "marketStartTime",
        name: "",
        searchable: true,
        orderable: true,
        search: {
          value: "",
          regex: false,
        },
      },
      {
        data: "isActive",
        name: "",
        searchable: true,
        orderable: true,
        search: {
          value: "",
          regex: false,
        },
      },
      {
        data: "isActive",
        name: "",
        searchable: true,
        orderable: true,
        search: {
          value: "",
          regex: false,
        },
      },
      {
        data: "allowBat",
        name: "",
        searchable: true,
        orderable: true,
        search: {
          value: "",
          regex: false,
        },
      },
      {
        data: "bookmakerMode",
        name: "",
        searchable: true,
        orderable: true,
        search: {
          value: "",
          regex: false,
        },
      },
      {
        data: "assignTo.name",
        name: "",
        searchable: true,
        orderable: true,
        search: {
          value: "",
          regex: false,
        },
      },
      {
        data: "displayOrder",
        name: "",
        searchable: true,
        orderable: true,
        search: {
          value: "",
          regex: false,
        },
      },
      {
        data: "",
        name: "",
        searchable: true,
        orderable: true,
        search: {
          value: "",
          regex: false,
        },
      },
    ],
    order: [headerSort],
    start: (currentPage - 1) * recordsPerPage,
    length: recordsPerPage,
    search: {
      value: searchTerm,
      regex: false,
    },
    filter: {
      page: 1,
      limit: 10,
      search: null,
    },
    id: "5ebc1code68br4bik5b0810",
    userId: user?.user_id,
  };

  const handlePageChange = (page) => {
    setCurrentPage(page);
  };

  const handleRecordsperPage = (value) => {
    setRecordsPerPage(value);
  };

  const handleSearch = (value) => {
    setSearchTerm(value);
    debouncedSearch(value);
  };

  const handleHeaderSort = ({ index, direction }) => {
    setHeaderSort({ column: index, dir: direction });
  };

  const { data, isLoading } = useQuery({
    queryKey: [
      "bookmakerData",
      currentPage,
      recordsPerPage,
      searchTerm,
      isShow.apiFlag,
      headerSort,
    ],
    queryFn: async () => await postAxiosDataTable(API_GET_BOOKMAKER, payload),
  });

  const fetchData = () => {
    if (!data) return { data: [], pages: 0 };

    return {
      data: data.docs,
      pages: data.pages,
    };
  };

  const columns = [
    {
      accessorKey: "action",
      header: "actions",
      cell: ({ row }) => {
        const handleSuspend = () => {
          setIsShow((prev) => ({
            ...prev,
            isOpen: true,
            rowData: row?.original,
            modalTitle: "Suspand Game",
            modalContent: SuspandModal,
          }));
        };

        const handleMessage = () => {
          setIsShow((prev) => ({
            ...prev,
            isOpen: true,
            rowData: row?.original,
            modalTitle: "Add Message",
            modalContent: Message,
          }));
        };

        const handleLimit = () => {
          setIsShow((prev) => ({
            ...prev,
            isOpen: true,
            rowData: row?.original,
            modalTitle: "Edit Limit",
            modalContent: LimitBookmakerModal,
          }));
        };

        const handleRate = () => {
          navigate(`view/${row?.original?.marketId}`, {
            state: {
              rowOriginalData: row?.original,
            },
          });
        };

        const tableOptions = {
          Rate: handleRate,
          Suspend: handleSuspend,
          Message: handleMessage,
          Limit: handleLimit,
        };
        return (
          <>
            <TableOptions tableOptions={tableOptions} />
          </>
        );
      },
    },
    {
      accessorKey: "marketType",
      header: "Market",
    },
    {
      accessorKey: "displayName",
      header: "Market Name",
    },
    {
      accessorKey: "createdAt",
      header: "Created Time",
      cell: ({ getValue }) => {
        const value = getValue();
        return dateFormat(value).formattedDateTime;
      },
    },
    {
      accessorKey: "marketStartTime",
      header: "Matched Time",
      cell: ({ getValue }) => {
        const value = getValue();
        return dateFormat(value).formattedDateTime;
      },
    },
    {
      accessorKey: "isActive",
      header: "Is Active",
      cell: ({ getValue, row }) => (
        <ConfimationModal
          isSwitch={true}
          getValue={() => getValue()}
          onStatusChange={(newValue) =>
            handlePutRequest(row?.original, newValue, "isActive")
          }
        />
      ),
    },
    {
      accessorKey: "allowBat",
      header: "Allow Bet",
      cell: ({ getValue, row }) => (
        <ConfimationModal
          isSwitch={true}
          getValue={() => getValue()}
          onStatusChange={(newValue) =>
            handlePutRequest(row?.original, newValue, "allowBat")
          }
        />
      ),
    },
    {
      accessorKey: "bookmakerMode",
      header: "Type",
    },
    {
      accessorKey: "assignTo.name",
      header: "Assign TO",
    },
    {
      accessorKey: "displayOrder",
      header: "display order",
      cell: ({ row }) => {
        const initialValue = row.original.displayOrder;

        return (
          <div className="d-flex">
            <DisplayOrder
              initialValue={initialValue}
              onConfirm={(newValue) =>
                handlePutRequest(row?.original, newValue, "displayOrder")
              }
            />
          </div>
        );
      },
    },
  ];

  const handleQueryClient = (rowData, updatedRowData, key) => {
    return queryClient.setQueryData(
      [
        "bookmakerData",
        currentPage,
        recordsPerPage,
        searchTerm,
        isShow.apiFlag,
        headerSort,
      ],
      (oldData) => {
        return {
          ...oldData,
          docs: oldData.docs.map((obj) =>
            obj._id === rowData._id
              ? { ...obj, [key]: updatedRowData[key] }
              : obj
          ),
        };
      }
    );
  };

  const handlePutRequest = async (rowData, value, key) => {
    const payload = { ...rowData, [key]: value };
    const url = `${API_UPDATE_MARKET}/${rowData?._id}`;
    const res = await putAxios(url, payload);

    if (res) {
      handleQueryClient(rowData, payload, key);
      setIsShow((prev) => ({
        ...prev,
        isOpen: false,
        rowData: {},
        name: "",
      }));
    }
  };

  return (
    <>
      <SubHeading
        subTitle="bookmaker list"
        handleShowHide={(value) =>
          setIsShow((prev) => ({
            ...prev,
            isOpen: true,
            rowData: {},
            name: "add",
            modalTitle: value === "add" ? "Add Bookmaker" : "",
            modalContent: value === "add" ? AddBookmakerModal : null,
          }))
        }
      />
      <div className="card-body">
        <DataTable
          columns={columns}
          fetchData={fetchData}
          currentPage={currentPage}
          onPageChange={handlePageChange}
          onRecordsPerPageChange={handleRecordsperPage}
          recordsPerPage={recordsPerPage}
          onSearchChange={handleSearch}
          isLoading={isLoading}
          handleHeaderSort={handleHeaderSort}
        />
      </div>

      <CommonModal
        isShow={isShow.isOpen}
        handleShowHide={() =>
          setIsShow((prev) => ({
            ...prev,
            isOpen: false,
            rowData: {},
            name: "",
          }))
        }
        modalTitle={isShow.modalTitle}
      >
        {isShow.modalContent &&
          React.createElement(isShow.modalContent, {
            handleShowHide: () =>
              setIsShow((prev) => ({
                ...prev,
                isOpen: false,
                rowData: {},
                name: "",
                modalTitle: "",
                apiFlag: !prev.apiFlag,
              })),
            rowData: isShow.rowData,
            handlePutRequest,
          })}
      </CommonModal>
    </>
  );
};

export default Bookmaker;
