import React, { useCallback, useEffect, useMemo, useState } from "react";
import { Button } from "react-bootstrap";
import { useLocation, useParams } from "react-router-dom";

import { getAxios, postAxios, putAxios } from "../../../Services/commonService";
import {
  API_BOOKMAKER_ADD_RATE,
  API_BOOKMAKER_LATEST_RATE,
  API_GET_BOOKMAKER,
} from "../../../utils/api/ApiConstant";
import { useQuery } from "@tanstack/react-query";
import { Label, SubHeading } from "../../../Components";
import { cleanUpValue } from "../../../helper/common";
import {
  BookmakerMessage,
  BookmakerSetting,
  CommonModal,
} from "../../../Modal";
import showToast from "../../../utils/toastUtil";
import { useSelector } from "react-redux";

const VOLUME = [
  {
    backVol: 0,
    layVol: 0,
  },
  {
    backVol: 0,
    layVol: 0.5,
  },
  {
    backVol: 0.5,
    layVol: 0,
  },
  {
    backVol: 0.5,
    layVol: 0.5,
  },
  {
    backVol: 0.25,
    layVol: 0.25,
  },
  {
    backVol: 0.75,
    layVol: 0.75,
  },
  {
    backVol: 0.25,
    layVol: 0.5,
  },
  {
    backVol: 0.25,
    layVol: 0.75,
  },
  {
    backVol: 0,
    layVol: 0.75,
  },
  {
    backVol: 0.25,
    layVol: 1,
  },
  {
    backVol: 0.5,
    layVol: 1.25,
  },
  {
    backVol: 0.75,
    layVol: 1.25,
  },
];
const VARIATION = [0, 1, 2, 3, 4, 5, 6, 7, 8, 9, 10, 11, 12, 13, 14, 15];

const BookmakerView = () => {
  const { user } = useSelector((state) => state.user);
  const { id } = useParams();
  const location = useLocation();
  const { rowOriginalData } = location.state;
  const [rowData, setRowData] = useState(rowOriginalData);
  const [rate, setRate] = useState(0);
  const [prevNum, setPrevNum] = useState([]);
  const [nextNum, setNextNum] = useState([]);
  const [isShow, setIsShow] = useState({
    isOpen: false,
    rowData: null,
    name: "",
    modalTitle: "",
    modalContent: null,
    apiFlag: false,
  });
  const [allRunners, setAllRunners] = useState([]);
  const [selectedRunner, setSelectedRunner] = useState(null);
  const [action, setAction] = useState(null);
  const [volume, setVolume] = useState({
    backVol: 0,
    layVol: 0,
  });
  const [variation, setVariation] = useState(0);
  const [isBoth, setIsBoth] = useState(false);

  const { data: bmkLatestData } = useQuery({
    queryKey: ["bmkLatestData"],
    queryFn: async () =>
      await getAxios(`${API_BOOKMAKER_LATEST_RATE}/${id}`, {}),
  });

  const { data: bmkMarketData } = useQuery({
    queryKey: ["bmkMarketData"],
    queryFn: async () => await getAxios(`${API_GET_BOOKMAKER}/${id}`, {}),
  });

  useEffect(() => {
    if (bmkMarketData && bmkMarketData?.runners) setRowData(bmkMarketData);
  }, [bmkMarketData]);

  useEffect(() => {
    if (rowData && rowData?.runners) {
      const tempObj = rowData?.runners.map((runner, i) => ({
        ...runner,
        backVol: rowData?.bookmakerSetting?.maxStack,
        layVol: rowData?.bookmakerSetting?.maxStack,
      }));

      setAllRunners(tempObj);
    }
  }, [rowData]);

  useEffect(() => {
    if (action) {
      handleActionRequest({
        statusVal: action,
        bothVal: selectedRunner === null ? true : false,
      });
    }
  }, [action]);

  useEffect(() => {
    if (isBoth) setSelectedRunner(null);
  }, [isBoth]);

  const handleRateChange = (e) => {
    let value = parseInt(e.target.value);
    value = Math.max(0, value);
    setRate(value);
  };

  const handleNumbersCount = () => {
    let previousNumbers;
    let nextNumbers;

    if (rate === "") {
      previousNumbers = [];
      nextNumbers = [];
    }

    if (rate === 0) {
      previousNumbers = [1, 2, 3, 4, 5, 6, 7, 8, 9, 10, 11, 12, 13, 14, 15];
    } else {
      previousNumbers = Array.from(
        { length: 15 },
        (_, i) => rate - (15 - i)
      ).filter((num) => num > 0);
    }

    nextNumbers = Array.from({ length: 15 }, (_, i) => rate + (i + 1)).filter(
      (num) => num > 0
    );

    setPrevNum(previousNumbers);
    setNextNum(nextNumbers);
  };

  const handleEnter = (e) => {
    if (e.key === "Enter") {
      if (!selectedRunner && !isBoth) {
        showToast.error("Please select runner");
        return;
      } else {
        // reset action as active

        setAction((prev) => {
          if (prev === "active") {
            handleActionRequest({ statusVal: "active" });
          }
          return "active";
        });

        // number handler
        handleNumbersCount();
      }
    }
  };

  const handlePutRequest = async ({
    url,
    payload,
    modalRequest = false,
    updateRowData = false,
  }) => {
    const res = await putAxios(url, payload);

    if (res && updateRowData) setRowData(res);
    if (modalRequest && res) {
      setIsShow((prev) => ({
        ...prev,
        isOpen: false,
        rowData: {},
        name: "",
      }));
    }
  };

  const handlePostRequest = async ({ url, payload, modalRequest = false }) => {
    const res = await postAxios(url, payload);

    if (modalRequest && res) {
      setIsShow((prev) => ({
        ...prev,
        isOpen: false,
        rowData: {},
        name: "",
      }));
    }
  };

  const handleMarketStatus = ({ status }) => {
    let marketStatus;
    switch (status) {
      case "suspend":
        marketStatus = {
          name: "SUSPENDED",
          id: "MS940896",
        };
        break;

      case "ballstart":
        marketStatus = {
          value: "BALLSTART",
          name: "ballstart",
          id: "MS950763",
        };
        break;

      case "active":
        marketStatus = {
          name: "OPEN",
          id: "MS081893",
        };
        break;
    }

    return marketStatus;
  };

  const handleActionRequest = useCallback(({ statusVal, bothVal = false }) => {
    try {
      // return false if statusVal is null or undefined or ""
      if (statusVal === null || statusVal === undefined || statusVal === "")
        return;

      // return false if runner is not selected
      if (!selectedRunner && !bothVal) {
        showToast.error("Please select runner");
        return;
      }

      // create common runner
      let modifyRunners;

      // set runners according to actions
      if (bothVal) {
        modifyRunners = allRunners.map((runner) => ({
          ...runner,
          backRate: rate,
          layRate: 0,
          status: {
            name: "open",
            id: "MS081893",
          },
        }));
        setSelectedRunner(null);
      } else {
        const findIndex = allRunners.findIndex(
          (x) => x.selectionId === selectedRunner.selectionId
        );

        if (findIndex >= 0) {
          modifyRunners = allRunners.map((runner, index) => {
            if (index === findIndex) {
              return {
                ...runner,
                backRate: rate + (volume?.backVol ?? 0),
                layRate: rate + ((volume?.layVol ?? 0) + (variation ?? 0)),
                status: {
                  name: "open",
                  id: "MS081893",
                },
              };
            } else {
              return {
                ...runner,
                backRate: 0,
                layRate: 0,
                status: {
                  id: "MS940896",
                  name: "suspend",
                  value: "SUSPENDED",
                },
              };
            }
          });
        }
      }
      setAllRunners(modifyRunners);

      // handle add bookmaker rate request
      const payload = {
        marketId: id,
        rate,
        variation,
        runners: modifyRunners,
        volume,
        selectedRunner: bothVal ? "both" : selectedRunner.selectionId,
        marketStatus: handleMarketStatus({ status: action }),
        userId: user?.user_id,
        userName: user?.username,
      };

      handlePostRequest({ url: API_BOOKMAKER_ADD_RATE, payload });
    } catch (error) {
      console.log("🚀 ~ handleActionRequest ~ error:", error);
    }
  });

  return (
    <>
      <SubHeading
        subTitle={`Bookmaker [ ${cleanUpValue(rowData?.match?.name)} ]`}
        isAddBtn={false}
      />
      <div className="row m-0 p-1">
        <div className="col-lg-12  m-0 p-0 ">
          <div className="setting_but_box mb-1">
            <Button
              className="btn-sm btn-primary"
              onClick={() =>
                setIsShow((prev) => ({
                  ...prev,
                  isOpen: true,
                  rowData,
                  modalTitle: "Message",
                  modalContent: BookmakerMessage,
                }))
              }
            >
              Message
            </Button>
            <Button
              className="btn-sm btn-primary"
              onClick={() =>
                setIsShow((prev) => ({
                  ...prev,
                  isOpen: true,
                  rowData,
                  modalTitle: "Bookmaker Setting",
                  modalContent: BookmakerSetting,
                }))
              }
            >
              Config
            </Button>
          </div>
        </div>
        <div className="col-lg-12  m-0 p-0 ">
          <div className="card p-1 m-0 mb-2">
            <div className="row m-0 p-0">
              <div className="col-lg-6 col-12  m-0 p-1 ">
                <h6 className="m-0 p-0">Previous Numbers</h6>
                <div className="previous_box">
                  {prevNum.map((item, i) => (
                    <Button key={i} className=" previous-but">
                      {item}
                    </Button>
                  ))}
                </div>
              </div>

              <div className="col-lg-6 col-12  m-0 p-1 ">
                <h6 className="m-0 p-0">Next Numbers</h6>
                <div className="previous_box">
                  {nextNum.map((item, i) => (
                    <Button key={i} className="previous-but">
                      {item}
                    </Button>
                  ))}
                </div>
              </div>
            </div>
          </div>
        </div>
        <div className="col-lg-12  m-0 p-0 ">
          <div className="card p-1 m-0 mb-1">
            <div className="row m-0 p-0">
              <div className="col-lg-6 col-12  m-0 p-1 ">
                <div className="w-100  position-relative">
                  <input
                    type="number"
                    value={rate}
                    className="form-control w-100 py-2 form-select-lg text-center"
                    onChange={handleRateChange}
                    onKeyDown={handleEnter}
                  />
                </div>
                <div className="book_running_box">
                  <div className="row m-0 p-0">
                    <div className="col-lg-4 col-12 m-0 p-1">
                      <Button
                        className={`running_but ${
                          action === "ballstart" ? "active" : ""
                        }`}
                        onClick={() => {
                          setAction("ballstart");
                          setIsBoth(false);
                        }}
                      >
                        ball
                      </Button>
                    </div>
                    <div className="col-lg-4 col-12 m-0 p-1">
                      <Button
                        className={`running_but ${
                          action === "active" ? "active" : ""
                        }`}
                        onClick={() => {
                          setAction((prev) => {
                            if (prev === "active") {
                              handleActionRequest({
                                statusVal: "active",
                                bothVal: selectedRunner === null ? true : false,
                              });
                            }
                            setIsBoth(false);
                            return "active";
                          });
                        }}
                      >
                        Active
                      </Button>
                    </div>
                    <div className="col-lg-4 col-6 m-0 p-1">
                      <Button
                        className={`running_but ${
                          action === "suspend" ? "active" : ""
                        }`}
                        onClick={() => {
                          setAction("suspend");
                          setIsBoth(false);
                        }}
                      >
                        Suspend
                      </Button>
                    </div>
                    <div className="col-lg-4 col-6 m-0 p-1">
                      <Button
                        className={`running_but ${isBoth ? "active" : ""}`}
                        onClick={() => {
                          setIsBoth(true);
                          setAction(null);
                          setSelectedRunner(null);
                          handleActionRequest({
                            statusVal: "active",
                            bothVal: true,
                          });
                        }}
                      >
                        Both
                      </Button>
                    </div>
                  </div>
                </div>
              </div>
              <div className="col-lg-6 col-12  m-0 p-1 ">
                <div className="sport_bookmaker_box">
                  {allRunners &&
                    allRunners.map((runner, i) => (
                      <div className="market_name_box" key={i}>
                        <p className="text-name">
                          <input
                            className="form-check-input"
                            type="radio"
                            name="runner"
                            value={runner}
                            onChange={() => {
                              setIsBoth(false);
                              setAction("suspend");
                              setSelectedRunner(runner);
                            }}
                            checked={
                              selectedRunner?.selectionId ===
                              runner?.selectionId
                            }
                            id={runner?.selectionId}
                          />
                          <Label htmlFor={runner?.selectionId}>
                            {runner?.runnerName}
                          </Label>
                        </p>

                        {/* market_suspend => ul tag class for suspend */}
                        <ul
                          className={`market_sport ${
                            action === "suspend"
                              ? "market_suspend"
                              : action === "ballstart"
                              ? "market_ball_running"
                              : ""
                          }`}
                        >
                          <li className="market market_bg-a">
                            <p>
                              {runner?.backRate ?? 0}
                              <span>{runner?.backVol ?? 0}</span>
                            </p>
                          </li>
                          <li className="market market_bg-b">
                            <p>
                              {runner?.layRate ?? 0}
                              <span>{runner?.layVol ?? 0}</span>
                            </p>
                          </li>
                        </ul>
                      </div>
                    ))}
                </div>
              </div>
            </div>
          </div>
        </div>
        <div className="col-lg-12  m-0 p-0 ">
          <div className="row m-0 p-0">
            <div className="col-lg-6 col-12  m-0 p-1 ">
              <div className="card p-1 m-0 mb-1">
                <h6>Volume</h6>
                <div className="previous_box">
                  {VOLUME.map((item, i) => {
                    return (
                      <Button
                        key={i}
                        className={`previous-but ${
                          volume.backVol === item.backVol &&
                          volume.layVol === item.layVol
                            ? "active"
                            : ""
                        } `}
                        onClick={() =>
                          setVolume((prev) => ({
                            ...prev,
                            backVol: item.backVol,
                            layVol: item.layVol,
                          }))
                        }
                      >{`${item.backVol}/${item.layVol}`}</Button>
                    );
                  })}
                </div>
              </div>
            </div>

            <div className="col-lg-6 col-12  m-0 p-1 ">
              <div className="card p-1 m-0 mb-1">
                <h6>Variation</h6>
                <div className="previous_box">
                  {VARIATION.map((item, i) => {
                    return (
                      <Button
                        key={i}
                        className={`previous-but ${
                          variation === item ? "active" : ""
                        }`}
                        onClick={() => setVariation(item)}
                      >
                        {item}
                      </Button>
                    );
                  })}
                </div>
              </div>
            </div>
          </div>
        </div>
      </div>

      <CommonModal
        isShow={isShow.isOpen}
        handleShowHide={() =>
          setIsShow((prev) => ({
            ...prev,
            isOpen: false,
            rowData: {},
            name: "",
          }))
        }
        modalTitle={isShow.modalTitle}
      >
        {isShow.modalContent &&
          React.createElement(isShow.modalContent, {
            handleShowHide: () =>
              setIsShow((prev) => ({
                ...prev,
                isOpen: false,
                rowData: {},
                name: "",
                modalTitle: "",
                apiFlag: !prev.apiFlag,
              })),
            rowData: isShow.rowData,
            handlePutRequest,
          })}
      </CommonModal>
    </>
  );
};

export default BookmakerView;
