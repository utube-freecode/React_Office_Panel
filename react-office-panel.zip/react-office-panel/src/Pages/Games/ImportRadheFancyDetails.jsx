import React, { useState } from "react";
import { useQuery } from "@tanstack/react-query";
import { useParams } from "react-router-dom";
import {
  getAxios,
  getAxiosForAuthResponse,
  postAxios,
} from "../../Services/commonService";
import {
  API_ADD_CREATEFANCY,
  API_GET_FANCYSETTINGS,
  API_GET_IMPORTRADHEFANCYDETAILS,
} from "../../utils/api/ApiConstant";
import { Button, Loading } from "../../Components";
import { generateRandomId } from "../../helper/common";

const ImportRadheFancyDetails = () => {
  const { id } = useParams();
  const [selectedItems, setSelectedItems] = useState([]);
  const [loading, setLoading] = useState(false);

  const { isLoading, data } = useQuery({
    queryKey: ["importRadheFancyDetails"],
    queryFn: async () =>
      await getAxios(`${API_GET_IMPORTRADHEFANCYDETAILS}/${id}`, {}),
  });

  const handleCheckboxChange = (game) => {
    setSelectedItems((prevSelectedItems) => {
      if (prevSelectedItems.some((item) => item._id === game._id)) {
        return prevSelectedItems.filter((item) => item._id !== game._id);
      }
      return [...prevSelectedItems, game];
    });
  };

  const { data: fancySettings } = useQuery({
    queryKey: ["fancySettings"],
    queryFn: async () =>
      await getAxiosForAuthResponse(API_GET_FANCYSETTINGS, {
        page: 1,
        limit: -1,
      }),
    staleTime: 300000,
  });

  const handleImportClick = async () => {
    setLoading(true);
    const body = selectedItems?.map((item) => {
      return {
        marketId: item?.marketId,
        __v: item?.__v,
        displayOrder: item?.displayOrder,
        fancyName: item?.fancyName,
        fancyType: "SKY",
        isActive: false,
        marketStartTime: item?.marketStartTime,
        marketType: item?.marketType,
        match: item?.match,
        result: "",
        runner: item?.runner,
        sport: item?.sport,
        status: item?.status,
        tournament: item?.tournament,
        fancyId: generateRandomId(),
        fancyMode: "Auto",
        marketTypeId: "5ebc1code68br4bik5b1808",
        fancySetting: {
          minStack: 10,
          maxStack: 100000,
          maxProfit: 2000000,
          betDelay: 0,
          maxStackPerOdds: 200000,
          isActive: true,
          isDeleted: false,
        },
        totalMatched: 0,
        gameSetting: null,
        fancyConfigurationSetting: {
          ballStart: 30,
          rateRange: 20,
          rateDiffrence: 1,
        },
        marketStatus: {
          id: "MS081893",
          name: "open",
        },
        bookmakerSetting: null,
        allowBat: true,
      };
    });

    const res = await postAxios(API_ADD_CREATEFANCY, body);

    setLoading(false);
    setSelectedItems([]);
  };

  return (
    <div className="table-responsive">
      <Button
        className="btn-primary m-2 float-end"
        onClick={handleImportClick}
        isDisabled={loading}
      >
        {loading ? "Loading" : "IMPORT"}
      </Button>
      <table
        style={{ borderCollapse: "collapse", width: "100%" }}
        className="table table-striped table-auto"
      >
        <thead className="table-light">
          <tr>
            <th>Select</th>
            <th>Market Name</th>
            <th>Market Type</th>
          </tr>
        </thead>
        <tbody>
          {isLoading ? (
            <tr>
              <td colSpan="3" style={{ textAlign: "center" }}>
                <Loading />
              </td>
            </tr>
          ) : (
            data &&
            Object.keys(data).map((key, i) => {
              const game = data[key];
              return (
                <tr key={game._id}>
                  <td>
                    <input
                      className="form-check-input"
                      type="checkbox"
                      checked={selectedItems.some(
                        (item) => item._id === game._id
                      )}
                      onChange={() => handleCheckboxChange(game)}
                    />
                  </td>
                  <td>{game.fancyName}</td>
                  <td>{game.marketType}</td>
                </tr>
              );
            })
          )}
        </tbody>
      </table>
    </div>
  );
};

export default ImportRadheFancyDetails;
