import React, { useCallback, useEffect, useMemo, useState } from "react";
import { useQuery, useQueryClient } from "@tanstack/react-query";
import { debounce } from "lodash";
import { Link, useParams } from "react-router-dom";

import {
  Breadcrumb,
  DataTable,
  DisplayOrder,
  Filter,
  SubHeading,
  TableOptions,
  YesNoBadge,
} from "../../Components";
import {
  CommonModal,
  ConfimationModal,
  LimitModal,
  TournamentModal,
} from "../../Modal";
import {
  API_GET_TOURNAMENT,
  API_UPDATE_TOURNAMENT,
} from "../../utils/api/ApiConstant";
import { postAxiosDataTable, putAxios } from "../../Services/commonService";
import { cleanUpValue } from "../../helper/common";
import { useDispatch, useSelector } from "react-redux";
import { uiActions } from "../../store/ui/ui-slice";

const Tournaments = () => {
  const dispatch = useDispatch();
  const { breadcrumb } = useSelector((state) => state.ui);
  const [currentPage, setCurrentPage] = useState(1);
  const [recordsPerPage, setRecordsPerPage] = useState(50);
  const [searchTerm, setSearchTerm] = useState("");
  const [headerSort, setHeaderSort] = useState({ column: 0, dir: "asc" });
  const [startRecord, setStartRecord] = useState(0);
  const queryClient = useQueryClient();
  const [isShow, setIsShow] = useState({
    isOpen: false,
    rowData: null,
    name: "",
    modalTitle: "",
    modalContent: null,
    apiFlag: false,
  });
  const { id: sportId } = useParams();
  const [filterData, setFilterData] = useState({
    sportId: sportId,
    tournamentId: null,
    matchId: null,
  });

  useEffect(() => {
    if (sportId) {
      setFilterData((prev) => ({
        ...prev,
        sportId: sportId,
      }));
    }

    // handleChildBreadcrumb({
    //   tournamentId: undefined,
    //   sportId: undefined,
    //   name: "",
    // });
    // else if (!sportId) {
    //   dispatch(uiActions.addBreadcrumb([]));
    // }
  }, []);

  const handleChildBreadcrumb = async ({ sportId, tournamentId, name }) => {
    const val = {
      type: 2,
      name: "T-" + name,
      link: `/tournaments?sportId=${sportId}`,
    };

    if (tournamentId) {
      const latestData = breadcrumb?.filter((item) => item.type === 1) || [];
      if (latestData.length > 0) {
        latestData.push(val);
        dispatch(uiActions.addBreadcrumb(latestData));
      } else {
        dispatch(uiActions.addBreadcrumb([val]));
      }
    } else {
      const latestData = breadcrumb?.filter((item) => item.type === 1) || [];
      dispatch(uiActions.addBreadcrumb(latestData));
    }
  };

  const payload = useMemo(() => {
    return {
      draw: currentPage,
      length: recordsPerPage,
      start: startRecord,
      search: {
        value: searchTerm,
        regex: false,
      },
      columns: [
        {
          data: "",
          name: "",
          searchable: true,
          orderable: false,
          search: {
            value: "",
            regex: false,
          },
        },
        {
          data: "name",
          name: "",
          searchable: true,
          orderable: true,
          search: {
            value: "",
            regex: false,
          },
        },
        {
          data: "isActive",
          name: "",
          searchable: true,
          orderable: true,
          search: {
            value: "",
            regex: false,
          },
        },
        {
          data: "betLock",
          name: "",
          searchable: true,
          orderable: true,
          search: {
            value: "",
            regex: false,
          },
        },
        {
          data: "isManual",
          name: "",
          searchable: true,
          orderable: true,
          search: {
            value: "",
            regex: false,
          },
        },
        {
          data: "isView",
          name: "",
          searchable: true,
          orderable: true,
          search: {
            value: "",
            regex: false,
          },
        },
        {
          data: "autoImport",
          name: "",
          searchable: true,
          orderable: true,
          search: {
            value: "",
            regex: false,
          },
        },
        {
          data: "displayOrder",
          name: "",
          searchable: true,
          orderable: true,
          search: {
            value: "",
            regex: false,
          },
        },
      ],
      order: [headerSort],
      sportId: filterData.sportId,
      data: { sportId: filterData.sportId },
    };
  }, [
    currentPage,
    recordsPerPage,
    searchTerm,
    startRecord,
    filterData.sportId,
    isShow.apiFlag,
    headerSort,
  ]);

  const handlePageChange = (page) => {
    setCurrentPage(page);
    setStartRecord((page - 1) * recordsPerPage);
  };

  const handleRecordsperPage = (value) => {
    setRecordsPerPage(value);
  };

  const handleSearch = (value) => {
    setSearchTerm(value);
    debouncedSearch(value);
  };

  const handleHeaderSort = ({ index, direction }) => {
    setHeaderSort({ column: index, dir: direction });
  };

  const { isLoading, data } = useQuery({
    queryKey: [
      "tournamentData",
      currentPage,
      recordsPerPage,
      searchTerm,
      startRecord,
      filterData.sportId,
      isShow.apiFlag,
      headerSort,
    ],
    queryFn: async () => await postAxiosDataTable(API_GET_TOURNAMENT, payload),
  });

  const handleQueryClient = (rowData, updatedRowData, key) => {
    return queryClient.setQueryData(
      [
        "tournamentData",
        currentPage,
        recordsPerPage,
        searchTerm,
        startRecord,
        filterData.sportId,
        isShow.apiFlag,
        headerSort,
      ],
      (oldData) => {
        return {
          ...oldData,
          docs: oldData.docs.map((obj) =>
            obj._id === rowData._id
              ? { ...obj, [key]: updatedRowData[key] }
              : obj
          ),
        };
      }
    );
  };

  const handlePutRequest = async (rowData, value, key) => {
    const payload = { ...rowData, [key]: value };
    const url = `${API_UPDATE_TOURNAMENT}/${rowData?._id}`;
    const res = await putAxios(url, payload);

    if (res) {
      handleQueryClient(rowData, payload, key);
    }
  };

  const columns = useMemo(
    () => [
      {
        accessorKey: "name",
        header: "Tournaments",
        cell: ({ getValue, row }) => (
          <Link
            to={`/eventmaster/matches/${row?.original?.sport?.id}/${row?.original?.id}`}
          >
            {getValue()}
          </Link>
        ),
      },
      {
        accessorKey: "sport.name",
        header: "Sports",
        cell: ({ getValue }) => cleanUpValue(getValue()),
      },
      {
        accessorKey: "isActive",
        header: "Is Active",
        cell: ({ getValue, row }) => (
          <ConfimationModal
            isSwitch={true}
            getValue={() => getValue()}
            onStatusChange={(newValue) =>
              handlePutRequest(row?.original, newValue, "isActive")
            }
          />
        ),
      },
      {
        accessorKey: "isManual",
        header: "Is Manual",
        cell: ({ getValue }) => <YesNoBadge getValue={getValue} />,
      },
      {
        accessorKey: "displayOrder",
        header: "Display Order",
        cell: ({ getValue, row }) => {
          const handleLimit = () => {
            setIsShow((prev) => ({
              ...prev,
              isOpen: true,
              rowData: row?.original,
              modalTitle: "Limit show",
              modalContent: LimitModal,
            }));
          };

          const tableOptions = {
            limit: handleLimit,
          };

          return (
            <div className="d-flex">
              <DisplayOrder
                initialValue={getValue()}
                onConfirm={(newValue) =>
                  handlePutRequest(row?.original, newValue, "displayOrder")
                }
              />
              <TableOptions tableOptions={tableOptions} />
            </div>
          );
        },
      },
    ],
    []
  );

  const fetchData = () => {
    if (!data) return { data: [], pages: 0 };

    return {
      data: data.docs,
      pages: data.pages,
    };
  };

  const handleFilterParams = useCallback((filterParams) => {
    if (filterParams) {
      const { sports } = filterParams;
      setFilterData((prev) => ({
        ...prev,
        sportId: sports?.value,
      }));
    } else {
      setFilterData((prev) => ({
        ...prev,
        sportId: null,
      }));
    }
  }, []);

  return (
    <>
      {/* <Breadcrumb breadcrumb={breadcrumb} title={"Tournaments"} /> */}
      <SubHeading
        subTitle="tournament list"
        handleShowHide={() =>
          setIsShow((prev) => ({
            ...prev,
            isOpen: true,
            rowData: {},
            name: "add",
            modalTitle: "Add Sport",
            modalContent: TournamentModal,
          }))
        }
      />
      <Filter
        isSport={true}
        handleFilterParams={handleFilterParams}
        defaultParams={filterData}
      />

      <div className="card-body">
        <DataTable
          columns={columns}
          fetchData={fetchData}
          currentPage={currentPage}
          onPageChange={handlePageChange}
          onRecordsPerPageChange={handleRecordsperPage}
          recordsPerPage={recordsPerPage}
          onSearchChange={handleSearch}
          isLoading={isLoading}
          handleHeaderSort={handleHeaderSort}
        />
      </div>

      <CommonModal
        isShow={isShow.isOpen}
        handleShowHide={() =>
          setIsShow((prev) => ({
            ...prev,
            isOpen: false,
            rowData: {},
            name: "",
          }))
        }
        modalTitle={isShow.modalTitle}
      >
        {isShow.modalContent &&
          React.createElement(isShow.modalContent, {
            handleShowHide: () =>
              setIsShow((prev) => ({
                ...prev,
                isOpen: false,
                rowData: {},
                name: "",
                modalTitle: "",
                apiFlag: !prev.apiFlag,
              })),
            rowData: isShow.rowData,
          })}
      </CommonModal>
    </>
  );
};

export default Tournaments;
