import Match from "./Match";
import Sports from "./Sports";
import Tournaments from "./Tournaments";
import Market from "./Market";
import Line from "./Line";
import OddEven from "./OddEven";
import ImportIndiaFancy from "./ImportIndiaFancy";
import ImportRadheFancy from "./ImportRadheFancy";
import CommentryPage from "./CommentryPage";
import ImportRadheFancyDetails from "./ImportRadheFancyDetails";
import ImportIndiaFancyDetails from "./ImportIndiaFancyDetails";

//fancy pages
import Fancy from "./Fancy/Fancy";
import FancyView from "./Fancy/FancyView";

// bookmaker pages
import Bookmaker from "./Bookmaker/Bookmaker";
import BookmakerView from "./Bookmaker/BookmakerView";

export {
  Sports,
  Tournaments,
  Match,
  ImportIndiaFancy,
  ImportIndiaFancyDetails,
  ImportRadheFancy,
  ImportRadheFancyDetails,
  Bookmaker,
  OddEven,
  Line,
  Market,
  Fancy,
  FancyView,
  CommentryPage,
  BookmakerView,
};
