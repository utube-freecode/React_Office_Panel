import { useQuery, useQueryClient } from "@tanstack/react-query";
import React, { useState, useCallback } from "react";
import { Link, useNavigate, useParams } from "react-router-dom";
import { debounce } from "lodash";

import { cleanUpValue, dateFormat } from "../../helper/common";
import {
  DataTable,
  DisplayOrder,
  Filter,
  SubHeading,
  Switch,
  TableOptions,
  YesNoBadge,
} from "../../Components";
import MatchModal from "../../Modal/GameModal/MatchModal";
import {
  AddScoreCardId,
  CheckPasswordModal,
  CommonModal,
  ConfimationModal,
  LiveTv,
} from "../../Modal";
import { postAxiosDataTable, putAxios } from "../../Services/commonService";
import { API_ADD_MATCH, API_GET_MATCH } from "../../utils/api/ApiConstant";
import ImportTimeModal from "../../Modal/GameModal/Match/ImportTimeModal";

const Match = () => {
  const navigate = useNavigate();
  const [currentPage, setCurrentPage] = useState(1);
  const [recordsPerPage, setRecordsPerPage] = useState(50);
  const [searchTerm, setSearchTerm] = useState("");
  const [headerSort, setHeaderSort] = useState({ column: 0, dir: "asc" });
  const queryClient = useQueryClient();
  const [isShow, setIsShow] = useState({
    isOpen: false,
    rowData: null,
    name: "",
    modalTitle: "",
    modalContent: null,
    apiFlag: false,
  });
  const { sportId, tournamentId } = useParams();
  const [filterData, setFilterData] = useState({
    sportId: sportId,
    tournamentId: tournamentId,
    matchId: null,
  });

  const payload = {
    draw: currentPage,
    columns: [
      {
        data: "",
        name: "",
        searchable: true,
        orderable: false,
        search: { value: "", regex: false },
      },
      {
        data: "name",
        searchable: true,
        orderable: true,
        search: { value: "", regex: false },
      },
      {
        data: "tournament.name",
        searchable: true,
        orderable: true,
        search: { value: "", regex: false },
      },
      {
        data: "sport.name",
        searchable: true,
        orderable: true,
        search: { value: "", regex: false },
      },
      {
        data: "openDate",
        searchable: true,
        orderable: true,
        search: { value: "", regex: false },
      },
      {
        data: "isManual",
        searchable: true,
        orderable: true,
        search: { value: "", regex: false },
      },
      {
        data: "isActive",
        searchable: true,
        orderable: true,
        search: { value: "", regex: false },
      },
      {
        data: "import",
        searchable: true,
        orderable: true,
        search: { value: "", regex: false },
      },
      {
        data: "inPlay",
        searchable: true,
        orderable: true,
        search: { value: "", regex: false },
      },
      {
        data: "displayOrder",
        searchable: true,
        orderable: true,
        search: { value: "", regex: false },
      },
    ],
    order: [headerSort],
    start: (currentPage - 1) * recordsPerPage, // Calculate offset
    length: recordsPerPage, // Number of records per page
    search: { value: searchTerm, regex: false },
    data: {
      sportId: filterData.sportId,
      tournamentId: filterData.tournamentId,
    },
    sportId: filterData.tournamentId,
  };

  const handlePageChange = (page) => {
    setCurrentPage(page);
  };

  const handleRecordsperPage = (value) => {
    setRecordsPerPage(value);
  };

  const handleSearch = (value) => {
    setSearchTerm(value);
    debouncedSearch(value);
  };

  const handleHeaderSort = ({ index, direction }) => {
    setHeaderSort({ column: index, dir: direction });
  };

  const { isLoading, data } = useQuery({
    queryKey: [
      "matchData",
      currentPage,
      recordsPerPage,
      searchTerm,
      sportId,
      filterData,
      isShow.apiFlag,
      headerSort,
    ],
    queryFn: async () => await postAxiosDataTable(API_GET_MATCH, payload),
  });

  const handleQueryClient = (rowData, updatedRowData, key) => {
    return queryClient.setQueryData(
      [
        "matchData",
        currentPage,
        recordsPerPage,
        searchTerm,
        sportId,
        filterData,
        isShow.apiFlag,
        headerSort,
      ],
      (oldData) => {
        return {
          ...oldData,
          docs: oldData.docs.map((match) =>
            match._id === rowData._id
              ? { ...match, [key]: updatedRowData[key] }
              : match
          ),
        };
      }
    );
  };

  const handlePutRequest = async (apiUrl, rowData, newValue, key) => {
    const updatedRowData = {
      ...rowData,
      [key]: newValue,
    };
    const url = `${apiUrl}/${rowData?._id}`;

    const res = await putAxios(url, updatedRowData);

    if (res) {
      handleQueryClient(rowData, updatedRowData, key);
    }
  };

  const columns = [
    {
      header: "Actions",
      cell: ({ row }) => {
        const handleLiveTv = () => {
          setIsShow((prev) => ({
            ...prev,
            isOpen: true,
            rowData: row?.original,
            modalTitle: "Live Tv",
            modalContent: LiveTv,
          }));
        };

        const handleScoreCardIdModal = () => {
          setIsShow((prev) => ({
            ...prev,
            isOpen: true,
            rowData: row?.original,
            modalTitle: "Add Score Card ID",
            modalContent: AddScoreCardId,
          }));
        };

        const handleCommentary = () => {
          navigate(`/commentary/show/${row?.original?.id}`);
        };

        const tableOptions = {
          // Commentary: handleCommentary,
          ["Live Tv"]: handleLiveTv,
          ScoreCard: handleScoreCardIdModal,
        };
        return <TableOptions tableOptions={tableOptions} />;
      },
    },
    {
      accessorKey: "name",
      header: "Matches",
      cell: ({ getValue, row }) => (
        <Link to={`/eventmaster/market/${row?.original?.id}`}>
          {getValue()}
        </Link>
      ),
    },
    {
      accessorKey: "tournament.name",
      header: "Tournaments",
      cell: ({ getValue }) => cleanUpValue(getValue()),
    },
    {
      accessorKey: "sport.name",
      header: "Sport",
      cell: ({ getValue }) => cleanUpValue(getValue()),
    },
    {
      accessorKey: "openDate",
      header: "Match Date",
      cell: ({ getValue }) => {
        const value = getValue();
        return dateFormat(value).formattedDateTime;
      },
    },
    {
      accessorKey: "isManual",
      header: "Is Manual",
      cell: ({ getValue }) => <YesNoBadge getValue={getValue} />,
    },
    {
      accessorKey: "isActive",
      header: "Is Active",
      cell: ({ getValue, row }) => (
        <ConfimationModal
          isSwitch={true}
          getValue={() => getValue()}
          onStatusChange={() =>
            handlePutRequest(
              API_ADD_MATCH,
              row?.original,
              !getValue(),
              "isActive"
            )
          }
        />
      ),
    },
    {
      accessorKey: "import",
      header: "F Import",
      cell: ({ getValue, row }) => (
        <ConfimationModal
          isSwitch={true}
          getValue={() => getValue()}
          onStatusChange={() =>
            handlePutRequest(
              API_ADD_MATCH,
              row?.original,
              !getValue(),
              "import"
            )
          }
        />
      ),
    },
    {
      accessorKey: "inPlay",
      header: "In Play",
      cell: ({ getValue, row }) => (
        <CheckPasswordModal
          isSwitch={true}
          onStatusChange={() => {
            handlePutRequest(
              API_ADD_MATCH,
              row?.original,
              !getValue(),
              "inPlay"
            );
          }}
          rowData={row?.original}
          getValue={getValue}
        />
      ),
    },
    {
      accessorKey: "displayOrder",
      header: "Display Order",
      cell: ({ getValue, row }) => {
        return (
          <div className="d-flex">
            <DisplayOrder
              initialValue={getValue()}
              onConfirm={(newValue) =>
                putAxios(`${API_ADD_MATCH}/${row?.original?._id}`, {
                  ...row?.original,
                  displayOrder: newValue,
                })
              }
            />
          </div>
        );
      },
    },
    {
      header: "Import Time",
      cell: ({ row }) => {
        return <ImportTimeModal rowData={row?.original} />;
      },
    },
  ];

  const fetchData = () => {
    if (!data) return { data: [], pages: 0 };

    return {
      data: data.docs,
      pages: data.pages,
    };
  };

  const handleFilterParams = (filterParams) => {
    const { sports, tournament } = filterParams;
    setFilterData({
      ...filterData,
      sportId: sports?.value,
      tournamentId: tournament?.value,
    });
  };

  return (
    <>
      <SubHeading
        subTitle="Match List"
        handleShowHide={() =>
          setIsShow((prev) => ({
            ...prev,
            isOpen: true,
            rowData: {},
            name: "add",
            modalTitle: "Add Match",
            modalContent: MatchModal,
          }))
        }
      />
      <Filter
        isSport={true}
        isTournament={true}
        handleFilterParams={handleFilterParams}
        defaultParams={filterData}
      />
      <div className="card-body">
        <DataTable
          columns={columns}
          fetchData={fetchData}
          currentPage={currentPage}
          onPageChange={handlePageChange}
          onRecordsPerPageChange={handleRecordsperPage}
          recordsPerPage={recordsPerPage}
          onSearchChange={handleSearch}
          isLoading={isLoading}
          handleHeaderSort={handleHeaderSort}
        />
      </div>

      <CommonModal
        isShow={isShow.isOpen}
        handleShowHide={() =>
          setIsShow((prev) => ({
            ...prev,
            isOpen: false,
            rowData: {},
            name: "",
          }))
        }
        modalTitle={isShow.modalTitle}
      >
        {isShow.modalContent &&
          React.createElement(isShow.modalContent, {
            handleShowHide: () =>
              setIsShow((prev) => ({
                ...prev,
                isOpen: false,
                rowData: {},
                name: "",
                modalTitle: "",
                apiFlag: !prev.apiFlag,
              })),
            rowData: isShow.rowData,
          })}
      </CommonModal>
    </>
  );
};

export default Match;
