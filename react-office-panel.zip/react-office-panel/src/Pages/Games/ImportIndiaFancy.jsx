import React from "react";
import { useQuery } from "@tanstack/react-query";
import { useNavigate } from "react-router-dom";
import { dateFormat } from "../../helper/common";
import Loading from "../../Components/UI/Loading";
import { getAxios } from "../../Services/commonService";
import { API_GET_IMPORT_INDIA_FANCY } from "../../utils/api/ApiConstant";

const ImportIndiaFancy = () => {
  const navigate = useNavigate();
  const { isLoading, data } = useQuery({
    queryKey: ["importIndiaFancyData"],
    queryFn: async () => await getAxios(API_GET_IMPORT_INDIA_FANCY, {}),
  });

  console.log("data", data);

  return (
    <div className="table-responsive">
      <table className="table table-striped table-auto">
        <thead className="table-light">
          <tr>
            <th>No.</th>
            <th className="text-start">Match Name</th>
            <th className="text-start">ID</th>
            <th className="text-start">Date</th>
          </tr>
        </thead>
        <tbody>
          {isLoading ? (
            <tr>
              <td colSpan="5" style={{ textAlign: "center" }}>
                <Loading />
              </td>
            </tr>
          ) : (
            data &&
            Object.keys(data).map((key, i) => {
              const game = data[key];
              return (
                <tr key={game.game_srno}>
                  <td>{i + 1}</td>
                  <td
                    className="cursor-pointer text-start"
                    onClick={() =>
                      navigate(
                        `/eventmaster/ImportIndiaFancy/${game.marketid}`,
                        { state: { game } }
                      )
                    }
                  >
                    {game.game_name}
                  </td>
                  <td className="text-start">{game.marketid}</td>
                  <td className="text-start">
                    {dateFormat(game.game_time).formattedDateTime}
                  </td>
                </tr>
              );
            })
          )}
        </tbody>
      </table>
    </div>
  );
};

export default ImportIndiaFancy;
