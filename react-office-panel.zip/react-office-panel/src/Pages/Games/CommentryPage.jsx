import React, { useState } from "react";
import { useParams } from "react-router-dom";
import { Button, SubHeading } from "../../Components";
import { AddCommentryModal, CommonModal } from "../../Modal";
import { useQuery, useQueryClient } from "@tanstack/react-query";
import {
  API_GET_COMMENTARYLIST,
  API_UPDATE_COMMENTARYSTATUS_MARKET,
  API_UPDATE_MATCHBYSTATUS,
} from "../../utils/api/ApiConstant";
import { getAxios, postAxios, putAxios } from "../../Services/commonService";

const CommentryPage = () => {
  const { id } = useParams();
  const queryClient = useQueryClient();
  const [isShow, setIsShow] = useState({
    isOpen: false,
    rowData: null,
    name: "",
    modalTitle: "",
    modalContent: null,
  });

  const { data } = useQuery({
    queryKey: ["commentaryList"],
    queryFn: async () => await getAxios(API_GET_COMMENTARYLIST, {}),
  });

  const handleBallRunning = () => {
    try {
      const body = {
        marketStatus: {
          id: "MS950763",
          name: "ballstart",
          value: "BALLSTART",
        },
        matchId: id,
      };

      const res1 = putAxios(
        `${API_UPDATE_COMMENTARYSTATUS_MARKET}/${id}`,
        body
      );
      // const res2 = putAxios(`${API_UPDATE_MATCHBYSTATUS}/${id}`, body);
    } catch (error) {
      console.log("handleBallRunning ", error);
    }
  };

  const handleSuspend = () => {
    try {
      const body = {
        marketStatus: {
          id: "MS940896",
          name: "suspend",
          value: "SUSPENDED",
        },
        matchId: id,
      };

      const res1 = putAxios(
        `${API_UPDATE_COMMENTARYSTATUS_MARKET}/${id}`,
        body
      );
      // const res2 = putAxios(`${API_UPDATE_MATCHBYSTATUS}/${id}`, body);
    } catch (error) {
      console.log("handleSuspend ", error);
    }
  };

  const handleLive = () => {
    try {
      const body = {
        marketStatus: {
          id: "MS940896",
          name: "open",
          value: "OPEN",
        },
        matchId: id,
      };

      const res1 = putAxios(
        `${API_UPDATE_COMMENTARYSTATUS_MARKET}/${id}`,
        body
      );
      // const res2 = putAxios(`${API_UPDATE_MATCHBYSTATUS}/${id}`, body);
    } catch (error) {
      console.log("handleSuspend ", error);
    }
  };

  return (
    <>
      <SubHeading
        subTitle="Commentary"
        handleShowHide={() =>
          setIsShow((prev) => ({
            ...prev,
            isOpen: open,
            rowData: {},
            name: "add",
            modalTitle: "Add Commetary",
            modalContent: AddCommentryModal,
          }))
        }
      />
      <div className="d-flex justify-content-evenly m-3">
        <Button className={`btn-primary`} onClick={handleBallRunning}>
          Ball Running
        </Button>
        <Button className={`btn-light`} onClick={handleSuspend}>
          Suspend
        </Button>
        <Button className={`btn-success`} onClick={handleLive}>
          Live
        </Button>
      </div>

      <p>Commentry List</p>
      <div className="d-flex justify-content-evenly m-3">
        {data?.map((item) =>
          item?.isActive ? (
            <Button key={item?._id} className="btn-danger m-1">
              {item?.name}
            </Button>
          ) : null
        )}
      </div>

      <CommonModal
        isShow={isShow.isOpen}
        handleShowHide={() =>
          setIsShow((prev) => ({
            ...prev,
            isOpen: false,
            rowData: {},
            name: "",
          }))
        }
        modalTitle={isShow.modalTitle}
      >
        {isShow.modalContent &&
          React.createElement(isShow.modalContent, {
            handleShowHide: () =>
              setIsShow((prev) => ({
                ...prev,
                isOpen: false,
                rowData: {},
                name: "",
                modalTitle: "",
              })),
            rowData: isShow.rowData,
            commentryList: data,
            queryClient: queryClient,
          })}
      </CommonModal>
    </>
  );
};

export default CommentryPage;
