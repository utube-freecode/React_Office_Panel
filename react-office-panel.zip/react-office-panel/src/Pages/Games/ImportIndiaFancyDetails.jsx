import React, { useState } from "react";
import { useQuery } from "@tanstack/react-query";
import { useParams } from "react-router-dom";
import { useLocation, useNavigate } from "react-router-dom";

import {
  getAxios,
  getAxiosForAuthResponse,
  postAxios,
} from "../../Services/commonService";
import {
  API_ADD_CREATEFANCY,
  API_GET_FANCYSETTINGS,
  API_GET_IMPORT_INDIA_FANCYDETAILS,
  API_GET_MATCHBYID,
} from "../../utils/api/ApiConstant";
import { Button, Loading } from "../../Components";
import { generateRandomId } from "../../helper/common";

const ImportIndiaFancyDetails = () => {
  const navigate = useNavigate();
  const { id } = useParams();
  const location = useLocation();
  const game = location.state?.game;

  if (!game) {
    navigate(`/eventmaster/ImportIndiaFancy`);
  }
  const [selectedItems, setSelectedItems] = useState([]);
  const [loading, setLoading] = useState(false);

  const { isLoading, data } = useQuery({
    queryKey: ["ImportIndiaFancyDetails"],
    queryFn: async () =>
      await getAxios(`${API_GET_IMPORT_INDIA_FANCYDETAILS}/${id}`, {}),
  });

  const { data: matchByIdData } = useQuery({
    queryKey: ["matchByIdData"],
    queryFn: async () =>
      await getAxiosForAuthResponse(`${API_GET_MATCHBYID}/${id}`, {}),
  });

  console.log("matchByIdData", matchByIdData);

  const handleCheckboxChange = (selectedGame) => {
    setSelectedItems((prevSelectedItems) => {
      if (prevSelectedItems.some((item) => item.srno === selectedGame.srno)) {
        return prevSelectedItems.filter(
          (item) => item.srno !== selectedGame.srno
        );
      }
      return [...prevSelectedItems, selectedGame];
    });
  };

  const { data: fancySettings } = useQuery({
    queryKey: ["fancySettings"],
    queryFn: async () =>
      await getAxiosForAuthResponse(API_GET_FANCYSETTINGS, {
        page: 1,
        limit: -1,
      }),
    staleTime: 300000,
  });

  console.log("selectedItems", selectedItems);

  const handleImportClick = async () => {
    setLoading(true);
    const body = selectedItems?.map((item) => {
      return {
        marketId: item?.game_srno,
        __v: item?.__v,
        displayOrder: item?.display_srno,
        fancyName: item?.event_name,
        fancyType: "PLAYER",
        isActive: false,
        marketStartTime: item?.created,
        marketType: item?.event_type,
        match: {
          id,
          name: game?.game_name,
        },
        result: "",
        sport: matchByIdData?.sport,
        tournament: matchByIdData?.tournament,
        fancyId: generateRandomId(),
        fancyMode: "Auto",
        marketTypeId: "5ebc1code68br4bik5b1808",
        fancySetting: {
          minStack: 10,
          maxStack: 100000,
          maxProfit: 2000000,
          betDelay: 0,
          maxStackPerOdds: 200000,
          isActive: true,
          isDeleted: false,
        },
        totalMatched: 0,
        gameSetting: null,
        fancyConfigurationSetting: {
          ballStart: 30,
          rateRange: 20,
          rateDiffrence: 1,
        },
        marketStatus: {
          id: "MS081893",
          name: "open",
        },
        bookmakerSetting: null,
        allowBat: true,
      };
    });

    const res = await postAxios(API_ADD_CREATEFANCY, body);

    setLoading(false);
    setSelectedItems([]);
  };

  return (
    <div className="table-responsive">
      <Button
        className="btn-primary m-2 float-end"
        onClick={handleImportClick}
        isDisabled={loading}
      >
        {loading ? "Loading" : "IMPORT"}
      </Button>
      <table
        style={{ borderCollapse: "collapse", width: "100%" }}
        className="table table-striped table-auto"
      >
        <thead className="table-light">
          <tr>
            <th>Select</th>
            <th>Market Name</th>
            <th>Market Type</th>
          </tr>
        </thead>
        <tbody>
          {isLoading ? (
            <tr>
              <td colSpan="3" style={{ textAlign: "center" }}>
                <Loading />
              </td>
            </tr>
          ) : (
            data &&
            Object.keys(data).map((key, i) => {
              const game = data[key];
              return (
                <tr key={game.srno}>
                  <td>
                    <input
                      className="form-check-input"
                      type="checkbox"
                      checked={selectedItems.some(
                        (item) => item.srno === game.srno
                      )}
                      onChange={() => handleCheckboxChange(game)}
                    />
                  </td>
                  <td>{game.event_name}</td>
                  <td>{game.fancyType}</td>
                </tr>
              );
            })
          )}
        </tbody>
      </table>
    </div>
  );
};

export default ImportIndiaFancyDetails;
