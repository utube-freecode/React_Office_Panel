import React, { useCallback, useMemo, useState } from "react";
import { useQuery, useQueryClient } from "@tanstack/react-query";
import { debounce } from "lodash";
import { useSelector } from "react-redux";
import { useParams } from "react-router-dom";

import { cleanUpValue, dateFormat } from "../../helper/common";
import {
  Button,
  DataTable,
  Filter,
  SubHeading,
  Switch,
  TableOptions,
  TruFalseBadge,
} from "../../Components";
import {
  API_ADD_MARKET,
  API_GET_MARKET,
  API_UPDATE_MARKET,
} from "../../utils/api/ApiConstant";
import {
  CheckPasswordModal,
  CommonModal,
  LimitMarketModal,
  Message,
  ResultModal,
  SuspandModal,
} from "../../Modal";
import {
  postAxios,
  postAxiosDataTable,
  putAxios,
} from "../../Services/commonService";

const marketTypeData = [
  {
    value: "Match Odds",
    label: "Match Odds",
  },
  {
    value: "Bookmaker",
    label: "Bookmaker",
  },
  {
    value: "Fancy",
    label: "Fancy",
  },
  {
    value: "Line",
    label: "Line",
  },
  {
    value: "CasinoLive",
    label: "CasinoLive",
  },
];

const Market = () => {
  const [currentPage, setCurrentPage] = useState(1);
  const [recordsPerPage, setRecordsPerPage] = useState(50);
  const [searchTerm, setSearchTerm] = useState("");
  const [headerSort, setHeaderSort] = useState({ column: 0, dir: "asc" });
  const [startRecord, setStartRecord] = useState(0);
  const queryClient = useQueryClient();
  const [isShow, setIsShow] = useState({
    isOpen: false,
    rowData: null,
    name: "",
    modalTitle: "",
    modalContent: null,
    apiFlag: false,
  });
  const { user } = useSelector((state) => state.user);
  const { matchId } = useParams();
  const [filterData, setFilterData] = useState({
    sportId: null,
    tournamentId: null,
    matchId: matchId,
    marketType: null,
  });

  const payload = useMemo(
    () => ({
      draw: currentPage,
      columns: [
        {
          data: "",
          name: "",
          searchable: true,
          orderable: false,
          search: {
            value: "",
            regex: false,
          },
        },
        {
          data: "marketType",
          name: "",
          searchable: true,
          orderable: true,
          search: {
            value: "",
            regex: false,
          },
        },
        {
          data: "match.name",
          name: "",
          searchable: true,
          orderable: true,
          search: {
            value: "",
            regex: false,
          },
        },
        {
          data: "marketType",
          name: "",
          searchable: true,
          orderable: true,
          search: {
            value: "",
            regex: false,
          },
        },
        {
          data: "isActive",
          name: "",
          searchable: true,
          orderable: true,
          search: {
            value: "",
            regex: false,
          },
        },
        {
          data: "allowBat",
          name: "",
          searchable: true,
          orderable: true,
          search: {
            value: "",
            regex: false,
          },
        },
        {
          data: "fancyMode",
          name: "",
          searchable: true,
          orderable: true,
          search: {
            value: "",
            regex: false,
          },
        },
        {
          data: "marketStartTime",
          name: "",
          searchable: true,
          orderable: true,
          search: {
            value: "",
            regex: false,
          },
        },
        {
          data: "createdAt",
          name: "",
          searchable: true,
          orderable: true,
          search: {
            value: "",
            regex: false,
          },
        },
      ],
      order: [headerSort],
      start: startRecord,
      length: recordsPerPage,
      search: {
        value: searchTerm,
        regex: false,
      },
      userId: user?.user_id,
      matchName: "",
      matchId: filterData.matchId,
      data: filterData,
    }),
    [
      currentPage,
      recordsPerPage,
      searchTerm,
      startRecord,
      filterData,
      isShow.apiFlag,
      headerSort,
    ]
  );

  const handlePageChange = (page) => {
    setCurrentPage(page);
    setStartRecord((page - 1) * recordsPerPage);
  };

  const handleRecordsperPage = (value) => {
    setRecordsPerPage(value);
  };

  const handleSearch = (value) => {
    setSearchTerm(value);
  };

  const { data, isLoading } = useQuery({
    queryKey: [
      "marketData",
      currentPage,
      recordsPerPage,
      searchTerm,
      startRecord,
      filterData.matchId,
      filterData.marketType,
      headerSort,
      isShow.apiFlag,
    ],
    queryFn: async () => await postAxiosDataTable(API_GET_MARKET, payload),
  });

  const handleHeaderSort = ({ index, direction }) => {
    setHeaderSort({ column: index, dir: direction });
  };

  const fetchData = () => {
    if (!data) return { data: [], pages: 0 };

    return {
      data: data.docs,
      pages: data.pages,
    };
  };

  const handleQueryClient = (rowData, updatedRowData, key) => {
    return queryClient.setQueryData(
      [
        "marketData",
        currentPage,
        recordsPerPage,
        searchTerm,
        startRecord,
        filterData.matchId,
        filterData.marketType,
        headerSort,
        isShow.apiFlag,
      ],
      (oldData) => {
        return {
          ...oldData,
          docs: oldData.docs.map((match) =>
            match._id === rowData._id
              ? { ...match, [key]: updatedRowData[key] }
              : match
          ),
        };
      }
    );
  };

  const handlePutRequest = async (apiUrl, rowData, newValue, key) => {
    const updatedRowData = {
      ...rowData,
      [key]: newValue,
    };
    const url = `${apiUrl}/${rowData?._id}`;

    const res = await putAxios(url, updatedRowData);

    if (res) {
      handleQueryClient(rowData, updatedRowData, key);
    }
  };

  const handleActions = async (
    newValue,
    token,
    rowData,
    apiAction,
    apiMethod,
    status
  ) => {
    const { marketType, marketId, match, assignTo } = rowData;

    const payload = {
      marketType,
      marketId,
      token,
      marketName: match?.name,
      status,
      userId: assignTo?.id,
    };
    const url = `${API_ADD_MARKET}/${apiAction}/${marketId}`;

    let res;
    if (apiMethod === "put") {
      res = await putAxios(url, payload);
    } else if (apiMethod === "post") {
      res = await postAxios(url, payload);
    }

    if (res) {
      setIsShow((prev) => ({
        ...prev,
        isOpen: false,
        rowData: {},
        name: "",
        modalTitle: "",
        apiFlag: !prev.apiFlag,
      }));
    }
  };

  const columns = useMemo(
    () => [
      {
        header: "Actions",
        cell: ({ row }) => {
          const handleSuspend = useCallback(() => {
            setIsShow((prev) => ({
              ...prev,
              isOpen: true,
              rowData: row?.original,
              modalTitle: "Suspand Game",
              modalContent: SuspandModal,
            }));
          }, []);

          const handleMessage = useCallback(() => {
            setIsShow((prev) => ({
              ...prev,
              isOpen: true,
              rowData: row?.original,
              modalTitle: "Add Message",
              modalContent: Message,
            }));
          }, []);

          const handleLimit = useCallback(() => {
            setIsShow((prev) => ({
              ...prev,
              isOpen: true,
              rowData: row?.original,
              modalTitle: "Edit Limit",
              modalContent: LimitMarketModal,
            }));
          }, []);

          const tableOptions = {
            Suspend: handleSuspend,
            Message: handleMessage,
            Limit: handleLimit,
          };

          return <TableOptions tableOptions={tableOptions} />;
        },
      },
      {
        accessorKey: "marketType",
        header: "Market",
        cell: ({ row }) => {
          const marketType = row.original.marketType;
          const fancyName = row.original.fancyName;
          return marketType === "Fancy" ? fancyName : marketType;
        },
      },
      {
        accessorKey: "match.name",
        header: "Match",
        cell: ({ getValue }) => cleanUpValue(getValue()),
      },
      {
        accessorKey: "marketType",
        header: "Type",
      },
      {
        header: "Result",
        cell: ({ row }) => {
          return (
            <Button
              className="btn-primary btn-sm me-1"
              onClick={() =>
                setIsShow((prev) => ({
                  ...prev,
                  isOpen: true,
                  rowData: row?.original,
                  name: "settlement",
                  modalTitle: "Settlement",
                  modalContent: ResultModal,
                }))
              }
            >
              R
            </Button>
          );
        },
      },
      {
        header: "Cancel",
        cell: ({ row, getValue }) => {
          const { match, marketType, displayName, fancyName } = row?.original;
          return (
            <CheckPasswordModal
              isBtn={true}
              onStatusChange={(newValue, token) => {
                const status = {
                  id: "MS930818",
                  name: "Cancelled",
                  value: "CANCELLED",
                };
                handleActions(
                  newValue,
                  token,
                  row?.original,
                  "cancel",
                  "put",
                  status
                );
              }}
              rowData={row?.original}
              getValue={getValue}
              btnText="X"
              btnClass="btn-danger btn-sm me-1"
              modalTitle={`Cancel Market (${
                marketType === "Fancy"
                  ? fancyName
                  : marketType === "Bookmaker"
                  ? displayName
                  : marketType
              })`}
            />
          );
        },
      },
      {
        accessorKey: "isActive",
        header: "Is Active",
        cell: ({ getValue, row }) => (
          <Switch
            getValue={getValue}
            onChange={() => {
              handlePutRequest(
                API_UPDATE_MARKET,
                row?.original,
                !getValue(),
                "isActive"
              );
            }}
          />
        ),
      },
      {
        accessorKey: "allowBat",
        header: "Allow Bet",
        cell: ({ getValue, row }) => (
          <Switch
            getValue={getValue}
            onChange={() => {
              handlePutRequest(
                API_UPDATE_MARKET,
                row?.original,
                !getValue(),
                "allowBat"
              );
            }}
          />
        ),
      },
      {
        accessorKey: "marketStatus.name",
        header: "Status",
      },
      {
        accessorKey: "marketStartTime",
        header: "Matched Time",
        cell: ({ getValue }) => {
          const value = getValue();
          return dateFormat(value).formattedDateTime;
        },
      },
      {
        accessorKey: "createdAt",
        header: "Created Time",
        cell: ({ getValue }) => {
          const value = getValue();
          return dateFormat(value).formattedDateTime;
        },
      },
    ],
    []
  );

  const handleFilterParams = (filterParams) => {
    const { match, marketType } = filterParams;
    console.log("🚀 ~ handleFilterParams ~ marketType:", marketType);
    console.log("🚀 ~ handleFilterParams ~ match:", match);
    setFilterData({
      ...filterData,
      matchId: match?.value,
      marketType: marketType?.value,
    });
  };

  return (
    <>
      <SubHeading subTitle="Market list" isAddBtn={false} />
      <Filter
        allMatch={true}
        handleFilterParams={handleFilterParams}
        apiParam="All"
        defaultParams={filterData}
        isType={true}
        marketTypeData={marketTypeData}
      />
      <div className="card-body">
        <DataTable
          columns={columns}
          fetchData={fetchData}
          currentPage={currentPage}
          onPageChange={handlePageChange}
          onRecordsPerPageChange={handleRecordsperPage}
          recordsPerPage={recordsPerPage}
          onSearchChange={handleSearch}
          isLoading={isLoading}
          handleHeaderSort={handleHeaderSort}
        />
      </div>

      <CommonModal
        isShow={isShow.isOpen}
        handleShowHide={() =>
          setIsShow((prev) => ({
            ...prev,
            isOpen: false,
            rowData: {},
            name: "",
          }))
        }
        modalTitle={isShow.modalTitle}
      >
        {isShow.modalContent &&
          React.createElement(isShow.modalContent, {
            handleShowHide: () =>
              setIsShow((prev) => ({
                ...prev,
                isOpen: false,
                rowData: {},
                name: "",
                modalTitle: "",
                apiFlag: !prev.apiFlag,
              })),
            rowData: isShow.rowData,
            handlePutRequest,
          })}
      </CommonModal>
    </>
  );
};

export default Market;
