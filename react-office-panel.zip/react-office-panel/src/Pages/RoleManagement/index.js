import ManageUsers from "./ManageUsers";
import ModuleAccess from "./ModuleAccess";

// roles
import Roles from "./Roles/Roles";
import RolesCreate from "./Roles/RolesCreate";
import RolesDetail from "./Roles/RolesDetail";

export { ManageUsers, ModuleAccess, Roles, RolesCreate, RolesDetail };
