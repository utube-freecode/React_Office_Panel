import React, { useCallback, useMemo, useState } from "react";
import { useQuery } from "@tanstack/react-query";
import { debounce } from "lodash";

import { DataTable, SubHeading } from "../../../Components";
import { API_USER_ROLES } from "../../../utils/api/ApiConstant";
import { getAxios } from "../../../Services/commonService";
import Icon from "../../../assets/icons/Icon";
import { Outlet, useNavigate } from "react-router-dom";
import { CommonModal, RoleDetailModal } from "../../../Modal";

const Roles = () => {
  const navigate = useNavigate();
  const [currentPage, setCurrentPage] = useState(1);
  const [recordsPerPage, setRecordsPerPage] = useState(50);
  const [searchTerm, setSearchTerm] = useState("");
  const [headerSort, setHeaderSort] = useState({ column: 0, dir: "asc" });
  const [isShow, setIsShow] = useState({
    isOpen: false,
    rowData: null,
    name: "",
    modalTitle: "",
    modalContent: null,
    apiFlag: false,
  });

  const { isLoading, data } = useQuery({
    queryKey: [
      "rolesData",
      currentPage,
      recordsPerPage,
      searchTerm,
      headerSort,
    ],
    queryFn: async () => await getAxios(API_USER_ROLES, { page: 1, limit: 10 }),
  });

  const columns = useMemo(
    () => [
      {
        accessorKey: "role name",
        header: "role_name",
      },
      {
        accessorKey: "description",
        header: "description",
      },
      {
        accessorKey: "modules",
        header: "Modules",
        cell: ({ row }) => {
          const modules = row.original.modules || [];
          return modules.map((module) => module.moduleName).join(", ");
        },
      },
      {
        accessorKey: "action",
        header: "Action",
        cell: ({ row }) => (
          <>
            <Icon
              name="FaEdit"
              cursorPointer={true}
              onClick={() =>
                navigate("/rolemanager/roles/create", {
                  state: {
                    rowData: row?.original,
                  },
                })
              }
            />
            <Icon
              name="FaEye"
              cursorPointer={true}
              onClick={() =>
                setIsShow((prev) => ({
                  ...prev,
                  isOpen: true,
                  rowData: row?.original,
                  name: "",
                  modalTitle: "Role Details",
                  modalContent: RoleDetailModal,
                }))
              }
            />
          </>
        ),
      },
    ],
    []
  );

  const fetchData = () => {
    if (!data) return { data: [], pages: 0 };

    return {
      data: data.docs,
      pages: data.pages,
    };
  };

  const handlePageChange = (page) => {
    setCurrentPage(page);
  };

  const handleRecordsperPage = (value) => {
    setRecordsPerPage(value);
  };

  const handleSearch = (value) => {
    setSearchTerm(value);
    debouncedSearch(value);
  };

  const handleHeaderSort = ({ index, direction }) => {
    setHeaderSort({ column: index, dir: direction });
  };

  return (
    <>
      <SubHeading
        subTitle="roles list"
        isAddBtnPage={true}
        isAddBtn={false}
        redirectPath="create"
      />
      <div className="card-body">
        <DataTable
          columns={columns}
          fetchData={fetchData}
          currentPage={currentPage}
          onPageChange={handlePageChange}
          onRecordsPerPageChange={handleRecordsperPage}
          recordsPerPage={recordsPerPage}
          onSearchChange={handleSearch}
          isLoading={isLoading}
          handleHeaderSort={handleHeaderSort}
        />
      </div>

      <CommonModal
        isShow={isShow.isOpen}
        handleShowHide={() =>
          setIsShow((prev) => ({
            ...prev,
            isOpen: false,
            rowData: {},
            name: "",
          }))
        }
        modalTitle={isShow.modalTitle}
      >
        {isShow.modalContent &&
          React.createElement(isShow.modalContent, {
            handleShowHide: () =>
              setIsShow((prev) => ({
                ...prev,
                isOpen: false,
                rowData: {},
                name: "",
                modalTitle: "",
                apiFlag: !prev.apiFlag,
              })),
            rowData: isShow.rowData,
          })}
      </CommonModal>
    </>
  );
};

export default Roles;
