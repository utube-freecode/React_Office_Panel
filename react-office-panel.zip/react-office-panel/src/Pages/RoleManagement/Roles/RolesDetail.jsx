import React from "react";

const RolesDetail = () => {
  return <div>RolesDetail</div>;
};

export default RolesDetail;
