import React from "react";
import { useQuery } from "@tanstack/react-query";
import { useFormik } from "formik";

import {
  API_USER_ROLES,
  API_GET_MODULES,
} from "../../../utils/api/ApiConstant";
import { getAxios, postAxios, putAxios } from "../../../Services/commonService";
import { Button, Error, Label, Loading, SubHeading } from "../../../Components";
import { RolesCreateSchema } from "../../../Schema/RoleManagement/RolesSchema";
import { useLocation, useNavigate } from "react-router-dom";

const defaultModuleState = {
  selectAllAccess: false,
  viewAccess: false,
  createAccess: false,
  updateAccess: false,
  deleteAccess: false,
  allowBet: false,
  applyCommission: false,
  limit: false,
  message: false,
  suspended: false,
  enterRate: false,
  commentary: false,
  liveTv: false,
  result: false,
};

const RolesCreate = () => {
  const navigate = useNavigate();
  const location = useLocation();
  const { state } = location;
  const { isLoading, data: moduleData } = useQuery({
    queryKey: ["moduleData"],
    queryFn: async () =>
      await getAxios(API_GET_MODULES, { page: 1, limit: -1 }),
  });

  const { values, touched, errors, handleChange, handleSubmit, setFieldValue } =
    useFormik({
      initialValues: {
        role_name: state?.rowData?.role_name ?? null,
        description: state?.rowData?.description ?? null,
        modules: state?.rowData?.modules ?? [],
      },
      validationSchema: RolesCreateSchema,
      enableReinitialize: true,
      onSubmit: (values) => {
        handleFormSubmit(values);
      },
    });

  const handleCheckboxChange = (moduleName, field, value) => {
    const updatedModules = [...values.modules];
    const moduleIndex = updatedModules.findIndex(
      (module) => module.moduleName === moduleName
    );

    if (moduleIndex === -1) {
      // Add new module
      const newModule = {
        moduleName,
        ...defaultModuleState,
      };

      // If "selectAllAccess" is toggled, update all fields
      if (field === "selectAllAccess") {
        Object.keys(defaultModuleState).forEach((key) => {
          newModule[key] = value;
        });
      } else {
        newModule[field] = value;
      }

      updatedModules.push(newModule);
    } else {
      // Update existing module
      const module = updatedModules[moduleIndex];

      if (field === "selectAllAccess") {
        // Update all fields when "selectAllAccess" is toggled
        Object.keys(defaultModuleState).forEach((key) => {
          module[key] = value;
        });
      } else {
        module[field] = value;

        // Automatically update "selectAllAccess" if all other fields are true
        module.selectAllAccess = Object.keys(defaultModuleState).every(
          (key) => key === "selectAllAccess" || module[key]
        );
      }

      // Remove module if all fields are false
      const allFalse = Object.keys(defaultModuleState).every(
        (key) => key === "moduleName" || module[key] === false
      );
      if (allFalse) {
        updatedModules.splice(moduleIndex, 1);
      }
    }

    setFieldValue("modules", updatedModules);
  };

  const renderCheckbox = (name, moduleName) => {
    const module = values.modules.find(
      (module) => module.moduleName === moduleName
    );

    return (
      <div className="form-check form-switch form-switch-success">
        <input
          className="form-check-input"
          type="checkbox"
          name={name}
          checked={module ? module[name] : false}
          onChange={(e) =>
            handleCheckboxChange(moduleName, name, e.target.checked)
          }
          onFocus={(e) => e.target.blur()}
        />
      </div>
    );
  };

  const handleFormSubmit = async (payload) => {
    const url = state?.rowData?._id
      ? `${API_USER_ROLES}/${state?.rowData?._id}`
      : API_USER_ROLES;

    let res;
    if (state?.rowData?._id) {
      res = await putAxios(url, payload);
    } else {
      res = await postAxios(url, payload);
    }
    if (res) {
      navigate("/rolemanager/roles");
    }
  };

  return (
    <>
      <SubHeading
        subTitle={state?.rowData?._id ? "Edit Role" : "Create Role"}
        isAddBtn={false}
      />
      <form onSubmit={handleSubmit} className="card-body">
        <div className="row">
          <div className="col-lg-2 col-md-6 col-12">
            <Button type="submit" className="btn btn-primary mt-2 w-100">
              Submit
            </Button>
          </div>
          <div className="col-lg-5 col-md-6 col-12">
            <Label htmlFor="role_name" isRequired={true}>
              Role Name
            </Label>
            <input
              type="text"
              id="role_name"
              name="role_name"
              className="form-control"
              value={values.role_name}
              onChange={handleChange}
              placeholder="Enter name"
            />
            {touched.role_name && errors.role_name && (
              <Error>{errors.role_name}</Error>
            )}
          </div>
          <div className="col-lg-5 col-md-6 col-12 ">
            <Label htmlFor="description" isRequired={true}>
              Description
            </Label>
            <textarea
              id="description"
              name="description"
              className="form-control"
              value={values.description}
              onChange={handleChange}
              placeholder="Enter description"
            />
            {touched.description && errors.description && (
              <Error>{errors.description}</Error>
            )}
          </div>
        </div>

        <div className="coll-lg-12 col-md-12 col-12 mt-2">
          {touched.modules && errors.modules && <Error>{errors.modules}</Error>}
          <div className="table-responsive">
            <table
              style={{ borderCollapse: "collapse", width: "100%" }}
              className="table table-striped table-auto"
            >
              <thead className="table-light">
                <tr>
                  <th className="text-start">Tab Name</th>
                  <th className="text-start">select-all</th>
                  <th className="text-start">view</th>
                  <th className="text-start">add</th>
                  <th className="text-start">edit</th>
                  <th className="text-start">delete</th>
                  <th className="text-start">allow bet</th>
                  <th className="text-start">commission</th>
                  <th className="text-start">limit</th>
                  <th className="text-start">message</th>
                  <th className="text-start">suspended</th>
                  <th className="text-start">enter rate</th>
                  <th className="text-start">commentary</th>
                  <th className="text-start">live tv</th>
                  <th className="text-start">result</th>
                </tr>
              </thead>
              <tbody>
                {isLoading ? (
                  <tr>
                    <td colSpan="12" style={{ textAlign: "center" }}>
                      <Loading />
                    </td>
                  </tr>
                ) : (
                  moduleData?.docs?.map((module, i) => (
                    <tr key={i}>
                      <td>{module.moduleName.toUpperCase()}</td>
                      {Object.keys(defaultModuleState).map((key) => (
                        <td key={key}>
                          {renderCheckbox(key, module.moduleName)}
                        </td>
                      ))}
                    </tr>
                  ))
                )}
              </tbody>
            </table>
          </div>
        </div>
      </form>
    </>
  );
};

export default RolesCreate;
