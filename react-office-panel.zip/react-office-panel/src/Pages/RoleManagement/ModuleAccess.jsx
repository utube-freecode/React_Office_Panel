import React, { useState } from "react";
import { useQuery } from "@tanstack/react-query";
import { getAxiosForAuthResponse } from "../../Services/commonService";
import { API_GET_MODULES } from "../../utils/api/ApiConstant";
import { DataTable, SubHeading, YesNoBadge } from "../../Components";
import Icon from "../../assets/icons/Icon";
import { AddEditModuleAccessModal, CommonModal } from "../../Modal";

const ModuleAccess = () => {
  const [isShow, setIsShow] = useState({
    isOpen: false,
    rowData: null,
    name: "",
    modalTitle: "",
    modalContent: null,
    apiFlag: false,
    isEdit: false,
  });

  const { isLoading, data } = useQuery({
    queryKey: ["modules", isShow.apiFlag],
    queryFn: async () =>
      await getAxiosForAuthResponse(API_GET_MODULES, {
        page: 1,
        limit: -1,
      }),
  });

  const fetchData = () => {
    if (!data) return { data: [], pages: 0 };

    return {
      data: data.docs,
      pages: data.pages,
    };
  };

  const columns = [
    {
      accessorKey: "moduleName",
      header: "Module Name",
    },
    {
      accessorKey: "viewAccess",
      header: "View",
      cell: ({ getValue }) => <YesNoBadge getValue={getValue} />,
    },
    {
      accessorKey: "createAccess",
      header: "Add",
      cell: ({ getValue }) => <YesNoBadge getValue={getValue} />,
    },
    {
      accessorKey: "updateAccess",
      header: "Edit",
      cell: ({ getValue }) => <YesNoBadge getValue={getValue} />,
    },
    {
      accessorKey: "deleteAccess",
      header: "Delete",
      cell: ({ getValue }) => <YesNoBadge getValue={getValue} />,
    },
    {
      accessorKey: "allowBet",
      header: "Allow Bet",
      cell: ({ getValue }) => <YesNoBadge getValue={getValue} />,
    },
    {
      accessorKey: "applyCommission",
      header: "Apply Commission",
      cell: ({ getValue }) => <YesNoBadge getValue={getValue} />,
    },
    {
      accessorKey: "limit",
      header: "Limit",
      cell: ({ getValue }) => <YesNoBadge getValue={getValue} />,
    },
    {
      accessorKey: "message",
      header: "Message",
      cell: ({ getValue }) => <YesNoBadge getValue={getValue} />,
    },
    {
      accessorKey: "suspended",
      header: "Suspend",
      cell: ({ getValue }) => <YesNoBadge getValue={getValue} />,
    },
    {
      accessorKey: "enterRate",
      header: "Enter Rate",
      cell: ({ getValue }) => <YesNoBadge getValue={getValue} />,
    },
    {
      accessorKey: "commentary",
      header: "Commentary",
      cell: ({ getValue }) => <YesNoBadge getValue={getValue} />,
    },
    {
      accessorKey: "result",
      header: "Result",
      cell: ({ getValue }) => <YesNoBadge getValue={getValue} />,
    },
    {
      header: "Action",
      cell: ({ row }) => {
        const editUser = () =>
          setIsShow((prev) => ({
            ...prev,
            isOpen: true,
            rowData: row?.original,
            name: "Edit",
            modalTitle: "Edit Module",
            modalContent: AddEditModuleAccessModal,
            isEdit: true,
          }));

        return (
          <div className="d-flex justify-content-around">
            <Icon name="FaEdit" size={18} onClick={editUser} />
          </div>
        );
      },
    },
  ];
  return (
    <>
      <SubHeading
        subTitle="Module Access"
        handleShowHide={(value) =>
          setIsShow((prev) => ({
            ...prev,
            isOpen: true,
            rowData: {},
            name: "add",
            modalTitle: "Create Module",
            modalContent: AddEditModuleAccessModal,
            isEdit: false,
          }))
        }
      />
      <div className="card-body">
        <DataTable
          columns={columns}
          fetchData={fetchData}
          currentPage={1}
          isSearchable={false}
          isPageSize={false}
          isPagination={false}
          // onPageChange={handlePageChange}
          onRecordsPerPageChange={data?.limit}
          recordsPerPage={data?.limit}
          // onSearchChange={handleSearch}
          // searchTerm={searchTerm}
          isLoading={isLoading}
        />
      </div>
      <CommonModal
        isShow={isShow.isOpen}
        handleShowHide={() =>
          setIsShow((prev) => ({
            ...prev,
            isOpen: false,
            rowData: {},
            name: "",
            isEdit: false,
          }))
        }
        modalTitle={isShow.modalTitle}
      >
        {isShow.modalContent &&
          React.createElement(isShow.modalContent, {
            handleShowHide: () =>
              setIsShow((prev) => ({
                ...prev,
                isOpen: false,
                rowData: {},
                name: "",
                modalTitle: "",
                apiFlag: !prev.apiFlag,
                isEdit: false,
              })),
            rowData: isShow.rowData,
            isEdit: isShow.isEdit,
          })}
      </CommonModal>
    </>
  );
};

export default ModuleAccess;
