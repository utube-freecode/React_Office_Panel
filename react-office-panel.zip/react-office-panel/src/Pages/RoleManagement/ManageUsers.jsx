import { debounce } from "lodash";
import React, { useCallback, useState } from "react";
import { postAxiosDataTable, putAxios } from "../../Services/commonService";
import { API_GET_GETALLUSER, API_USER } from "../../utils/api/ApiConstant";
import { useQuery, useQueryClient } from "@tanstack/react-query";
import { DataTable, SubHeading } from "../../Components";
import {
  AddEditUser,
  CheckPasswordModal,
  CommonModal,
  ResetPassword,
} from "../../Modal";
import Icon from "../../assets/icons/Icon";

const ManageUsers = () => {
  const queryClient = useQueryClient();
  const [currentPage, setCurrentPage] = useState(1);
  const [recordsPerPage, setRecordsPerPage] = useState(50);
  const [searchTerm, setSearchTerm] = useState("");
  const [isShow, setIsShow] = useState({
    isOpen: false,
    rowData: null,
    name: "",
    modalTitle: "",
    modalContent: null,
    apiFlag: false,
    isEdit: false,
  });

  const handlePageChange = (page) => {
    setCurrentPage(page);
  };

  const handleRecordsperPage = (value) => {
    setRecordsPerPage(value);
  };

  const handleSearch = (value) => {
    setSearchTerm(value);
    debouncedSearch(value);
  };

  const payload = {
    draw: currentPage,
    columns: [
      {
        data: "",
        name: "",
        searchable: true,
        orderable: false,
        search: {
          value: "",
          regex: false,
        },
      },
      {
        data: "name",
        name: "",
        searchable: true,
        orderable: true,
        search: {
          value: "",
          regex: false,
        },
      },
      {
        data: "username",
        name: "",
        searchable: true,
        orderable: true,
        search: {
          value: "",
          regex: false,
        },
      },
      {
        data: "role",
        name: "",
        searchable: true,
        orderable: true,
        search: {
          value: "",
          regex: false,
        },
      },
      {
        data: "updatedAt",
        name: "",
        searchable: true,
        orderable: true,
        search: {
          value: "",
          regex: false,
        },
      },
      {
        data: "isActive",
        name: "",
        searchable: true,
        orderable: true,
        search: {
          value: "",
          regex: false,
        },
      },
      {
        data: "",
        name: "",
        searchable: true,
        orderable: true,
        search: {
          value: "",
          regex: false,
        },
      },
    ],
    order: [
      {
        column: 0,
        dir: "",
      },
    ],
    start: (currentPage - 1) * recordsPerPage,
    length: recordsPerPage,
    search: {
      value: searchTerm,
      regex: false,
    },
  };

  const { isLoading, data } = useQuery({
    queryKey: [
      "userData",
      currentPage,
      recordsPerPage,
      searchTerm,
      isShow.apiFlag,
    ],
    queryFn: async () => await postAxiosDataTable(API_GET_GETALLUSER, payload),
  });

  const fetchData = () => {
    if (!data) return { data: [], pages: 0 };

    return {
      data: data.docs,
      pages: data.pages,
    };
  };

  const handleQueryClient = (rowData, updatedRowData, key) => {
    return queryClient.setQueryData(
      ["userData", currentPage, recordsPerPage, searchTerm, isShow.apiFlag],
      (oldData) => {
        return {
          ...oldData,
          docs: oldData.docs.map((match) =>
            match._id === rowData._id
              ? { ...match, [key]: updatedRowData[key] }
              : match
          ),
        };
      }
    );
  };

  const handlePutRequest = async (apiUrl, rowData, newValue, key) => {
    const updatedRowData = {
      ...rowData,
      [key]: newValue,
    };
    const url = `${apiUrl}/${rowData?._id}`;

    const res = await putAxios(url, updatedRowData);
    console.log("res", res);
    if (res) {
      handleQueryClient(rowData, updatedRowData, key);
    }
  };

  const columns = [
    { accessorKey: "name", header: "Name" },
    { accessorKey: "username", header: "Username" },
    { accessorKey: "role.role_name", header: "Role" },
    {
      accessorKey: "isActive",
      header: "Is Active",
      cell: ({ getValue, row }) => (
        <CheckPasswordModal
          isSwitch={true}
          onStatusChange={() => {
            handlePutRequest(API_USER, row?.original, !getValue(), "isActive");
          }}
          rowData={row?.original}
          getValue={getValue}
        />
      ),
    },
    {
      header: "Actions",
      cell: ({ row }) => {
        const editUser = () =>
          setIsShow((prev) => ({
            ...prev,
            isOpen: true,
            rowData: row?.original,
            name: "Edit",
            modalTitle: "Edit User",
            modalContent: AddEditUser,
            isEdit: true,
          }));

        const resetPassword = () =>
          setIsShow((prev) => ({
            ...prev,
            isOpen: true,
            rowData: row?.original,
            name: "Reset",
            modalTitle: "Reset Password",
            modalContent: ResetPassword,
            isEdit: false,
          }));
        return (
          <div className="d-flex justify-content-around">
            <Icon name="FaEdit" size={18} onClick={editUser} />
            <Icon name="FaKey" size={18} onClick={resetPassword} />
          </div>
        );
      },
    },
  ];
  return (
    <>
      <SubHeading
        subTitle="User List"
        handleShowHide={(value) =>
          setIsShow((prev) => ({
            ...prev,
            isOpen: true,
            rowData: {},
            name: "add",
            modalTitle: "Create User",
            modalContent: AddEditUser,
            isEdit: false,
          }))
        }
      />
      <div className="card-body">
        <DataTable
          columns={columns}
          fetchData={fetchData}
          currentPage={currentPage}
          onPageChange={handlePageChange}
          onRecordsPerPageChange={handleRecordsperPage}
          recordsPerPage={recordsPerPage}
          onSearchChange={handleSearch}
          isLoading={isLoading}
        />
      </div>
      <CommonModal
        isShow={isShow.isOpen}
        handleShowHide={() =>
          setIsShow((prev) => ({
            ...prev,
            isOpen: false,
            rowData: {},
            name: "",
            isEdit: false,
          }))
        }
        modalTitle={isShow.modalTitle}
      >
        {isShow.modalContent &&
          React.createElement(isShow.modalContent, {
            handleShowHide: () =>
              setIsShow((prev) => ({
                ...prev,
                isOpen: false,
                rowData: {},
                name: "",
                modalTitle: "",
                apiFlag: !prev.apiFlag,
                isEdit: false,
              })),
            rowData: isShow.rowData,
            isEdit: isShow.isEdit,
          })}
      </CommonModal>
    </>
  );
};

export default ManageUsers;
