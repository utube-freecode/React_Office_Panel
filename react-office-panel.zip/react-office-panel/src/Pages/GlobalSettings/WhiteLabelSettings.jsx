import React, { useEffect, useState } from "react";
import { useQuery } from "@tanstack/react-query";

import {
  Button,
  CustomSelect,
  SubHeading,
  Switch,
  YesNoBadge,
} from "../../Components";
import { getAxios, putAxios } from "../../Services/commonService";
import { API_GET_WHITE_LABEL_SETTING } from "../../utils/api/ApiConstant";
import Icon from "../../assets/icons/Icon";
import { CommonModal, WhiteLabelSettingModal } from "../../Modal";

const WhiteLabelSettingOption = [
  {
    label: "layout 1",
    value: "100",
  },
  {
    label: "layout 2",
    value: "200",
  },
];

const WhiteLabelSettings = () => {
  const [finalData, setFinalData] = useState([]);
  console.log("🚀 ~ WhiteLabelSettings ~ finalData:", finalData);
  const [isShow, setIsShow] = useState({
    isOpen: false,
    rowData: null,
    name: "",
    modalTitle: "",
    modalContent: null,
    apiFlag: false,
  });
  const { data: WhiteLabelSettingsData } = useQuery({
    queryKey: ["WhiteLabelSettingsData"],
    queryFn: async () =>
      await getAxios(API_GET_WHITE_LABEL_SETTING, { page: 1, limit: 10 }),
    staleTime: 30000,
  });

  useEffect(() => {
    if (WhiteLabelSettingsData?.docs) {
      setFinalData(WhiteLabelSettingsData.docs);
    }
  }, [WhiteLabelSettingsData]);

  const handleChange = (rowData, name, value) => {
    const updatedRow = { ...rowData, [name]: value };

    setFinalData((prevData) =>
      prevData.map((item) => (item.id === rowData.id ? updatedRow : item))
    );

    if (name === "stockMarket") {
      handleUpdate(updatedRow);
    }
  };

  const handleUpdate = async (payload) => {
    console.log("🚀 ~ handleUpdate ~ payload:", payload);
    const url = `${API_GET_WHITE_LABEL_SETTING}/layout/${payload?._id}`;
    const res = await putAxios(url, payload);
    console.log("🚀 ~ handleUpdate ~ res:", res);
    if (res) {
      console.log(123456);
    }
  };

  return (
    <>
      <SubHeading
        subTitle="white label setting"
        isAddBtn={false}
        isAddBtnPage={true}
        redirectPath="create"
      />
      <div className="card-body">
        <div className="row">
          {finalData &&
            finalData.map((wtl, i) => (
              <div className="col-md-6" key={i}>
                <div className="table-responsive">
                  <table
                    style={{ borderCollapse: "collapse", width: "100%" }}
                    className="table table-striped table-auto"
                  >
                    <thead className="table-light">
                      <tr>
                        <th>scal apex</th>
                        <th>
                          <Icon
                            name="IoSettingsOutline"
                            cursorPointer={true}
                            onClick={() => {
                              setIsShow({
                                isOpen: true,
                                rowData: wtl,
                                name: "",
                                modalTitle: "Edit White Label Setting",
                                modalContent: WhiteLabelSettingModal,
                              });
                            }}
                          />
                        </th>
                      </tr>
                    </thead>
                    <tbody>
                      <tr>
                        <td>URL</td>
                        <td>{wtl.app_url}</td>
                      </tr>
                      <tr>
                        <td>domain name</td>
                        <td>{wtl.app_domainName}</td>
                      </tr>
                      <tr>
                        <td>token</td>
                        <td>{wtl.app_token}</td>
                      </tr>
                      <tr>
                        <td>currency</td>
                        <td>{wtl.app_currency}</td>
                      </tr>
                      <tr>
                        <td>logo</td>
                        <td>{wtl.app_logo}</td>
                      </tr>
                      <tr>
                        <td>unique no</td>
                        <td>{wtl.app_orderNo}</td>
                      </tr>
                      <tr>
                        <td>active</td>
                        <td>
                          <YesNoBadge getValue={() => wtl.isActive} />
                        </td>
                      </tr>
                      <tr>
                        <td>layout</td>
                        <td>
                          <div className="d-flex w-100">
                            <CustomSelect
                              className="w-100"
                              options={WhiteLabelSettingOption}
                              name="app_layout"
                              value={
                                WhiteLabelSettingOption.find(
                                  (x) => x.value === wtl.app_layout
                                ) || null
                              }
                              onChange={(selectedOption) =>
                                handleChange(
                                  wtl,
                                  "app_layout",
                                  selectedOption.value
                                )
                              }
                            />

                            <Button
                              className="btn-primary"
                              onClick={() => handleUpdate(wtl)}
                            >
                              Update
                            </Button>
                          </div>
                        </td>
                      </tr>
                      <tr>
                        <td>stockmarket</td>
                        <td>
                          <Switch
                            name="stockMarket"
                            getValue={() => wtl.stockMarket}
                            onChange={(e) =>
                              handleChange(wtl, "stockMarket", e.target.checked)
                            }
                          />
                        </td>
                      </tr>
                    </tbody>
                  </table>
                </div>
              </div>
            ))}
        </div>
      </div>

      <CommonModal
        isShow={isShow.isOpen}
        handleShowHide={() =>
          setIsShow((prev) => ({
            ...prev,
            isOpen: false,
            rowData: {},
            name: "",
          }))
        }
        modalTitle={isShow.modalTitle}
      >
        {isShow.modalContent &&
          React.createElement(isShow.modalContent, {
            handleShowHide: () =>
              setIsShow((prev) => ({
                ...prev,
                isOpen: false,
                rowData: {},
                name: "",
                modalTitle: "",
                apiFlag: !prev.apiFlag,
              })),
            rowData: isShow.rowData,
          })}
      </CommonModal>
    </>
  );
};

export default WhiteLabelSettings;
