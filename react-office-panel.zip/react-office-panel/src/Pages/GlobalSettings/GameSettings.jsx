import React, { useState } from "react";
import Tab from "react-bootstrap/Tab";
import Tabs from "react-bootstrap/Tabs";
import {
  BookmakerSettings,
  CasinoLiveSettings,
  CasinoSettings,
  CupSettings,
  FancyConfigureSettings,
  FancySettings,
  LineConfigureSettings,
  LineMarketSettings,
  MatchOddsSettings,
  SubHeading,
} from "../../Components";
import { CommonModal, CreateGameSetting } from "../../Modal";

const GameSettings = () => {
  const [activeKey, setActiveKey] = useState("CasinoLiveSettings");
  const [isShow, setIsShow] = useState({
    isOpen: false,
    rowData: null,
    name: "",
    modalTitle: "",
    modalContent: null,
    apiFlag: false,
  });

  const renderContent = () => {
    switch (activeKey) {
      case "CasinoLiveSettings":
        return <CasinoLiveSettings />;
      case "CupSettings":
        return <CupSettings />;
      case "MatchOddsSettings":
        return <MatchOddsSettings />;
      case "FancySettings":
        return <FancySettings />;
      case "BookmakerSettings":
        return <BookmakerSettings />;
      case "FancyConfigureSettings":
        return <FancyConfigureSettings />;
      case "LineMarketSettings":
        return <LineMarketSettings />;
      case "LineConfigureSettings":
        return <LineConfigureSettings />;
      case "CasinoSettings":
        return <CasinoSettings />;
      default:
        return null;
    }
  };

  return (
    <>
      <SubHeading
        subTitle="Game setting list"
        isAddBtn={true}
        handleShowHide={() =>
          setIsShow((prev) => ({
            ...prev,
            isOpen: true,
            rowData: {},
            name: "add",
            modalTitle: "Create Game Setting",
            modalContent: CreateGameSetting,
          }))
        }
      />
      <div className="card-body">
        <Tabs
          id="controlled-tab-example game-setting-flex"
          activeKey={activeKey}
          onSelect={(k) => setActiveKey(k)}
          className="mb-2 tab_bottle "
        >
          <Tab eventKey="CasinoLiveSettings" title="Casino Live Settings" />
          <Tab eventKey="CupSettings" title="Cup Settings" />
          <Tab eventKey="MatchOddsSettings" title="Match Odds Settings" />
          <Tab eventKey="FancySettings" title="Fancy Settings" />
          <Tab eventKey="BookmakerSettings" title="Bookmaker Settings" />
          <Tab
            eventKey="FancyConfigureSettings"
            title="Fancy Configure Settings"
          />
          <Tab eventKey="LineMarketSettings" title="Line Market Settings" />
          <Tab
            eventKey="LineConfigureSettings"
            title="Line Configure Settings"
          />
          <Tab eventKey="CasinoSettings" title="Casino Settings" />
        </Tabs>
        {renderContent()}
      </div>

      <CommonModal
        isShow={isShow.isOpen}
        handleShowHide={() =>
          setIsShow((prev) => ({
            ...prev,
            isOpen: false,
            rowData: {},
            name: "",
          }))
        }
        modalTitle={isShow.modalTitle}
      >
        {isShow.modalContent &&
          React.createElement(isShow.modalContent, {
            handleShowHide: () =>
              setIsShow((prev) => ({
                ...prev,
                isOpen: false,
                rowData: {},
                name: "",
                modalTitle: "",
                apiFlag: !prev.apiFlag,
              })),
            rowData: isShow.rowData,
          })}
      </CommonModal>
    </>
  );
};

export default GameSettings;
