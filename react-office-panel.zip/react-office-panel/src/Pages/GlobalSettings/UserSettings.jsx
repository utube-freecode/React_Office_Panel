import { useQuery } from "@tanstack/react-query";
import React, { useState, useEffect } from "react";
import { API_GET_USERGLOBALSETTINGS } from "../../utils/api/ApiConstant";
import {
  getAxiosForAuthResponse,
  putAxios,
} from "../../Services/commonService";
import { Button, Label, SubHeading } from "../../Components";
import { AddGameSettings, CommonModal } from "../../Modal";
import { useFormik } from "formik";

const UserSettings = () => {
  const [loading, setLoading] = useState(false);
  const [isShow, setIsShow] = useState({
    isOpen: false,
    rowData: null,
    name: "",
    modalTitle: "",
    modalContent: null,
    apiFlag: false,
    isEdit: false,
  });

  const { values, handleChange, handleSubmit, setFieldValue } = useFormik({
    initialValues: {
      settings: [], // Array to hold values for each document
    },
    onSubmit: async (values) => {
      console.log("Updated Values:", values);
      // Submit logic goes here
    },
  });

  const { isLoading, data } = useQuery({
    queryKey: ["userGlobalSettings", isShow?.apiFlag],
    queryFn: async () =>
      await getAxiosForAuthResponse(API_GET_USERGLOBALSETTINGS, {
        page: 1,
        limit: -1,
      }),
  });

  useEffect(() => {
    if (data?.docs?.length) {
      const formattedData = data.docs.map((doc) => ({
        _id: doc._id || "",
        updatedAt: doc.updatedAt,
        createdAt: doc.createdAt,
        minStack: doc?.minStack || 0,
        maxStack: doc?.maxStack || 0,
        maxProfit: doc?.maxProfit || 0,
        maxLoss: doc?.maxLoss || 0,
        betDelay: doc?.betDelay || 0,
        minOdds: doc?.minOdds || 0,
        isActive: doc?.isActive,
        isDeleted: doc?.isDeleted,
        maxOdds: doc?.maxOdds || 0,
        preInPlayProfit: doc?.preInPlayProfit || 0,
        preInPlayStack: doc?.preInPlayStack || 0,
        sport: doc?.sport || { id: "", name: "" },
      }));
      setFieldValue("settings", formattedData);
    }
  }, [data]);

  const updateSettings = async (details) => {
    setLoading(true);
    const res = await putAxios(
      `${API_GET_USERGLOBALSETTINGS}/${details?._id}`,
      details
    );
    setLoading(false);
  };

  return (
    <>
      <SubHeading
        subTitle="Set User General Settings"
        handleShowHide={() =>
          setIsShow((prev) => ({
            ...prev,
            isOpen: true,
            rowData: {},
            name: "add",
            modalTitle: "Create Game Settings",
            modalContent: AddGameSettings,
            isEdit: false,
          }))
        }
      />

      {isLoading ? (
        <div>Loading...</div>
      ) : (
        <div>
          {values.settings.map((setting, index) => (
            <div className=" p-1" key={setting._id}>
              <div className="row m-0 p-0 ">
                <div className="heading_box">
                  <h5>{setting?.sport?.name}</h5>
                  <Button
                    isDisabled={loading}
                    className="btn-primary w-auto"
                    onClick={() => updateSettings(setting)}
                  >
                    Save
                  </Button>
                </div>
              </div>
              <div className="row">
                <div className="col-md-2">
                  <Label
                    htmlFor={`settings[${index}].minStack`}
                    className="form-label"
                    isRequired={true}
                  >
                    Min Stake
                  </Label>
                  <input
                    type="number"
                    className="form-control"
                    name={`settings[${index}].minStack`}
                    id={`settings[${index}].minStack`}
                    placeholder="Enter Min Stake"
                    onChange={handleChange}
                    value={values.settings[index]?.minStack}
                  />
                </div>
                <div className="col-md-2">
                  <Label
                    htmlFor={`settings[${index}].maxStack`}
                    className="form-label"
                  >
                    Max Stake
                  </Label>
                  <input
                    type="number"
                    className="form-control"
                    name={`settings[${index}].maxStack`}
                    id={`settings[${index}].maxStack`}
                    placeholder="Enter Max Stake"
                    onChange={handleChange}
                    value={values.settings[index]?.maxStack}
                  />
                </div>
                <div className="col-md-2">
                  <Label
                    htmlFor={`settings[${index}].maxProfit`}
                    className="form-label"
                  >
                    Max Profit
                  </Label>
                  <input
                    type="number"
                    className="form-control"
                    name={`settings[${index}].maxProfit`}
                    id={`settings[${index}].maxProfit`}
                    placeholder="Enter Max Stake"
                    onChange={handleChange}
                    value={values.settings[index]?.maxProfit}
                  />
                </div>
                <div className="col-md-2">
                  <Label
                    htmlFor={`settings[${index}].maxLoss`}
                    className="form-label"
                  >
                    Max Loss
                  </Label>
                  <input
                    type="number"
                    className="form-control"
                    name={`settings[${index}].maxLoss`}
                    id={`settings[${index}].maxLoss`}
                    placeholder="Enter Max Stake"
                    onChange={handleChange}
                    value={values.settings[index]?.maxLoss}
                  />
                </div>
                <div className="col-md-2">
                  <Label
                    htmlFor={`settings[${index}].betDelay`}
                    className="form-label"
                  >
                    Bet Delay
                  </Label>
                  <input
                    type="number"
                    className="form-control"
                    name={`settings[${index}].betDelay`}
                    id={`settings[${index}].betDelay`}
                    placeholder="Enter Max Stake"
                    onChange={handleChange}
                    value={values.settings[index]?.betDelay}
                  />
                </div>

                <div className="col-md-2">
                  <Label
                    htmlFor={`settings[${index}].minOdds`}
                    className="form-label"
                  >
                    Min Odds
                  </Label>
                  <input
                    type="number"
                    className="form-control"
                    name={`settings[${index}].minOdds`}
                    id={`settings[${index}].minOdds`}
                    placeholder="Enter Max Stake"
                    onChange={handleChange}
                    value={values.settings[index]?.minOdds}
                  />
                </div>
                <div className="col-md-2">
                  <Label
                    htmlFor={`settings[${index}].maxOdds`}
                    className="form-label"
                  >
                    Max Odds
                  </Label>
                  <input
                    type="number"
                    className="form-control"
                    name={`settings[${index}].maxOdds`}
                    id={`settings[${index}].maxOdds`}
                    placeholder="Enter Max Stake"
                    onChange={handleChange}
                    value={values.settings[index]?.maxOdds}
                  />
                </div>

                <div className="col-md-2">
                  <Label
                    htmlFor={`settings[${index}].preInPlayProfit`}
                    className="form-label"
                  >
                    Pre InPlay Profit
                  </Label>
                  <input
                    type="number"
                    className="form-control"
                    name={`settings[${index}].preInPlayProfit`}
                    id={`settings[${index}].preInPlayProfit`}
                    placeholder="Enter Max Stake"
                    onChange={handleChange}
                    value={values.settings[index]?.preInPlayProfit}
                  />
                </div>
                <div className="col-md-2">
                  <Label
                    htmlFor={`settings[${index}].preInPlayStack`}
                    className="form-label"
                  >
                    Pre InPlay Stack
                  </Label>
                  <input
                    type="number"
                    className="form-control"
                    name={`settings[${index}].preInPlayStack`}
                    id={`settings[${index}].preInPlayStack`}
                    placeholder="Enter Max Stake"
                    onChange={handleChange}
                    value={values.settings[index]?.preInPlayStack}
                  />
                </div>
              </div>
            </div>
          ))}
        </div>
      )}

      <CommonModal
        isShow={isShow.isOpen}
        handleShowHide={() =>
          setIsShow((prev) => ({
            ...prev,
            isOpen: false,
            rowData: {},
            name: "",
            isEdit: false,
          }))
        }
        modalTitle={isShow.modalTitle}
      >
        {isShow.modalContent &&
          React.createElement(isShow.modalContent, {
            handleShowHide: () =>
              setIsShow((prev) => ({
                ...prev,
                isOpen: false,
                rowData: {},
                name: "",
                modalTitle: "",
                apiFlag: !prev.apiFlag,
                isEdit: false,
              })),
            rowData: isShow.rowData,
            isEdit: isShow.isEdit,
          })}
      </CommonModal>
    </>
  );
};

export default UserSettings;
