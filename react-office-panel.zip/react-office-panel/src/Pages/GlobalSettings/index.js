import GameSettings from "./GameSettings";
import UserSettings from "./UserSettings";

//white label
import WhiteLabelSettings from "./WhiteLabelSettings";
import WhiteLabelSettingsCreate from "./WhiteLabelSettingsCreate";

export {
  GameSettings,
  UserSettings,
  WhiteLabelSettings,
  WhiteLabelSettingsCreate,
};
