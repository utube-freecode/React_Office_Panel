import React from "react";

import { Button, CustomSelect, Input, Label } from "../../Components";
import { useFilteredData } from "../../Hooks";
import { generateOptions } from "../../helper/common";

const currencyOptions = [
  {
    value: "100",
    label: "Dollar",
  },
  {
    value: "200",
    label: "Rupees",
  },
];

const uniqueOptions = generateOptions();

const WhiteLabelSettingsCreate = () => {
  const { sportOptions } = useFilteredData({
    sport: null,
  });
  return (
    <>
      <div className="card-body">
        <form className="row">
          <div className="col-md-12 d-flex">
            <h4>create white label</h4>
            <Button className="btn-primary">Save</Button>
          </div>
          <div className="col-md-3">
            <Label htmlFor="" isRequired={true}>
              name
            </Label>
            <input
              type="text"
              className="form-control"
              placeholder="enter name"
              autoFocus={true}
            />
          </div>
          <div className="col-md-3">
            <Label htmlFor="" isRequired={true}>
              URL
            </Label>
            <input
              type="text"
              className="form-control"
              placeholder="enter URL"
            />
          </div>
          <div className="col-md-3">
            <Label htmlFor="" isRequired={true}>
              domain name
            </Label>
            <input
              type="text"
              className="form-control"
              placeholder="enter domain name"
            />
          </div>
          <div className="col-md-3">
            <Label htmlFor="" isRequired={true}>
              token
            </Label>
            <input
              type="text"
              className="form-control"
              placeholder="enter token"
            />
          </div>
          <div className="col-md-3">
            <Label htmlFor="" isRequired={true}>
              logo
            </Label>
            <input
              type="text"
              className="form-control"
              placeholder="enter logo"
            />
          </div>
          <div className="col-md-3">
            <Label htmlFor="" isRequired={true}>
              currency
            </Label>
            <CustomSelect options={currencyOptions} onChange={() => {}} />
          </div>
          <div className="col-md-3">
            <Label htmlFor="" isRequired={true}>
              unique no
            </Label>
            <CustomSelect options={uniqueOptions} onChange={() => {}} />
          </div>

          <div className="col-md-12">
            <span>Sport partnership</span>
          </div>

          <div className="col-md-12">
            <div className="table-responsive">
              <table
                style={{ borderCollapse: "collapse", width: "100%" }}
                className="table table-striped table-auto"
              >
                <thead className="table-light">
                  <tr>
                    <th></th>
                    <th className="text-center" colSpan="2">
                      partnership
                    </th>
                    <th className="text-center" colSpan="2">
                      commission
                    </th>
                  </tr>
                </thead>
                <tbody>
                  <tr>
                    <td></td>
                    <td>Down</td>
                    <td>Own</td>
                    <td>Down</td>
                    <td>Own</td>
                  </tr>
                  {sportOptions.map((sport, index) => (
                    <tr key={index}>
                      <td>{sport.label}</td>
                      <td>
                        {
                          <Input
                            type="text"
                            className="form-control"
                            value={0}
                            onChange={() => {}}
                          />
                        }
                      </td>
                      <td>100</td>
                      <td>
                        {
                          <Input
                            type="text"
                            className="form-control"
                            value={0}
                            onChange={() => {}}
                          />
                        }
                      </td>
                      <td>100</td>
                    </tr>
                  ))}
                </tbody>
              </table>
            </div>
          </div>
        </form>
      </div>
    </>
  );
};

export default WhiteLabelSettingsCreate;
