// urls
export const APIBaseUrl = import.meta.env.VITE_API_BASE_URL;
export const APIServerBaseUrl = import.meta.env.VITE_API_SERVER_BASE_URL;
export const importUrl = import.meta.env.VITE_IMPORT_URL;
export const FancySocketUrl = import.meta.env.VITE_FANCY_SOCKET_URL;
export const GlobalWebSocket = import.meta.env.VITE_GLOBAL_WS_BASE;
export const APICustomServerUrl = import.meta.env.VITE_API_CUSTOM_SERVER_URL;
export const socketServerUrl = import.meta.env.VITE_API_BASE_SOCKET_URL;

// secret keys
export const DATA_KEY = "bqwOlSSbg9VLtQuMp3mB7OAWQQwrvj6V";
