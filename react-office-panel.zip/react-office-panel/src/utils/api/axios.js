import axios from "axios";

import store from "../../store";
import { APIBaseUrl } from "../constance";
import { decryptPayload } from "../../helper/common";
import { handleAxiosError } from "../../store/user/user-action";

export const defaultAxios = axios.create({
  baseURL: APIBaseUrl,
});

// Request interceptor for authorization token
defaultAxios.interceptors.request.use(
  (config) => {
    const state = store.getState();
    const token = state?.user?.token ?? "";
    if (token) {
      config.headers["Authorization"] = token;
    }
    return config;
  },
  (error) => {
    return Promise.reject(error);
  }
);

defaultAxios.interceptors.response.use(
  (response) => {
    if (response.status === 200) {
      if (response.data && response.data.auth) {
        const decryptedData = decryptPayload(response.data.auth);
        return decryptedData;
      }
      return response.data;
    } else {
      return Promise.reject({ messages: ["Unknown error occurred"] });
    }
  },
  (error) => {
    const dispatch = store.dispatch;
    handleAxiosError(error, dispatch);
  }
);
