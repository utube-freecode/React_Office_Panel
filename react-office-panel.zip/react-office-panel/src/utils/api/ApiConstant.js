//auth
export const API_LOGIN = "/user/login";
export const API_LOGOUT = "/user/logout";

//common
export const API_GET_WHITE_LABEL_SETTING = "/whiteLabelSetting";
export const API_POST_CHECK_USER = "/user/checkUser";
export const API_VIEW_BET = "/placebet/get-all-viewbet/matchId";
export const API_GET_CURRENCY = "/currency";
export const API_WHITE_LABEL_WELCOME = "/white-lable-welcome-massage";

//webhook setting
export const API_GET_ALL_SETTINGS = "/webHook/getallsettings";
export const API_GET_WEBHOOK_RESTRICTION = "/webHook/getRestriction";
export const API_PUT_WEBHOOK_RESTRICTION = "/webHook/updateRestriction";

// Game = sport
export const API_GET_FILTER_SPORT = "/sport";
export const API_GET_SPORT = "/sport/get-all";
export const API_POST_SPORT = "/sport";
export const API_UPDATE_SPORT = "/sport";

// tournament
export const API_GET_FILTER_TOURNAMENT = "/tournament";
export const API_GET_TOURNAMENT = "/tournament/get-all";
export const API_UPDATE_TOURNAMENT = "/tournament";
export const API_POST_TOURNAMENT = "/tournament";

// match
export const API_GET_MATCH = "/match/get-all";
export const API_ADD_MATCH = "/match";
export const API_GET_MATCHBYID = "/match/byId";
export const API_UPDATE_IMPORTFANCY = "/match/importFancy";
export const API_GET_GETALLCHANNELS = "/match/getAllChannel";
export const API_UPDATE_EDITMATCHLIVETV = "/match/chennel";
export const API_UPDATE_MATCHIMPORTTIME = "/match/openDate";
export const API_POST_MATCHSETTLED = "/match/settled";
export const API_MATCH_MARKET_RESULT = "/match/marketResult";

// market
export const API_ADD_MARKET = "/market";
export const API_GET_MARKET = "/market/get-all";
export const API_GET_ALL_MATCH = "/market/getMatch";
export const API_UPDATE_MARKET = "/market/flag";
export const API_UPDATE_MARKETBYTYPE = "/market/updateMarketByType";
export const API_POST_MARKET_REPORT = "/market/report";
export const API_GET_LINE = "/market/line";
export const API_GET_BOOKMAKER = "/market/bookmaker";
export const API_GET_ODDEVEN = "/market/get-all-OddEven";
export const API_ADD_CREATEFANCY = "/market/createfancy";
export const API_UPDATE_COMMENTARY = "/market/commentory";
export const API_UPDATE_MATCHBYSTATUS = "/market/updateMatchByStatus";
export const API_UPDATE_COMMENTARYSTATUS_MARKET = "/market/commentory";
export const API_GET_OPEN_MARKET = "/market/report";
export const API_GET_MARKETBYID = "/market/getmarketById";
export const API_GET_IMAGES = "/market/getImages";
export const API_POST_IMAGES = "/market/addImages";
export const API_DELETE_IMAGES = "/market/deleteImages";
export const API_UPDATE_IMAGES = "/market/updateImages  ";
export const API_GET_PAYMENT_GATEWAY = "/market/getGateway";

// markeet config
export const API_GET_MARKET_CONFIG = "/marketapi/get";
export const API_CREATE_MARKET_CONFIG = "/marketapi/create";
export const API_STATUS_MARKET_CONFIG = "/marketapi/status";

// bookmaker
export const API_GET_BOOKMAKERSETTINGS = "/bookmakerSetting";
export const API_POST_SETTLEBOOKMAKER = "/bookmaker/settled";
export const API_BOOKMAKER_LATEST_RATE = "/bookmaker/bookmaker-latest-rate";
export const API_BOOKMAKER_ADD_RATE = "/bookmaker/add-bookmaker-rate";

// fancy
export const API_COMMON_FANCY = "/fancy";
export const API_GET_FANCYSETTINGS = "/fancySetting";
export const API_POST_SETTLEFANCY = "/fancy/fancySettle";
export const API_FANCY_CONFIGURE = "/fancyConfigure";
export const API_FANCY_VOLUME = "/fancy/get-volume";
export const API_FANCY_LATEST = "/fancy/get-latest-rate";
export const API_FANCY_SETTING = "/fancy/update-fancy-setting";
export const API_FANCY_RATE = "/fancy/add-fancy-rate";

// user
export const API_USER_ROLES = "/role";
export const API_USER = "/user";
export const API_UPDATE_PASSWORD = "/user/resetpassword";
export const API_GET_GETALLUSER = "/user/get-all";
export const API_GET_IMPORT_INDIA_FANCY = "/user/active-game-india";
export const API_GET_IMPORT_INDIA_FANCYDETAILS = "/user/active-market-india";
export const API_GET_IMPORTRADHEFANCY = "/user/active-game-samudra-new";
export const API_GET_IMPORTRADHEFANCYDETAILS = "/user/active-market-samudra";
export const API_GET_FANCYUSERS = "/user/fancyuser";
export const API_GET_USERGLOBALSETTINGS = "/userGlobalSetting";
export const API_DASHBOARD_COUNT = "/user/getDashboard";

// commentary
export const API_ADD_COMMENTARY = "/commentary/create";
export const API_GET_COMMENTARYLIST = "/commentary/list-all";
export const API_DELETE_COMMENTARY = "/commentary/delete";
export const API_UPDATE_COMMENTARYSTATUS = "/commentary/updateStatus";
export const API_EDIT_COMMENTARY = "/commentary/update";

// moduleAccess
export const API_GET_MODULES = "/moduleAccess";

// game setting
export const API_COMMON_GAME_SETTING = "/gameSetting";

// line-market
export const API_LINE_MARKET_SETTING = "/lineMarketSetting";
export const API_LINE_CONFIGURE = "/lineConfigure";

// import
export const IMPORT_GET_SPORT = "/method/import_export/1";
export const IMPORT_GET_TOURNAMENT = "/method/competitions";
export const IMPORT_GET_MATCH = "/method/competitions_event";
export const IMPORT_GET_MATCHODDS = "/method/competitions_event_matchodd";
export const IMPORT_GET_ALLDATA = "/method/import_data";
