import * as Yup from "yup";

export const AddUserSchema = Yup.object().shape({
  name: Yup.string().trim().required("Name is required"),
  username: Yup.string().trim().required("UserName is required"),
  password: Yup.string().trim().required("Password is required"),
  role: Yup.object().required("Select Any Role"),
});

export const PasswordSchema = Yup.object().shape({
  password: Yup.string().trim().required("Password is required"),
});
