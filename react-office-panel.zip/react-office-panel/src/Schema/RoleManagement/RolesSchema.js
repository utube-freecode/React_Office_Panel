import * as Yup from "yup";

export const RolesCreateSchema = Yup.object().shape({
  role_name: Yup.string().trim().required("Name is required"),
  description: Yup.string().trim().required("Description is required"),
  modules: Yup.array()
    .min(1, "At least one module is required")
    .of(
      Yup.object().shape({
        moduleName: Yup.string().required("Module name is required"),
        selectAllAccess: Yup.boolean(),
        viewAccess: Yup.boolean(),
        createAccess: Yup.boolean(),
        updateAccess: Yup.boolean(),
        deleteAccess: Yup.boolean(),
        allowBet: Yup.boolean(),
        applyCommission: Yup.boolean(),
        limit: Yup.boolean(),
        message: Yup.boolean(),
        suspended: Yup.boolean(),
        enterRate: Yup.boolean(),
        commentary: Yup.boolean(),
        liveTv: Yup.boolean(),
        result: Yup.boolean(),
      })
    ),
});
