import * as Yup from "yup";

const LoginSchema = Yup.object().shape({
  userName: Yup.string().trim().required("Email is required"),
  password: Yup.string().trim().required("Password is required"),
});

export default LoginSchema;
