import * as Yup from "yup";

export const resultSchema = Yup.object().shape({
  password: Yup.string().required("Password is required"),
});
