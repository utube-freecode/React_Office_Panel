import * as Yup from "yup";

export const limitFancySchema = Yup.object().shape({
  minStack: Yup.number()
    .min(0, "Min Stack must be at least 0")
    .required("Min Stack is required"),
  maxStack: Yup.number()
    .min(0, "Max Stack must be at least 0")
    .required("Max Stack is required"),
  maxProfit: Yup.number()
    .min(0, "Max Profit must be at least 0")
    .required("Max Profit is required"),
  betDelay: Yup.number()
    .min(0, "Bet Delay must be at least 0")
    .required("Bet Delay is required"),
  password: Yup.string().trim().required("Password is required"),
});

export const importFancySchema = Yup.object().shape({
  minStack: Yup.number()
    .min(0, "Min Stack must be at least 0")
    .required("Min Stack is required"),
  maxStack: Yup.number()
    .min(0, "Max Stack must be at least 0")
    .required("Max Stack is required"),
  maxProfit: Yup.number()
    .min(0, "Max Profit must be at least 0")
    .required("Max Profit is required"),
  betDelay: Yup.number()
    .min(0, "Bet Delay must be at least 0")
    .required("Bet Delay is required"),
  password: Yup.string().trim().required("Password is required"),
});

export const endGameSchema = Yup.object().shape({
  result: Yup.number().required("Result is required"),
  token: Yup.string().trim().required("Password is required"),
});

export const fancyConfigSchema = Yup.object().shape({
  rateDiffrence: Yup.number().required("Rate diffrence is required"),
  rateRange: Yup.number().required("Rate range is required"),
  ballStart: Yup.number().required("ball start is required"),
});

export const fancySettingSchema = Yup.object().shape({
  minStack: Yup.number().required("Rate diffrence is required"),
  maxStack: Yup.number().required("Rate range is required"),
  betDelay: Yup.number().required("ball start is required"),
  maxProfit: Yup.number().required("ball start is required"),
});
