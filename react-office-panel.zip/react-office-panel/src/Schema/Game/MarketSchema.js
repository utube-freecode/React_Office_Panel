import * as Yup from "yup";

export const MarketSchema = Yup.object().shape({
  sports: Yup.object().required("Sport is required"),
  tournament: Yup.object().required("Tournament is required"),
  match: Yup.object().required("Match is required"),
  assignTo: Yup.object().required("Assign To is required"),
  fancyName: Yup.string().trim().required("Fancy Name is required"),
});

export const messageSchema = Yup.object().shape({
  message: Yup.string().trim().required("Message is required"),
});

export const limitMarketSchema = Yup.object().shape({
  minStack: Yup.number()
    .min(0, "Min Stack must be at least 0")
    .required("Min Stack is required"),
  maxStack: Yup.number()
    .min(0, "Max Stack must be at least 0")
    .required("Max Stack is required"),
  maxProfit: Yup.number()
    .min(0, "Max Profit must be at least 0")
    .required("Max Profit is required"),
  betDelay: Yup.number()
    .min(0, "Bet Delay must be at least 0")
    .required("Bet Delay is required"),
  maxOdds: Yup.number()
    .min(0, "Max Odds must be at least 0")
    .required("Max Odds is required"),
  volume: Yup.number()
    .min(0, "Volume must be at least 0")
    .required("Volume is required"),
});
