import * as Yup from "yup";

export const addBookmakerSchema = Yup.object().shape({
  sport: Yup.mixed()
    .nullable()
    .test(
      "is-object",
      "Sport is required",
      (value) => value && typeof value === "object" && !Array.isArray(value)
    )
    .required("Sport is required"),
  tournament: Yup.mixed()
    .nullable()
    .test(
      "is-object",
      "Tournament is required",
      (value) => value && typeof value === "object" && !Array.isArray(value)
    )
    .required("Tournament is required"),
  match: Yup.mixed()
    .nullable()
    .test(
      "is-object",
      "Match is required",
      (value) => value && typeof value === "object" && !Array.isArray(value)
    )
    .required("Match is required"),
  assignTo: Yup.mixed()
    .nullable()
    .test(
      "is-object",
      "Assign To is required",
      (value) => value && typeof value === "object" && !Array.isArray(value)
    )
    .required("Assign To is required"),
  displayName: Yup.string().trim().required("Display Name is required"),
  maxLimit: Yup.number().required("Max limit is required"),
  runners: Yup.array()
    .of(
      Yup.object().shape({
        runnerName: Yup.string()
          .trim()
          .trim()
          .required("Runner Name is required"),
      })
    )
    .min(1, "At least one runner is required")
    .required("Runners field is required"),
});

export const limitBookmakerSchema = Yup.object().shape({
  minStack: Yup.number()
    .min(0, "Min Stack must be at least 0")
    .required("Min Stack is required"),
  maxStack: Yup.number()
    .min(0, "Max Stack must be at least 0")
    .required("Max Stack is required"),
  maxProfit: Yup.number()
    .min(0, "Max Profit must be at least 0")
    .required("Max Profit is required"),
  betDelay: Yup.number()
    .min(0, "Bet Delay must be at least 0")
    .required("Bet Delay is required"),
});

export const bookmakerSettingSchema = Yup.object().shape({
  minStack: Yup.number()
    .min(0, "Min Stack must be at least 0")
    .required("Min Stack is required"),
  maxStack: Yup.number()
    .min(0, "Max Stack must be at least 0")
    .required("Max Stack is required"),
  maxProfit: Yup.number()
    .min(0, "Max Profit must be at least 0")
    .required("Max Profit is required"),
  betDelay: Yup.number()
    .min(0, "Bet Delay must be at least 0")
    .required("Bet Delay is required"),
});
