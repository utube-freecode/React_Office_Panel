import * as Yup from "yup";

export const LiveTvSchema = Yup.object().shape({
  channelName: Yup.string().trim().required("Channel Name is required"),
  channelUrl: Yup.string().trim().required("Channel url is required"),
});
