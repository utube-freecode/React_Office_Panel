import * as Yup from "yup";

export const ApiSettingSchema = Yup.object().shape({
  apiName: Yup.string().trim().required("api Name is required"),
  apiUrl: Yup.string().trim().required("api url is required"),
});
